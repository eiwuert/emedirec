<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-24 08:08:02 --> Config Class Initialized
INFO - 2017-05-24 08:08:02 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:02 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:02 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:02 --> URI Class Initialized
DEBUG - 2017-05-24 08:08:02 --> No URI present. Default controller set.
INFO - 2017-05-24 08:08:02 --> Router Class Initialized
INFO - 2017-05-24 08:08:02 --> Output Class Initialized
INFO - 2017-05-24 08:08:02 --> Security Class Initialized
DEBUG - 2017-05-24 08:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:02 --> Input Class Initialized
INFO - 2017-05-24 08:08:02 --> Language Class Initialized
INFO - 2017-05-24 08:08:02 --> Loader Class Initialized
INFO - 2017-05-24 08:08:02 --> Controller Class Initialized
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
INFO - 2017-05-24 08:08:03 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:03 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:03 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:03 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:03 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:04 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:04 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:04 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:04 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:04 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:04 --> Upload Class Initialized
INFO - 2017-05-24 08:08:04 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:04 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:04 --> Config Class Initialized
INFO - 2017-05-24 08:08:04 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:04 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:04 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:04 --> URI Class Initialized
INFO - 2017-05-24 08:08:04 --> Router Class Initialized
INFO - 2017-05-24 08:08:04 --> Output Class Initialized
INFO - 2017-05-24 08:08:04 --> Security Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:04 --> Input Class Initialized
INFO - 2017-05-24 08:08:04 --> Language Class Initialized
INFO - 2017-05-24 08:08:04 --> Loader Class Initialized
INFO - 2017-05-24 08:08:04 --> Controller Class Initialized
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
INFO - 2017-05-24 08:08:04 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:04 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:04 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:04 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:04 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:04 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:04 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:04 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:04 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:04 --> Upload Class Initialized
INFO - 2017-05-24 08:08:05 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:05 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:05 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/login.php
INFO - 2017-05-24 08:08:05 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:05 --> Total execution time: 0.5900
INFO - 2017-05-24 08:08:08 --> Config Class Initialized
INFO - 2017-05-24 08:08:08 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:08 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:08 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:08 --> URI Class Initialized
INFO - 2017-05-24 08:08:08 --> Router Class Initialized
INFO - 2017-05-24 08:08:08 --> Output Class Initialized
INFO - 2017-05-24 08:08:08 --> Security Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:08 --> Input Class Initialized
INFO - 2017-05-24 08:08:08 --> Language Class Initialized
INFO - 2017-05-24 08:08:08 --> Loader Class Initialized
INFO - 2017-05-24 08:08:08 --> Controller Class Initialized
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
INFO - 2017-05-24 08:08:08 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:08 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:08 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:08 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:08 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:08 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:08 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:08 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:08 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:08 --> Upload Class Initialized
INFO - 2017-05-24 08:08:08 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:08 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:09 --> Config Class Initialized
INFO - 2017-05-24 08:08:09 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:09 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:09 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:09 --> URI Class Initialized
INFO - 2017-05-24 08:08:09 --> Router Class Initialized
INFO - 2017-05-24 08:08:09 --> Output Class Initialized
INFO - 2017-05-24 08:08:09 --> Security Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:09 --> Input Class Initialized
INFO - 2017-05-24 08:08:09 --> Language Class Initialized
INFO - 2017-05-24 08:08:09 --> Loader Class Initialized
INFO - 2017-05-24 08:08:09 --> Controller Class Initialized
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
INFO - 2017-05-24 08:08:09 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:09 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:09 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:09 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:09 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:09 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:09 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:09 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:09 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:09 --> Upload Class Initialized
INFO - 2017-05-24 08:08:09 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:09 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 08:08:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 08:08:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 08:08:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/main.php
INFO - 2017-05-24 08:08:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 08:08:09 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:09 --> Total execution time: 0.7622
INFO - 2017-05-24 08:08:10 --> Config Class Initialized
INFO - 2017-05-24 08:08:10 --> Hooks Class Initialized
INFO - 2017-05-24 08:08:10 --> Config Class Initialized
INFO - 2017-05-24 08:08:10 --> Config Class Initialized
INFO - 2017-05-24 08:08:10 --> Config Class Initialized
INFO - 2017-05-24 08:08:10 --> Config Class Initialized
INFO - 2017-05-24 08:08:10 --> Config Class Initialized
DEBUG - 2017-05-24 08:08:10 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:10 --> Hooks Class Initialized
INFO - 2017-05-24 08:08:10 --> Hooks Class Initialized
INFO - 2017-05-24 08:08:10 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:10 --> Hooks Class Initialized
INFO - 2017-05-24 08:08:10 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:10 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:10 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 08:08:10 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:10 --> URI Class Initialized
DEBUG - 2017-05-24 08:08:10 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:10 --> Utf8 Class Initialized
DEBUG - 2017-05-24 08:08:10 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:10 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:10 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:10 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:10 --> Router Class Initialized
INFO - 2017-05-24 08:08:10 --> URI Class Initialized
INFO - 2017-05-24 08:08:10 --> URI Class Initialized
INFO - 2017-05-24 08:08:10 --> URI Class Initialized
INFO - 2017-05-24 08:08:10 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:10 --> URI Class Initialized
INFO - 2017-05-24 08:08:10 --> Router Class Initialized
INFO - 2017-05-24 08:08:10 --> Output Class Initialized
INFO - 2017-05-24 08:08:10 --> Router Class Initialized
INFO - 2017-05-24 08:08:10 --> URI Class Initialized
INFO - 2017-05-24 08:08:10 --> Router Class Initialized
INFO - 2017-05-24 08:08:10 --> Router Class Initialized
INFO - 2017-05-24 08:08:10 --> Output Class Initialized
INFO - 2017-05-24 08:08:10 --> Security Class Initialized
INFO - 2017-05-24 08:08:10 --> Output Class Initialized
INFO - 2017-05-24 08:08:10 --> Output Class Initialized
INFO - 2017-05-24 08:08:10 --> Output Class Initialized
INFO - 2017-05-24 08:08:10 --> Router Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:10 --> Security Class Initialized
INFO - 2017-05-24 08:08:10 --> Security Class Initialized
INFO - 2017-05-24 08:08:10 --> Security Class Initialized
INFO - 2017-05-24 08:08:10 --> Security Class Initialized
INFO - 2017-05-24 08:08:10 --> Output Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:10 --> Input Class Initialized
INFO - 2017-05-24 08:08:10 --> Security Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:10 --> Input Class Initialized
INFO - 2017-05-24 08:08:10 --> Input Class Initialized
INFO - 2017-05-24 08:08:10 --> Input Class Initialized
INFO - 2017-05-24 08:08:10 --> Language Class Initialized
INFO - 2017-05-24 08:08:10 --> Input Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:10 --> Language Class Initialized
INFO - 2017-05-24 08:08:10 --> Language Class Initialized
INFO - 2017-05-24 08:08:10 --> Input Class Initialized
INFO - 2017-05-24 08:08:10 --> Language Class Initialized
INFO - 2017-05-24 08:08:10 --> Language Class Initialized
INFO - 2017-05-24 08:08:10 --> Language Class Initialized
INFO - 2017-05-24 08:08:10 --> Loader Class Initialized
INFO - 2017-05-24 08:08:10 --> Loader Class Initialized
INFO - 2017-05-24 08:08:10 --> Loader Class Initialized
INFO - 2017-05-24 08:08:10 --> Loader Class Initialized
INFO - 2017-05-24 08:08:10 --> Controller Class Initialized
INFO - 2017-05-24 08:08:10 --> Controller Class Initialized
INFO - 2017-05-24 08:08:10 --> Loader Class Initialized
INFO - 2017-05-24 08:08:10 --> Loader Class Initialized
INFO - 2017-05-24 08:08:10 --> Controller Class Initialized
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
INFO - 2017-05-24 08:08:10 --> Controller Class Initialized
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
INFO - 2017-05-24 08:08:10 --> Controller Class Initialized
INFO - 2017-05-24 08:08:10 --> Controller Class Initialized
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
INFO - 2017-05-24 08:08:10 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:10 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
INFO - 2017-05-24 08:08:10 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
INFO - 2017-05-24 08:08:10 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:10 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:10 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:10 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:10 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:10 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:10 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:10 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:10 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:10 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:10 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:10 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:10 --> Upload Class Initialized
INFO - 2017-05-24 08:08:10 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:10 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:11 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:11 --> Total execution time: 1.3173
INFO - 2017-05-24 08:08:11 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
INFO - 2017-05-24 08:08:11 --> Config Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Hooks Class Initialized
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:11 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
INFO - 2017-05-24 08:08:11 --> URI Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Router Class Initialized
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
INFO - 2017-05-24 08:08:11 --> Output Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Security Class Initialized
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Input Class Initialized
INFO - 2017-05-24 08:08:11 --> Language Class Initialized
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Loader Class Initialized
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
INFO - 2017-05-24 08:08:11 --> Controller Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
INFO - 2017-05-24 08:08:11 --> Database Driver Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
INFO - 2017-05-24 08:08:11 --> Helper loaded: date_helper
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:11 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:11 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:11 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:11 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:12 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:12 --> Upload Class Initialized
INFO - 2017-05-24 08:08:12 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:12 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:12 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:12 --> Total execution time: 2.2453
INFO - 2017-05-24 08:08:12 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
INFO - 2017-05-24 08:08:12 --> Config Class Initialized
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Hooks Class Initialized
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
INFO - 2017-05-24 08:08:12 --> URI Class Initialized
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Router Class Initialized
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
INFO - 2017-05-24 08:08:12 --> Output Class Initialized
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Security Class Initialized
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Input Class Initialized
INFO - 2017-05-24 08:08:12 --> Language Class Initialized
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Loader Class Initialized
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
INFO - 2017-05-24 08:08:12 --> Controller Class Initialized
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
INFO - 2017-05-24 08:08:12 --> Database Driver Class Initialized
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
INFO - 2017-05-24 08:08:12 --> Helper loaded: date_helper
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:13 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:13 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:13 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:13 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:13 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:13 --> Upload Class Initialized
INFO - 2017-05-24 08:08:13 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:13 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:13 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:13 --> Total execution time: 3.2255
INFO - 2017-05-24 08:08:13 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
INFO - 2017-05-24 08:08:13 --> Config Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Hooks Class Initialized
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
INFO - 2017-05-24 08:08:13 --> URI Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Router Class Initialized
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
INFO - 2017-05-24 08:08:13 --> Output Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Security Class Initialized
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Input Class Initialized
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
INFO - 2017-05-24 08:08:13 --> Language Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
INFO - 2017-05-24 08:08:13 --> Loader Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Controller Class Initialized
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
INFO - 2017-05-24 08:08:13 --> Database Driver Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
INFO - 2017-05-24 08:08:13 --> Helper loaded: date_helper
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:13 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:13 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:13 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:13 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:13 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:13 --> Upload Class Initialized
INFO - 2017-05-24 08:08:13 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:13 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:14 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:14 --> Total execution time: 4.1370
INFO - 2017-05-24 08:08:14 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:14 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:14 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:14 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:14 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:14 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:14 --> Upload Class Initialized
INFO - 2017-05-24 08:08:14 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:14 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:15 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:15 --> Total execution time: 4.8872
INFO - 2017-05-24 08:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:15 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:15 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:15 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:15 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:15 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:15 --> Upload Class Initialized
INFO - 2017-05-24 08:08:15 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:15 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:15 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:15 --> Total execution time: 5.6287
INFO - 2017-05-24 08:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:15 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:16 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:16 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:16 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:16 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:16 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:16 --> Upload Class Initialized
INFO - 2017-05-24 08:08:16 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:16 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:16 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:16 --> Total execution time: 5.1621
INFO - 2017-05-24 08:08:16 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:16 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:17 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:17 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:17 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:17 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:17 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:17 --> Upload Class Initialized
INFO - 2017-05-24 08:08:17 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:17 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:17 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:17 --> Total execution time: 4.7344
INFO - 2017-05-24 08:08:17 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:17 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:17 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:17 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:17 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:17 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:17 --> Upload Class Initialized
INFO - 2017-05-24 08:08:17 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:17 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:18 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:18 --> Total execution time: 4.6930
INFO - 2017-05-24 08:08:28 --> Config Class Initialized
INFO - 2017-05-24 08:08:28 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:28 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:28 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:28 --> URI Class Initialized
INFO - 2017-05-24 08:08:28 --> Router Class Initialized
INFO - 2017-05-24 08:08:28 --> Output Class Initialized
INFO - 2017-05-24 08:08:28 --> Security Class Initialized
DEBUG - 2017-05-24 08:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:28 --> Input Class Initialized
INFO - 2017-05-24 08:08:28 --> Language Class Initialized
INFO - 2017-05-24 08:08:28 --> Loader Class Initialized
INFO - 2017-05-24 08:08:28 --> Controller Class Initialized
INFO - 2017-05-24 08:08:28 --> Model Class Initialized
INFO - 2017-05-24 08:08:28 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:28 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:28 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:28 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:28 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:29 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Config Class Initialized
INFO - 2017-05-24 08:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:29 --> Hooks Class Initialized
INFO - 2017-05-24 08:08:29 --> Pagination Class Initialized
DEBUG - 2017-05-24 08:08:29 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:29 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:29 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:29 --> URI Class Initialized
INFO - 2017-05-24 08:08:29 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:29 --> Router Class Initialized
INFO - 2017-05-24 08:08:29 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:29 --> Output Class Initialized
INFO - 2017-05-24 08:08:29 --> Upload Class Initialized
INFO - 2017-05-24 08:08:29 --> Security Class Initialized
INFO - 2017-05-24 08:08:29 --> Language file loaded: language/english/common_lang.php
DEBUG - 2017-05-24 08:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:29 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:29 --> Input Class Initialized
INFO - 2017-05-24 08:08:29 --> Language Class Initialized
INFO - 2017-05-24 08:08:29 --> Loader Class Initialized
INFO - 2017-05-24 08:08:29 --> Controller Class Initialized
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
INFO - 2017-05-24 08:08:29 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:29 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:29 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 08:08:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 08:08:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 08:08:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/reports/list.php
INFO - 2017-05-24 08:08:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 08:08:29 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:29 --> Total execution time: 1.0832
INFO - 2017-05-24 08:08:29 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:29 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:30 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:30 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:30 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:30 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:30 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:30 --> Upload Class Initialized
INFO - 2017-05-24 08:08:30 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:30 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:30 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 08:08:30 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 08:08:30 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 08:08:30 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/reports/list.php
INFO - 2017-05-24 08:08:30 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 08:08:30 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:30 --> Total execution time: 1.4216
INFO - 2017-05-24 08:08:36 --> Config Class Initialized
INFO - 2017-05-24 08:08:36 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:36 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:36 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:36 --> URI Class Initialized
INFO - 2017-05-24 08:08:36 --> Router Class Initialized
INFO - 2017-05-24 08:08:36 --> Output Class Initialized
INFO - 2017-05-24 08:08:36 --> Security Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:36 --> Input Class Initialized
INFO - 2017-05-24 08:08:36 --> Language Class Initialized
INFO - 2017-05-24 08:08:36 --> Loader Class Initialized
INFO - 2017-05-24 08:08:36 --> Controller Class Initialized
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
INFO - 2017-05-24 08:08:36 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:36 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:36 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:36 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:36 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:36 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:36 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:36 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:36 --> Upload Class Initialized
INFO - 2017-05-24 08:08:36 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:36 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:37 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/reports/dr_list.php
INFO - 2017-05-24 08:08:37 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:37 --> Total execution time: 0.9265
INFO - 2017-05-24 08:08:51 --> Config Class Initialized
INFO - 2017-05-24 08:08:51 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:08:51 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:08:51 --> Utf8 Class Initialized
INFO - 2017-05-24 08:08:51 --> URI Class Initialized
INFO - 2017-05-24 08:08:51 --> Router Class Initialized
INFO - 2017-05-24 08:08:51 --> Output Class Initialized
INFO - 2017-05-24 08:08:51 --> Security Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:08:51 --> Input Class Initialized
INFO - 2017-05-24 08:08:51 --> Language Class Initialized
INFO - 2017-05-24 08:08:51 --> Loader Class Initialized
INFO - 2017-05-24 08:08:51 --> Controller Class Initialized
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
INFO - 2017-05-24 08:08:51 --> Database Driver Class Initialized
INFO - 2017-05-24 08:08:51 --> Helper loaded: file_helper
INFO - 2017-05-24 08:08:51 --> Helper loaded: date_helper
INFO - 2017-05-24 08:08:51 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:51 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:52 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:52 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:52 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:52 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:52 --> Model Class Initialized
DEBUG - 2017-05-24 08:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:52 --> Helper loaded: url_helper
INFO - 2017-05-24 08:08:52 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:08:52 --> Pagination Class Initialized
INFO - 2017-05-24 08:08:52 --> Form Validation Class Initialized
INFO - 2017-05-24 08:08:52 --> Jquery Class Initialized
INFO - 2017-05-24 08:08:52 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:08:52 --> Upload Class Initialized
INFO - 2017-05-24 08:08:52 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:08:52 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:08:52 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/reports/dr_list.php
INFO - 2017-05-24 08:08:52 --> Final output sent to browser
DEBUG - 2017-05-24 08:08:52 --> Total execution time: 0.8458
INFO - 2017-05-24 08:09:05 --> Config Class Initialized
INFO - 2017-05-24 08:09:05 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:09:05 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:09:05 --> Utf8 Class Initialized
INFO - 2017-05-24 08:09:05 --> URI Class Initialized
INFO - 2017-05-24 08:09:05 --> Router Class Initialized
INFO - 2017-05-24 08:09:05 --> Output Class Initialized
INFO - 2017-05-24 08:09:05 --> Security Class Initialized
DEBUG - 2017-05-24 08:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:09:05 --> Input Class Initialized
INFO - 2017-05-24 08:09:06 --> Language Class Initialized
INFO - 2017-05-24 08:09:06 --> Loader Class Initialized
INFO - 2017-05-24 08:09:06 --> Controller Class Initialized
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
INFO - 2017-05-24 08:09:06 --> Database Driver Class Initialized
INFO - 2017-05-24 08:09:06 --> Helper loaded: file_helper
INFO - 2017-05-24 08:09:06 --> Helper loaded: date_helper
INFO - 2017-05-24 08:09:06 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Helper loaded: url_helper
INFO - 2017-05-24 08:09:06 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:09:06 --> Pagination Class Initialized
INFO - 2017-05-24 08:09:06 --> Form Validation Class Initialized
INFO - 2017-05-24 08:09:06 --> Jquery Class Initialized
INFO - 2017-05-24 08:09:06 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:09:06 --> Upload Class Initialized
INFO - 2017-05-24 08:09:06 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:09:06 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:09:06 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/reports/dr_list.php
INFO - 2017-05-24 08:09:06 --> Final output sent to browser
DEBUG - 2017-05-24 08:09:06 --> Total execution time: 0.8538
INFO - 2017-05-24 08:09:32 --> Config Class Initialized
INFO - 2017-05-24 08:09:32 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:09:32 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:09:32 --> Utf8 Class Initialized
INFO - 2017-05-24 08:09:32 --> URI Class Initialized
INFO - 2017-05-24 08:09:32 --> Router Class Initialized
INFO - 2017-05-24 08:09:32 --> Output Class Initialized
INFO - 2017-05-24 08:09:32 --> Security Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:09:32 --> Input Class Initialized
INFO - 2017-05-24 08:09:32 --> Language Class Initialized
INFO - 2017-05-24 08:09:32 --> Loader Class Initialized
INFO - 2017-05-24 08:09:32 --> Controller Class Initialized
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
INFO - 2017-05-24 08:09:32 --> Database Driver Class Initialized
INFO - 2017-05-24 08:09:32 --> Helper loaded: file_helper
INFO - 2017-05-24 08:09:32 --> Helper loaded: date_helper
INFO - 2017-05-24 08:09:32 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Helper loaded: url_helper
INFO - 2017-05-24 08:09:32 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:09:32 --> Pagination Class Initialized
INFO - 2017-05-24 08:09:32 --> Form Validation Class Initialized
INFO - 2017-05-24 08:09:32 --> Jquery Class Initialized
INFO - 2017-05-24 08:09:32 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:09:32 --> Upload Class Initialized
INFO - 2017-05-24 08:09:32 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:09:32 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:09:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 08:09:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 08:09:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 08:09:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 08:09:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 08:09:33 --> Final output sent to browser
DEBUG - 2017-05-24 08:09:33 --> Total execution time: 1.2395
INFO - 2017-05-24 08:09:33 --> Config Class Initialized
INFO - 2017-05-24 08:09:33 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:09:33 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:09:33 --> Utf8 Class Initialized
INFO - 2017-05-24 08:09:33 --> URI Class Initialized
INFO - 2017-05-24 08:09:33 --> Router Class Initialized
INFO - 2017-05-24 08:09:33 --> Output Class Initialized
INFO - 2017-05-24 08:09:33 --> Security Class Initialized
DEBUG - 2017-05-24 08:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:09:33 --> Input Class Initialized
INFO - 2017-05-24 08:09:33 --> Language Class Initialized
INFO - 2017-05-24 08:09:33 --> Loader Class Initialized
INFO - 2017-05-24 08:09:33 --> Controller Class Initialized
INFO - 2017-05-24 08:09:33 --> Model Class Initialized
INFO - 2017-05-24 08:09:33 --> Database Driver Class Initialized
INFO - 2017-05-24 08:09:33 --> Helper loaded: file_helper
INFO - 2017-05-24 08:09:33 --> Helper loaded: date_helper
INFO - 2017-05-24 08:09:33 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:09:33 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Model Class Initialized
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Helper loaded: url_helper
INFO - 2017-05-24 08:09:34 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:09:34 --> Pagination Class Initialized
INFO - 2017-05-24 08:09:34 --> Form Validation Class Initialized
INFO - 2017-05-24 08:09:34 --> Jquery Class Initialized
INFO - 2017-05-24 08:09:34 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:09:34 --> Upload Class Initialized
INFO - 2017-05-24 08:09:34 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:09:34 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:09:34 --> Final output sent to browser
DEBUG - 2017-05-24 08:09:34 --> Total execution time: 1.0060
INFO - 2017-05-24 08:32:10 --> Config Class Initialized
INFO - 2017-05-24 08:32:10 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:32:10 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:32:10 --> Utf8 Class Initialized
INFO - 2017-05-24 08:32:10 --> URI Class Initialized
DEBUG - 2017-05-24 08:32:10 --> No URI present. Default controller set.
INFO - 2017-05-24 08:32:10 --> Router Class Initialized
INFO - 2017-05-24 08:32:10 --> Output Class Initialized
INFO - 2017-05-24 08:32:10 --> Security Class Initialized
DEBUG - 2017-05-24 08:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:32:10 --> Input Class Initialized
INFO - 2017-05-24 08:32:10 --> Language Class Initialized
INFO - 2017-05-24 08:32:11 --> Loader Class Initialized
INFO - 2017-05-24 08:32:11 --> Controller Class Initialized
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
INFO - 2017-05-24 08:32:11 --> Database Driver Class Initialized
INFO - 2017-05-24 08:32:11 --> Helper loaded: file_helper
INFO - 2017-05-24 08:32:11 --> Helper loaded: date_helper
INFO - 2017-05-24 08:32:11 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Helper loaded: url_helper
INFO - 2017-05-24 08:32:11 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:32:11 --> Pagination Class Initialized
INFO - 2017-05-24 08:32:11 --> Form Validation Class Initialized
INFO - 2017-05-24 08:32:11 --> Jquery Class Initialized
INFO - 2017-05-24 08:32:11 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:32:11 --> Upload Class Initialized
INFO - 2017-05-24 08:32:11 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:32:11 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:32:11 --> Config Class Initialized
INFO - 2017-05-24 08:32:11 --> Hooks Class Initialized
DEBUG - 2017-05-24 08:32:11 --> UTF-8 Support Enabled
INFO - 2017-05-24 08:32:11 --> Utf8 Class Initialized
INFO - 2017-05-24 08:32:11 --> URI Class Initialized
INFO - 2017-05-24 08:32:12 --> Router Class Initialized
INFO - 2017-05-24 08:32:12 --> Output Class Initialized
INFO - 2017-05-24 08:32:12 --> Security Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 08:32:12 --> Input Class Initialized
INFO - 2017-05-24 08:32:12 --> Language Class Initialized
INFO - 2017-05-24 08:32:12 --> Loader Class Initialized
INFO - 2017-05-24 08:32:12 --> Controller Class Initialized
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
INFO - 2017-05-24 08:32:12 --> Database Driver Class Initialized
INFO - 2017-05-24 08:32:12 --> Helper loaded: file_helper
INFO - 2017-05-24 08:32:12 --> Helper loaded: date_helper
INFO - 2017-05-24 08:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Model Class Initialized
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Helper loaded: url_helper
INFO - 2017-05-24 08:32:12 --> Helper loaded: form_helper
DEBUG - 2017-05-24 08:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 08:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 08:32:12 --> Pagination Class Initialized
INFO - 2017-05-24 08:32:12 --> Form Validation Class Initialized
INFO - 2017-05-24 08:32:12 --> Jquery Class Initialized
INFO - 2017-05-24 08:32:12 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 08:32:12 --> Upload Class Initialized
INFO - 2017-05-24 08:32:12 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 08:32:12 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 08:32:12 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/login.php
INFO - 2017-05-24 08:32:12 --> Final output sent to browser
DEBUG - 2017-05-24 08:32:12 --> Total execution time: 0.9086
INFO - 2017-05-24 09:22:27 --> Config Class Initialized
INFO - 2017-05-24 09:22:27 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:27 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:27 --> Utf8 Class Initialized
INFO - 2017-05-24 09:22:27 --> URI Class Initialized
INFO - 2017-05-24 09:22:27 --> Router Class Initialized
INFO - 2017-05-24 09:22:27 --> Output Class Initialized
INFO - 2017-05-24 09:22:28 --> Security Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:28 --> Input Class Initialized
INFO - 2017-05-24 09:22:28 --> Language Class Initialized
INFO - 2017-05-24 09:22:28 --> Loader Class Initialized
INFO - 2017-05-24 09:22:28 --> Controller Class Initialized
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
INFO - 2017-05-24 09:22:28 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:28 --> Helper loaded: file_helper
INFO - 2017-05-24 09:22:28 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:28 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:28 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:28 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:28 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:28 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:28 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:28 --> Upload Class Initialized
INFO - 2017-05-24 09:22:28 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:28 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:28 --> Config Class Initialized
INFO - 2017-05-24 09:22:28 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:28 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:28 --> Utf8 Class Initialized
INFO - 2017-05-24 09:22:28 --> URI Class Initialized
INFO - 2017-05-24 09:22:28 --> Router Class Initialized
INFO - 2017-05-24 09:22:28 --> Output Class Initialized
INFO - 2017-05-24 09:22:29 --> Security Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:29 --> Input Class Initialized
INFO - 2017-05-24 09:22:29 --> Language Class Initialized
INFO - 2017-05-24 09:22:29 --> Loader Class Initialized
INFO - 2017-05-24 09:22:29 --> Controller Class Initialized
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
INFO - 2017-05-24 09:22:29 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:29 --> Helper loaded: file_helper
INFO - 2017-05-24 09:22:29 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:29 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:29 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:29 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:29 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:29 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:29 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:29 --> Upload Class Initialized
INFO - 2017-05-24 09:22:29 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:29 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 09:22:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 09:22:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 09:22:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/main.php
INFO - 2017-05-24 09:22:29 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 09:22:29 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:29 --> Total execution time: 1.0277
INFO - 2017-05-24 09:22:30 --> Config Class Initialized
INFO - 2017-05-24 09:22:30 --> Config Class Initialized
INFO - 2017-05-24 09:22:30 --> Config Class Initialized
INFO - 2017-05-24 09:22:30 --> Config Class Initialized
INFO - 2017-05-24 09:22:30 --> Config Class Initialized
INFO - 2017-05-24 09:22:30 --> Hooks Class Initialized
INFO - 2017-05-24 09:22:30 --> Config Class Initialized
INFO - 2017-05-24 09:22:30 --> Hooks Class Initialized
INFO - 2017-05-24 09:22:30 --> Hooks Class Initialized
INFO - 2017-05-24 09:22:30 --> Hooks Class Initialized
INFO - 2017-05-24 09:22:30 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 09:22:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 09:22:30 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:30 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 09:22:30 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:30 --> Utf8 Class Initialized
INFO - 2017-05-24 09:22:30 --> Utf8 Class Initialized
DEBUG - 2017-05-24 09:22:30 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:30 --> Utf8 Class Initialized
INFO - 2017-05-24 09:22:30 --> Utf8 Class Initialized
INFO - 2017-05-24 09:22:30 --> URI Class Initialized
INFO - 2017-05-24 09:22:30 --> Utf8 Class Initialized
INFO - 2017-05-24 09:22:30 --> URI Class Initialized
INFO - 2017-05-24 09:22:30 --> URI Class Initialized
INFO - 2017-05-24 09:22:30 --> URI Class Initialized
INFO - 2017-05-24 09:22:30 --> Utf8 Class Initialized
INFO - 2017-05-24 09:22:30 --> Router Class Initialized
INFO - 2017-05-24 09:22:30 --> URI Class Initialized
INFO - 2017-05-24 09:22:30 --> Router Class Initialized
INFO - 2017-05-24 09:22:30 --> Router Class Initialized
INFO - 2017-05-24 09:22:30 --> URI Class Initialized
INFO - 2017-05-24 09:22:30 --> Router Class Initialized
INFO - 2017-05-24 09:22:30 --> Output Class Initialized
INFO - 2017-05-24 09:22:30 --> Router Class Initialized
INFO - 2017-05-24 09:22:30 --> Output Class Initialized
INFO - 2017-05-24 09:22:30 --> Router Class Initialized
INFO - 2017-05-24 09:22:30 --> Output Class Initialized
INFO - 2017-05-24 09:22:30 --> Output Class Initialized
INFO - 2017-05-24 09:22:30 --> Output Class Initialized
INFO - 2017-05-24 09:22:30 --> Security Class Initialized
INFO - 2017-05-24 09:22:30 --> Output Class Initialized
INFO - 2017-05-24 09:22:30 --> Security Class Initialized
INFO - 2017-05-24 09:22:30 --> Security Class Initialized
INFO - 2017-05-24 09:22:30 --> Security Class Initialized
INFO - 2017-05-24 09:22:30 --> Security Class Initialized
DEBUG - 2017-05-24 09:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 09:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:30 --> Security Class Initialized
INFO - 2017-05-24 09:22:30 --> Input Class Initialized
DEBUG - 2017-05-24 09:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 09:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 09:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:30 --> Input Class Initialized
INFO - 2017-05-24 09:22:30 --> Input Class Initialized
INFO - 2017-05-24 09:22:30 --> Input Class Initialized
DEBUG - 2017-05-24 09:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:30 --> Language Class Initialized
INFO - 2017-05-24 09:22:30 --> Input Class Initialized
INFO - 2017-05-24 09:22:30 --> Language Class Initialized
INFO - 2017-05-24 09:22:30 --> Language Class Initialized
INFO - 2017-05-24 09:22:30 --> Language Class Initialized
INFO - 2017-05-24 09:22:30 --> Input Class Initialized
INFO - 2017-05-24 09:22:30 --> Language Class Initialized
INFO - 2017-05-24 09:22:30 --> Loader Class Initialized
INFO - 2017-05-24 09:22:30 --> Loader Class Initialized
INFO - 2017-05-24 09:22:30 --> Loader Class Initialized
INFO - 2017-05-24 09:22:30 --> Language Class Initialized
INFO - 2017-05-24 09:22:30 --> Loader Class Initialized
INFO - 2017-05-24 09:22:30 --> Controller Class Initialized
INFO - 2017-05-24 09:22:30 --> Loader Class Initialized
INFO - 2017-05-24 09:22:30 --> Loader Class Initialized
INFO - 2017-05-24 09:22:30 --> Controller Class Initialized
INFO - 2017-05-24 09:22:30 --> Controller Class Initialized
INFO - 2017-05-24 09:22:30 --> Controller Class Initialized
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
INFO - 2017-05-24 09:22:30 --> Controller Class Initialized
INFO - 2017-05-24 09:22:30 --> Controller Class Initialized
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
INFO - 2017-05-24 09:22:30 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:30 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
INFO - 2017-05-24 09:22:30 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
INFO - 2017-05-24 09:22:30 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:30 --> Helper loaded: file_helper
INFO - 2017-05-24 09:22:30 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:30 --> Helper loaded: file_helper
INFO - 2017-05-24 09:22:30 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:30 --> Helper loaded: file_helper
INFO - 2017-05-24 09:22:30 --> Helper loaded: file_helper
INFO - 2017-05-24 09:22:30 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:30 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:30 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:30 --> Helper loaded: file_helper
INFO - 2017-05-24 09:22:30 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:30 --> Helper loaded: file_helper
INFO - 2017-05-24 09:22:30 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:30 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:30 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:30 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:31 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:31 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:31 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:31 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:31 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:31 --> Upload Class Initialized
INFO - 2017-05-24 09:22:31 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:31 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:31 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:31 --> Total execution time: 1.4002
INFO - 2017-05-24 09:22:31 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:31 --> Config Class Initialized
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
INFO - 2017-05-24 09:22:31 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:31 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
INFO - 2017-05-24 09:22:31 --> Utf8 Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> URI Class Initialized
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
INFO - 2017-05-24 09:22:31 --> Router Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:31 --> Output Class Initialized
INFO - 2017-05-24 09:22:31 --> Model Class Initialized
INFO - 2017-05-24 09:22:31 --> Security Class Initialized
DEBUG - 2017-05-24 09:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
INFO - 2017-05-24 09:22:32 --> Input Class Initialized
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Language Class Initialized
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
INFO - 2017-05-24 09:22:32 --> Loader Class Initialized
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Controller Class Initialized
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
INFO - 2017-05-24 09:22:32 --> Helper loaded: file_helper
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:32 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:32 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:32 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:32 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:32 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:32 --> Upload Class Initialized
INFO - 2017-05-24 09:22:32 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:32 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:32 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:32 --> Total execution time: 2.5468
INFO - 2017-05-24 09:22:33 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:33 --> Config Class Initialized
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
INFO - 2017-05-24 09:22:33 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:33 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
INFO - 2017-05-24 09:22:33 --> Utf8 Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> URI Class Initialized
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
INFO - 2017-05-24 09:22:33 --> Router Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Output Class Initialized
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
INFO - 2017-05-24 09:22:33 --> Security Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
INFO - 2017-05-24 09:22:33 --> Input Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Language Class Initialized
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
INFO - 2017-05-24 09:22:33 --> Loader Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Controller Class Initialized
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
INFO - 2017-05-24 09:22:33 --> Helper loaded: file_helper
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:33 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:33 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:33 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:33 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:33 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:33 --> Upload Class Initialized
INFO - 2017-05-24 09:22:33 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:33 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:34 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:34 --> Total execution time: 4.0661
INFO - 2017-05-24 09:22:34 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:34 --> Config Class Initialized
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
INFO - 2017-05-24 09:22:34 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:34 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
INFO - 2017-05-24 09:22:34 --> Utf8 Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> URI Class Initialized
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
INFO - 2017-05-24 09:22:34 --> Router Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> Output Class Initialized
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
INFO - 2017-05-24 09:22:34 --> Security Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
INFO - 2017-05-24 09:22:34 --> Input Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> Language Class Initialized
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
INFO - 2017-05-24 09:22:34 --> Loader Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> Controller Class Initialized
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
INFO - 2017-05-24 09:22:34 --> Helper loaded: file_helper
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:35 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:35 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:35 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:35 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:35 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:35 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:35 --> Upload Class Initialized
INFO - 2017-05-24 09:22:35 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:35 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:35 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:35 --> Total execution time: 5.4163
INFO - 2017-05-24 09:22:35 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:35 --> Config Class Initialized
INFO - 2017-05-24 09:22:35 --> Model Class Initialized
INFO - 2017-05-24 09:22:35 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:35 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:35 --> Model Class Initialized
INFO - 2017-05-24 09:22:35 --> Utf8 Class Initialized
DEBUG - 2017-05-24 09:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:35 --> URI Class Initialized
INFO - 2017-05-24 09:22:35 --> Model Class Initialized
INFO - 2017-05-24 09:22:35 --> Router Class Initialized
DEBUG - 2017-05-24 09:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:35 --> Output Class Initialized
INFO - 2017-05-24 09:22:35 --> Model Class Initialized
INFO - 2017-05-24 09:22:35 --> Security Class Initialized
DEBUG - 2017-05-24 09:22:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:35 --> Model Class Initialized
INFO - 2017-05-24 09:22:36 --> Input Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Language Class Initialized
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
INFO - 2017-05-24 09:22:36 --> Loader Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Controller Class Initialized
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
INFO - 2017-05-24 09:22:36 --> Helper loaded: file_helper
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:36 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:36 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:36 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:36 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:36 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:36 --> Upload Class Initialized
INFO - 2017-05-24 09:22:36 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:36 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:36 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:36 --> Total execution time: 6.5079
INFO - 2017-05-24 09:22:36 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:36 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:37 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:37 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:37 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:37 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:37 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:37 --> Upload Class Initialized
INFO - 2017-05-24 09:22:37 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:37 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:37 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:37 --> Total execution time: 7.3986
INFO - 2017-05-24 09:22:37 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:37 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:38 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:38 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:38 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:38 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:38 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:38 --> Upload Class Initialized
INFO - 2017-05-24 09:22:38 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:38 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:38 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:38 --> Total execution time: 6.8441
INFO - 2017-05-24 09:22:38 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:38 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:39 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:39 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:39 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:39 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:39 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:39 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:39 --> Upload Class Initialized
INFO - 2017-05-24 09:22:39 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:39 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 09:22:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 09:22:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 09:22:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 09:22:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 09:22:39 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:39 --> Total execution time: 6.6379
INFO - 2017-05-24 09:22:39 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:39 --> Model Class Initialized
INFO - 2017-05-24 09:22:39 --> Config Class Initialized
DEBUG - 2017-05-24 09:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:39 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:22:40 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
INFO - 2017-05-24 09:22:40 --> Utf8 Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> URI Class Initialized
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
INFO - 2017-05-24 09:22:40 --> Router Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Output Class Initialized
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
INFO - 2017-05-24 09:22:40 --> Security Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
INFO - 2017-05-24 09:22:40 --> Input Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Language Class Initialized
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
INFO - 2017-05-24 09:22:40 --> Loader Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Controller Class Initialized
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Database Driver Class Initialized
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
INFO - 2017-05-24 09:22:40 --> Helper loaded: file_helper
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Helper loaded: date_helper
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:40 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:40 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:40 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:40 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:40 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:40 --> Upload Class Initialized
INFO - 2017-05-24 09:22:40 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:40 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:40 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:40 --> Total execution time: 6.4376
INFO - 2017-05-24 09:22:41 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:41 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:41 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:41 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:41 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:41 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:41 --> Upload Class Initialized
INFO - 2017-05-24 09:22:41 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:41 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:42 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:42 --> Total execution time: 6.2182
INFO - 2017-05-24 09:22:42 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Helper loaded: url_helper
INFO - 2017-05-24 09:22:42 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:22:42 --> Pagination Class Initialized
INFO - 2017-05-24 09:22:42 --> Form Validation Class Initialized
INFO - 2017-05-24 09:22:42 --> Jquery Class Initialized
INFO - 2017-05-24 09:22:42 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:22:42 --> Upload Class Initialized
INFO - 2017-05-24 09:22:42 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:22:42 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:22:43 --> Final output sent to browser
DEBUG - 2017-05-24 09:22:43 --> Total execution time: 3.5067
INFO - 2017-05-24 09:24:33 --> Config Class Initialized
INFO - 2017-05-24 09:24:33 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:33 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:33 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:33 --> URI Class Initialized
INFO - 2017-05-24 09:24:34 --> Router Class Initialized
INFO - 2017-05-24 09:24:34 --> Output Class Initialized
INFO - 2017-05-24 09:24:34 --> Security Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:34 --> Input Class Initialized
INFO - 2017-05-24 09:24:34 --> Language Class Initialized
INFO - 2017-05-24 09:24:34 --> Loader Class Initialized
INFO - 2017-05-24 09:24:34 --> Controller Class Initialized
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
INFO - 2017-05-24 09:24:34 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:34 --> Helper loaded: file_helper
INFO - 2017-05-24 09:24:34 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:34 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:34 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:34 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:34 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:34 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:34 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:34 --> Upload Class Initialized
INFO - 2017-05-24 09:24:34 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:34 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:35 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:35 --> Total execution time: 1.1479
INFO - 2017-05-24 09:24:35 --> Config Class Initialized
INFO - 2017-05-24 09:24:35 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:35 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:35 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:35 --> URI Class Initialized
INFO - 2017-05-24 09:24:35 --> Router Class Initialized
INFO - 2017-05-24 09:24:35 --> Output Class Initialized
INFO - 2017-05-24 09:24:35 --> Security Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:35 --> Input Class Initialized
INFO - 2017-05-24 09:24:35 --> Language Class Initialized
INFO - 2017-05-24 09:24:35 --> Loader Class Initialized
INFO - 2017-05-24 09:24:35 --> Controller Class Initialized
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
INFO - 2017-05-24 09:24:35 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:35 --> Helper loaded: file_helper
INFO - 2017-05-24 09:24:35 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:35 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:35 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:35 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:35 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:35 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:36 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:36 --> Upload Class Initialized
INFO - 2017-05-24 09:24:36 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:36 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:36 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:36 --> Total execution time: 1.0908
INFO - 2017-05-24 09:24:39 --> Config Class Initialized
INFO - 2017-05-24 09:24:39 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:39 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:39 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:39 --> URI Class Initialized
INFO - 2017-05-24 09:24:39 --> Router Class Initialized
INFO - 2017-05-24 09:24:39 --> Output Class Initialized
INFO - 2017-05-24 09:24:39 --> Security Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:39 --> Input Class Initialized
INFO - 2017-05-24 09:24:39 --> Language Class Initialized
INFO - 2017-05-24 09:24:39 --> Loader Class Initialized
INFO - 2017-05-24 09:24:39 --> Controller Class Initialized
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
INFO - 2017-05-24 09:24:39 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:39 --> Helper loaded: file_helper
INFO - 2017-05-24 09:24:39 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:39 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:39 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:40 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:40 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:40 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:40 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:40 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:40 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:40 --> Upload Class Initialized
INFO - 2017-05-24 09:24:40 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:40 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:40 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:40 --> Total execution time: 1.1096
INFO - 2017-05-24 09:24:40 --> Config Class Initialized
INFO - 2017-05-24 09:24:40 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:40 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:40 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:40 --> URI Class Initialized
INFO - 2017-05-24 09:24:40 --> Router Class Initialized
INFO - 2017-05-24 09:24:40 --> Output Class Initialized
INFO - 2017-05-24 09:24:40 --> Security Class Initialized
DEBUG - 2017-05-24 09:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:40 --> Input Class Initialized
INFO - 2017-05-24 09:24:40 --> Language Class Initialized
INFO - 2017-05-24 09:24:40 --> Loader Class Initialized
INFO - 2017-05-24 09:24:40 --> Controller Class Initialized
INFO - 2017-05-24 09:24:40 --> Model Class Initialized
INFO - 2017-05-24 09:24:40 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:40 --> Helper loaded: file_helper
INFO - 2017-05-24 09:24:40 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:40 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:40 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:41 --> Config Class Initialized
INFO - 2017-05-24 09:24:41 --> Helper loaded: form_helper
INFO - 2017-05-24 09:24:41 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:24:41 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:41 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:41 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:41 --> URI Class Initialized
INFO - 2017-05-24 09:24:41 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:41 --> Router Class Initialized
INFO - 2017-05-24 09:24:41 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:41 --> Output Class Initialized
INFO - 2017-05-24 09:24:41 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:41 --> Security Class Initialized
INFO - 2017-05-24 09:24:41 --> Upload Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:41 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:41 --> Input Class Initialized
INFO - 2017-05-24 09:24:41 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:41 --> Language Class Initialized
INFO - 2017-05-24 09:24:41 --> Loader Class Initialized
INFO - 2017-05-24 09:24:41 --> Controller Class Initialized
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
INFO - 2017-05-24 09:24:41 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:41 --> Helper loaded: file_helper
INFO - 2017-05-24 09:24:41 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:41 --> Final output sent to browser
INFO - 2017-05-24 09:24:41 --> Config Class Initialized
INFO - 2017-05-24 09:24:41 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Total execution time: 1.1744
DEBUG - 2017-05-24 09:24:41 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:41 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:41 --> URI Class Initialized
INFO - 2017-05-24 09:24:41 --> Router Class Initialized
INFO - 2017-05-24 09:24:41 --> Output Class Initialized
INFO - 2017-05-24 09:24:41 --> Security Class Initialized
INFO - 2017-05-24 09:24:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2017-05-24 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
INFO - 2017-05-24 09:24:41 --> Input Class Initialized
DEBUG - 2017-05-24 09:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:41 --> Language Class Initialized
INFO - 2017-05-24 09:24:41 --> Model Class Initialized
INFO - 2017-05-24 09:24:42 --> Loader Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Controller Class Initialized
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
INFO - 2017-05-24 09:24:42 --> Helper loaded: file_helper
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:42 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:42 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:42 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:42 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:42 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:42 --> Upload Class Initialized
INFO - 2017-05-24 09:24:42 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:42 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:42 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:42 --> Total execution time: 1.5462
INFO - 2017-05-24 09:24:42 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:42 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:43 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:43 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:43 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:43 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:43 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:43 --> Upload Class Initialized
INFO - 2017-05-24 09:24:43 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:43 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:43 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:43 --> Total execution time: 1.9848
INFO - 2017-05-24 09:24:45 --> Config Class Initialized
INFO - 2017-05-24 09:24:45 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:45 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:45 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:45 --> URI Class Initialized
INFO - 2017-05-24 09:24:45 --> Router Class Initialized
INFO - 2017-05-24 09:24:45 --> Output Class Initialized
INFO - 2017-05-24 09:24:45 --> Security Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:45 --> Input Class Initialized
INFO - 2017-05-24 09:24:45 --> Language Class Initialized
INFO - 2017-05-24 09:24:45 --> Loader Class Initialized
INFO - 2017-05-24 09:24:45 --> Controller Class Initialized
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
INFO - 2017-05-24 09:24:45 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:45 --> Helper loaded: file_helper
INFO - 2017-05-24 09:24:45 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:45 --> Config Class Initialized
INFO - 2017-05-24 09:24:45 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:45 --> Hooks Class Initialized
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
INFO - 2017-05-24 09:24:45 --> URI Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Router Class Initialized
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
INFO - 2017-05-24 09:24:45 --> Output Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Security Class Initialized
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Input Class Initialized
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
INFO - 2017-05-24 09:24:45 --> Language Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Loader Class Initialized
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
INFO - 2017-05-24 09:24:45 --> Controller Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
INFO - 2017-05-24 09:24:45 --> Database Driver Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Helper loaded: file_helper
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
INFO - 2017-05-24 09:24:45 --> Helper loaded: date_helper
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:45 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:46 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:46 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:46 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:46 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:46 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:46 --> Upload Class Initialized
INFO - 2017-05-24 09:24:46 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:46 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:46 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:46 --> Total execution time: 1.3182
INFO - 2017-05-24 09:24:46 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> Config Class Initialized
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
INFO - 2017-05-24 09:24:46 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:24:46 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
INFO - 2017-05-24 09:24:46 --> Utf8 Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> URI Class Initialized
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
INFO - 2017-05-24 09:24:46 --> Router Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> Output Class Initialized
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
INFO - 2017-05-24 09:24:46 --> Security Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
INFO - 2017-05-24 09:24:46 --> Input Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> Language Class Initialized
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
INFO - 2017-05-24 09:24:46 --> Loader Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> Controller Class Initialized
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:46 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:46 --> Model Class Initialized
INFO - 2017-05-24 09:24:47 --> Helper loaded: file_helper
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:47 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:47 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:47 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:47 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:47 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:47 --> Upload Class Initialized
INFO - 2017-05-24 09:24:47 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:47 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:47 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:47 --> Total execution time: 2.1659
INFO - 2017-05-24 09:24:47 --> Config Class Initialized
INFO - 2017-05-24 09:24:47 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:47 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:47 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:47 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:47 --> URI Class Initialized
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
INFO - 2017-05-24 09:24:47 --> Router Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Output Class Initialized
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
INFO - 2017-05-24 09:24:47 --> Security Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 09:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
INFO - 2017-05-24 09:24:47 --> Input Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Language Class Initialized
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
INFO - 2017-05-24 09:24:47 --> Loader Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Controller Class Initialized
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:47 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:47 --> Model Class Initialized
INFO - 2017-05-24 09:24:47 --> Helper loaded: file_helper
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:48 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:48 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:48 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:48 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:48 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:48 --> Upload Class Initialized
INFO - 2017-05-24 09:24:48 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:48 --> Language file loaded: language/english/accounttype_lang.php
ERROR - 2017-05-24 09:24:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query:  SELECT  districts_name AS value FROM emedirec_1_districts WHERE  districts_deleted = 0 AND provinces_id = 
INFO - 2017-05-24 09:24:48 --> Language file loaded: language/english/db_lang.php
INFO - 2017-05-24 09:24:48 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:48 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:49 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:49 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:49 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:49 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:49 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:49 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:49 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:49 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:49 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:49 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:49 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:49 --> Upload Class Initialized
INFO - 2017-05-24 09:24:49 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:49 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:49 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:49 --> Total execution time: 2.1231
INFO - 2017-05-24 09:24:51 --> Config Class Initialized
INFO - 2017-05-24 09:24:51 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:24:51 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:24:51 --> Utf8 Class Initialized
INFO - 2017-05-24 09:24:51 --> URI Class Initialized
INFO - 2017-05-24 09:24:51 --> Router Class Initialized
INFO - 2017-05-24 09:24:51 --> Output Class Initialized
INFO - 2017-05-24 09:24:51 --> Security Class Initialized
DEBUG - 2017-05-24 09:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:24:51 --> Input Class Initialized
INFO - 2017-05-24 09:24:51 --> Language Class Initialized
INFO - 2017-05-24 09:24:51 --> Loader Class Initialized
INFO - 2017-05-24 09:24:51 --> Controller Class Initialized
INFO - 2017-05-24 09:24:51 --> Model Class Initialized
INFO - 2017-05-24 09:24:51 --> Database Driver Class Initialized
INFO - 2017-05-24 09:24:51 --> Helper loaded: file_helper
INFO - 2017-05-24 09:24:52 --> Helper loaded: date_helper
INFO - 2017-05-24 09:24:52 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Model Class Initialized
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Helper loaded: url_helper
INFO - 2017-05-24 09:24:52 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:24:52 --> Pagination Class Initialized
INFO - 2017-05-24 09:24:52 --> Form Validation Class Initialized
INFO - 2017-05-24 09:24:52 --> Jquery Class Initialized
INFO - 2017-05-24 09:24:52 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:24:52 --> Upload Class Initialized
INFO - 2017-05-24 09:24:52 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:24:52 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:24:52 --> Final output sent to browser
DEBUG - 2017-05-24 09:24:52 --> Total execution time: 1.1211
INFO - 2017-05-24 09:25:01 --> Config Class Initialized
INFO - 2017-05-24 09:25:01 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:25:01 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:25:01 --> Config Class Initialized
INFO - 2017-05-24 09:25:01 --> Utf8 Class Initialized
INFO - 2017-05-24 09:25:01 --> Hooks Class Initialized
INFO - 2017-05-24 09:25:01 --> URI Class Initialized
DEBUG - 2017-05-24 09:25:01 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:25:01 --> Router Class Initialized
INFO - 2017-05-24 09:25:01 --> Utf8 Class Initialized
INFO - 2017-05-24 09:25:01 --> URI Class Initialized
INFO - 2017-05-24 09:25:01 --> Output Class Initialized
INFO - 2017-05-24 09:25:01 --> Router Class Initialized
INFO - 2017-05-24 09:25:01 --> Security Class Initialized
INFO - 2017-05-24 09:25:01 --> Output Class Initialized
DEBUG - 2017-05-24 09:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:25:01 --> Security Class Initialized
INFO - 2017-05-24 09:25:01 --> Input Class Initialized
DEBUG - 2017-05-24 09:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:25:01 --> Language Class Initialized
INFO - 2017-05-24 09:25:01 --> Input Class Initialized
INFO - 2017-05-24 09:25:01 --> Language Class Initialized
INFO - 2017-05-24 09:25:01 --> Loader Class Initialized
INFO - 2017-05-24 09:25:01 --> Loader Class Initialized
INFO - 2017-05-24 09:25:01 --> Controller Class Initialized
INFO - 2017-05-24 09:25:01 --> Controller Class Initialized
INFO - 2017-05-24 09:25:01 --> Model Class Initialized
INFO - 2017-05-24 09:25:01 --> Model Class Initialized
INFO - 2017-05-24 09:25:01 --> Database Driver Class Initialized
INFO - 2017-05-24 09:25:01 --> Database Driver Class Initialized
INFO - 2017-05-24 09:25:01 --> Helper loaded: file_helper
INFO - 2017-05-24 09:25:01 --> Helper loaded: file_helper
INFO - 2017-05-24 09:25:01 --> Helper loaded: date_helper
INFO - 2017-05-24 09:25:01 --> Helper loaded: date_helper
INFO - 2017-05-24 09:25:01 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:25:01 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Helper loaded: url_helper
INFO - 2017-05-24 09:25:02 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:25:02 --> Pagination Class Initialized
INFO - 2017-05-24 09:25:02 --> Form Validation Class Initialized
INFO - 2017-05-24 09:25:02 --> Jquery Class Initialized
INFO - 2017-05-24 09:25:02 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:25:02 --> Upload Class Initialized
INFO - 2017-05-24 09:25:02 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:25:02 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:25:03 --> Final output sent to browser
DEBUG - 2017-05-24 09:25:03 --> Total execution time: 1.6197
INFO - 2017-05-24 09:25:03 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Helper loaded: url_helper
INFO - 2017-05-24 09:25:03 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:25:03 --> Pagination Class Initialized
INFO - 2017-05-24 09:25:03 --> Form Validation Class Initialized
INFO - 2017-05-24 09:25:03 --> Jquery Class Initialized
INFO - 2017-05-24 09:25:03 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:25:03 --> Upload Class Initialized
INFO - 2017-05-24 09:25:03 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:25:03 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:25:04 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 09:25:04 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 09:25:04 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 09:25:04 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 09:25:04 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 09:25:04 --> Final output sent to browser
DEBUG - 2017-05-24 09:25:04 --> Total execution time: 2.6180
INFO - 2017-05-24 09:25:04 --> Config Class Initialized
INFO - 2017-05-24 09:25:04 --> Hooks Class Initialized
DEBUG - 2017-05-24 09:25:04 --> UTF-8 Support Enabled
INFO - 2017-05-24 09:25:04 --> Utf8 Class Initialized
INFO - 2017-05-24 09:25:04 --> URI Class Initialized
INFO - 2017-05-24 09:25:04 --> Router Class Initialized
INFO - 2017-05-24 09:25:04 --> Output Class Initialized
INFO - 2017-05-24 09:25:04 --> Security Class Initialized
DEBUG - 2017-05-24 09:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 09:25:04 --> Input Class Initialized
INFO - 2017-05-24 09:25:04 --> Language Class Initialized
INFO - 2017-05-24 09:25:04 --> Loader Class Initialized
INFO - 2017-05-24 09:25:04 --> Controller Class Initialized
INFO - 2017-05-24 09:25:04 --> Model Class Initialized
INFO - 2017-05-24 09:25:04 --> Database Driver Class Initialized
INFO - 2017-05-24 09:25:04 --> Helper loaded: file_helper
INFO - 2017-05-24 09:25:04 --> Helper loaded: date_helper
INFO - 2017-05-24 09:25:05 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Model Class Initialized
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Helper loaded: url_helper
INFO - 2017-05-24 09:25:05 --> Helper loaded: form_helper
DEBUG - 2017-05-24 09:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 09:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 09:25:05 --> Pagination Class Initialized
INFO - 2017-05-24 09:25:05 --> Form Validation Class Initialized
INFO - 2017-05-24 09:25:05 --> Jquery Class Initialized
INFO - 2017-05-24 09:25:05 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 09:25:05 --> Upload Class Initialized
INFO - 2017-05-24 09:25:05 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 09:25:05 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 09:25:05 --> Final output sent to browser
DEBUG - 2017-05-24 09:25:05 --> Total execution time: 1.2100
INFO - 2017-05-24 10:38:17 --> Config Class Initialized
INFO - 2017-05-24 10:38:17 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:17 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:17 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:17 --> URI Class Initialized
INFO - 2017-05-24 10:38:17 --> Router Class Initialized
INFO - 2017-05-24 10:38:17 --> Output Class Initialized
INFO - 2017-05-24 10:38:17 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:17 --> Input Class Initialized
INFO - 2017-05-24 10:38:17 --> Language Class Initialized
INFO - 2017-05-24 10:38:17 --> Loader Class Initialized
INFO - 2017-05-24 10:38:17 --> Controller Class Initialized
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
INFO - 2017-05-24 10:38:17 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:17 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:17 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:17 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:17 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:18 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:18 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:18 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:18 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:18 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:18 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:18 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:18 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:18 --> Upload Class Initialized
INFO - 2017-05-24 10:38:18 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:18 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:18 --> Config Class Initialized
INFO - 2017-05-24 10:38:18 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:18 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:18 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:18 --> URI Class Initialized
INFO - 2017-05-24 10:38:18 --> Router Class Initialized
INFO - 2017-05-24 10:38:18 --> Output Class Initialized
INFO - 2017-05-24 10:38:18 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:18 --> Input Class Initialized
INFO - 2017-05-24 10:38:18 --> Language Class Initialized
INFO - 2017-05-24 10:38:18 --> Loader Class Initialized
INFO - 2017-05-24 10:38:18 --> Controller Class Initialized
INFO - 2017-05-24 10:38:18 --> Model Class Initialized
INFO - 2017-05-24 10:38:18 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:18 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:18 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:19 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:19 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:19 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:19 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:19 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:19 --> Upload Class Initialized
INFO - 2017-05-24 10:38:19 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:19 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:19 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/login.php
INFO - 2017-05-24 10:38:19 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:19 --> Total execution time: 1.0208
INFO - 2017-05-24 10:38:22 --> Config Class Initialized
INFO - 2017-05-24 10:38:22 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:22 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:22 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:22 --> URI Class Initialized
INFO - 2017-05-24 10:38:22 --> Router Class Initialized
INFO - 2017-05-24 10:38:22 --> Output Class Initialized
INFO - 2017-05-24 10:38:22 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:22 --> Input Class Initialized
INFO - 2017-05-24 10:38:22 --> Language Class Initialized
INFO - 2017-05-24 10:38:22 --> Loader Class Initialized
INFO - 2017-05-24 10:38:22 --> Controller Class Initialized
INFO - 2017-05-24 10:38:22 --> Model Class Initialized
INFO - 2017-05-24 10:38:23 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:23 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:23 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:23 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:23 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:23 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:23 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:23 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:23 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:23 --> Upload Class Initialized
INFO - 2017-05-24 10:38:23 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:23 --> Language file loaded: language/english/accounttype_lang.php
ERROR - 2017-05-24 10:38:23 --> Could not find the language line "not_match_username_password"
INFO - 2017-05-24 10:38:23 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/login.php
INFO - 2017-05-24 10:38:23 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:23 --> Total execution time: 1.1620
INFO - 2017-05-24 10:38:28 --> Config Class Initialized
INFO - 2017-05-24 10:38:28 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:28 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:28 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:28 --> URI Class Initialized
INFO - 2017-05-24 10:38:28 --> Router Class Initialized
INFO - 2017-05-24 10:38:29 --> Output Class Initialized
INFO - 2017-05-24 10:38:29 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:29 --> Input Class Initialized
INFO - 2017-05-24 10:38:29 --> Language Class Initialized
INFO - 2017-05-24 10:38:29 --> Loader Class Initialized
INFO - 2017-05-24 10:38:29 --> Controller Class Initialized
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
INFO - 2017-05-24 10:38:29 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:29 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:29 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:29 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:29 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:29 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:29 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:29 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:29 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:29 --> Upload Class Initialized
INFO - 2017-05-24 10:38:29 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:29 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:30 --> Config Class Initialized
INFO - 2017-05-24 10:38:30 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:30 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:30 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:30 --> URI Class Initialized
INFO - 2017-05-24 10:38:30 --> Router Class Initialized
INFO - 2017-05-24 10:38:30 --> Output Class Initialized
INFO - 2017-05-24 10:38:30 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:30 --> Input Class Initialized
INFO - 2017-05-24 10:38:30 --> Language Class Initialized
INFO - 2017-05-24 10:38:30 --> Loader Class Initialized
INFO - 2017-05-24 10:38:30 --> Controller Class Initialized
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
INFO - 2017-05-24 10:38:30 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:30 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:30 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:30 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:30 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:30 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:30 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:30 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:30 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:31 --> Upload Class Initialized
INFO - 2017-05-24 10:38:31 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:31 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:31 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 10:38:31 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 10:38:31 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 10:38:31 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/main.php
INFO - 2017-05-24 10:38:31 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 10:38:31 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:31 --> Total execution time: 1.1371
INFO - 2017-05-24 10:38:31 --> Config Class Initialized
INFO - 2017-05-24 10:38:31 --> Config Class Initialized
INFO - 2017-05-24 10:38:31 --> Config Class Initialized
INFO - 2017-05-24 10:38:31 --> Config Class Initialized
INFO - 2017-05-24 10:38:31 --> Hooks Class Initialized
INFO - 2017-05-24 10:38:31 --> Config Class Initialized
INFO - 2017-05-24 10:38:31 --> Hooks Class Initialized
INFO - 2017-05-24 10:38:31 --> Hooks Class Initialized
INFO - 2017-05-24 10:38:31 --> Config Class Initialized
DEBUG - 2017-05-24 10:38:31 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:31 --> Hooks Class Initialized
INFO - 2017-05-24 10:38:31 --> Hooks Class Initialized
INFO - 2017-05-24 10:38:31 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:31 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:31 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:31 --> Utf8 Class Initialized
DEBUG - 2017-05-24 10:38:31 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:31 --> URI Class Initialized
DEBUG - 2017-05-24 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 10:38:31 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:31 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:31 --> URI Class Initialized
INFO - 2017-05-24 10:38:31 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:31 --> Router Class Initialized
INFO - 2017-05-24 10:38:31 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:31 --> Utf8 Class Initialized
INFO - 2017-05-24 10:38:31 --> URI Class Initialized
INFO - 2017-05-24 10:38:31 --> URI Class Initialized
INFO - 2017-05-24 10:38:31 --> Router Class Initialized
INFO - 2017-05-24 10:38:31 --> Output Class Initialized
INFO - 2017-05-24 10:38:31 --> URI Class Initialized
INFO - 2017-05-24 10:38:31 --> URI Class Initialized
INFO - 2017-05-24 10:38:31 --> Router Class Initialized
INFO - 2017-05-24 10:38:31 --> Router Class Initialized
INFO - 2017-05-24 10:38:31 --> Output Class Initialized
INFO - 2017-05-24 10:38:31 --> Router Class Initialized
INFO - 2017-05-24 10:38:31 --> Security Class Initialized
INFO - 2017-05-24 10:38:31 --> Router Class Initialized
INFO - 2017-05-24 10:38:31 --> Output Class Initialized
INFO - 2017-05-24 10:38:31 --> Output Class Initialized
INFO - 2017-05-24 10:38:31 --> Security Class Initialized
INFO - 2017-05-24 10:38:31 --> Output Class Initialized
INFO - 2017-05-24 10:38:31 --> Output Class Initialized
DEBUG - 2017-05-24 10:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:32 --> Security Class Initialized
INFO - 2017-05-24 10:38:32 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:32 --> Input Class Initialized
INFO - 2017-05-24 10:38:32 --> Security Class Initialized
INFO - 2017-05-24 10:38:32 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:32 --> Language Class Initialized
INFO - 2017-05-24 10:38:32 --> Input Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 10:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:32 --> Language Class Initialized
INFO - 2017-05-24 10:38:32 --> Loader Class Initialized
INFO - 2017-05-24 10:38:32 --> Input Class Initialized
INFO - 2017-05-24 10:38:32 --> Input Class Initialized
INFO - 2017-05-24 10:38:32 --> Input Class Initialized
INFO - 2017-05-24 10:38:32 --> Input Class Initialized
INFO - 2017-05-24 10:38:32 --> Language Class Initialized
INFO - 2017-05-24 10:38:32 --> Loader Class Initialized
INFO - 2017-05-24 10:38:32 --> Language Class Initialized
INFO - 2017-05-24 10:38:32 --> Language Class Initialized
INFO - 2017-05-24 10:38:32 --> Controller Class Initialized
INFO - 2017-05-24 10:38:32 --> Language Class Initialized
INFO - 2017-05-24 10:38:32 --> Loader Class Initialized
INFO - 2017-05-24 10:38:32 --> Loader Class Initialized
INFO - 2017-05-24 10:38:32 --> Loader Class Initialized
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
INFO - 2017-05-24 10:38:32 --> Controller Class Initialized
INFO - 2017-05-24 10:38:32 --> Loader Class Initialized
INFO - 2017-05-24 10:38:32 --> Controller Class Initialized
INFO - 2017-05-24 10:38:32 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
INFO - 2017-05-24 10:38:32 --> Controller Class Initialized
INFO - 2017-05-24 10:38:32 --> Controller Class Initialized
INFO - 2017-05-24 10:38:32 --> Controller Class Initialized
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
INFO - 2017-05-24 10:38:32 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
INFO - 2017-05-24 10:38:32 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:32 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:32 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:32 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:32 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:32 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:32 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:32 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:32 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:32 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:32 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:32 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:32 --> Helper loaded: file_helper
INFO - 2017-05-24 10:38:32 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:32 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:32 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
INFO - 2017-05-24 10:38:32 --> Helper loaded: date_helper
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:32 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:32 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:32 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:32 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:32 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:32 --> Upload Class Initialized
INFO - 2017-05-24 10:38:32 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:32 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:33 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:33 --> Total execution time: 1.9527
INFO - 2017-05-24 10:38:33 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:33 --> Config Class Initialized
INFO - 2017-05-24 10:38:33 --> Model Class Initialized
INFO - 2017-05-24 10:38:33 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 10:38:33 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:33 --> Model Class Initialized
INFO - 2017-05-24 10:38:33 --> Utf8 Class Initialized
DEBUG - 2017-05-24 10:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:33 --> URI Class Initialized
INFO - 2017-05-24 10:38:33 --> Model Class Initialized
INFO - 2017-05-24 10:38:33 --> Router Class Initialized
DEBUG - 2017-05-24 10:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:33 --> Output Class Initialized
INFO - 2017-05-24 10:38:33 --> Model Class Initialized
INFO - 2017-05-24 10:38:33 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 10:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
INFO - 2017-05-24 10:38:34 --> Input Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Language Class Initialized
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
INFO - 2017-05-24 10:38:34 --> Loader Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Controller Class Initialized
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
INFO - 2017-05-24 10:38:34 --> Helper loaded: file_helper
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:34 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:34 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:34 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:34 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:34 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:34 --> Upload Class Initialized
INFO - 2017-05-24 10:38:34 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:34 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:35 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:35 --> Total execution time: 3.2935
INFO - 2017-05-24 10:38:35 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:35 --> Config Class Initialized
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
INFO - 2017-05-24 10:38:35 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 10:38:35 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
INFO - 2017-05-24 10:38:35 --> Utf8 Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> URI Class Initialized
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
INFO - 2017-05-24 10:38:35 --> Router Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Output Class Initialized
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
INFO - 2017-05-24 10:38:35 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 10:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
INFO - 2017-05-24 10:38:35 --> Input Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Language Class Initialized
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
INFO - 2017-05-24 10:38:35 --> Loader Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Controller Class Initialized
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
INFO - 2017-05-24 10:38:35 --> Helper loaded: file_helper
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:35 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:35 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:35 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:35 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:35 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:35 --> Upload Class Initialized
INFO - 2017-05-24 10:38:35 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:35 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:36 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:36 --> Total execution time: 4.4781
INFO - 2017-05-24 10:38:36 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:36 --> Config Class Initialized
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
INFO - 2017-05-24 10:38:36 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 10:38:36 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
INFO - 2017-05-24 10:38:36 --> Utf8 Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> URI Class Initialized
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
INFO - 2017-05-24 10:38:36 --> Router Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Output Class Initialized
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
INFO - 2017-05-24 10:38:36 --> Security Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
INFO - 2017-05-24 10:38:36 --> Input Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Language Class Initialized
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
INFO - 2017-05-24 10:38:36 --> Loader Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Controller Class Initialized
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Database Driver Class Initialized
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
INFO - 2017-05-24 10:38:36 --> Helper loaded: file_helper
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Helper loaded: date_helper
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:36 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:36 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:37 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:37 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:37 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:37 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:37 --> Upload Class Initialized
INFO - 2017-05-24 10:38:37 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:37 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:37 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:37 --> Total execution time: 5.7375
INFO - 2017-05-24 10:38:37 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:37 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:37 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:37 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:37 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:37 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:37 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:37 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:37 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:38 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:38 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:38 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:38 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:38 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:38 --> Upload Class Initialized
INFO - 2017-05-24 10:38:38 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:38 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:38 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:38 --> Total execution time: 7.0639
INFO - 2017-05-24 10:38:38 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:38 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:38 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:39 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:39 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:39 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:39 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:39 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:39 --> Upload Class Initialized
INFO - 2017-05-24 10:38:39 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:39 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:39 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:39 --> Total execution time: 8.0295
INFO - 2017-05-24 10:38:39 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:39 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:40 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:40 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:40 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:40 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:40 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:40 --> Upload Class Initialized
INFO - 2017-05-24 10:38:40 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:40 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:40 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:40 --> Total execution time: 7.0637
INFO - 2017-05-24 10:38:40 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:40 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:41 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:41 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:41 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:41 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:41 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:41 --> Upload Class Initialized
INFO - 2017-05-24 10:38:41 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:41 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:41 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:41 --> Total execution time: 6.7610
INFO - 2017-05-24 10:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:38:41 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Model Class Initialized
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Helper loaded: url_helper
INFO - 2017-05-24 10:38:42 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:38:42 --> Pagination Class Initialized
INFO - 2017-05-24 10:38:42 --> Form Validation Class Initialized
INFO - 2017-05-24 10:38:42 --> Jquery Class Initialized
INFO - 2017-05-24 10:38:42 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:38:42 --> Upload Class Initialized
INFO - 2017-05-24 10:38:42 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:38:42 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:38:42 --> Final output sent to browser
DEBUG - 2017-05-24 10:38:42 --> Total execution time: 6.5953
INFO - 2017-05-24 10:40:18 --> Config Class Initialized
INFO - 2017-05-24 10:40:18 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:40:18 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:40:18 --> Utf8 Class Initialized
INFO - 2017-05-24 10:40:18 --> URI Class Initialized
INFO - 2017-05-24 10:40:18 --> Router Class Initialized
INFO - 2017-05-24 10:40:18 --> Output Class Initialized
INFO - 2017-05-24 10:40:18 --> Security Class Initialized
DEBUG - 2017-05-24 10:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:40:18 --> Input Class Initialized
INFO - 2017-05-24 10:40:18 --> Language Class Initialized
INFO - 2017-05-24 10:40:18 --> Loader Class Initialized
INFO - 2017-05-24 10:40:18 --> Controller Class Initialized
INFO - 2017-05-24 10:40:18 --> Model Class Initialized
INFO - 2017-05-24 10:40:18 --> Database Driver Class Initialized
INFO - 2017-05-24 10:40:18 --> Helper loaded: file_helper
INFO - 2017-05-24 10:40:18 --> Helper loaded: date_helper
INFO - 2017-05-24 10:40:18 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:40:18 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:18 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:18 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:18 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:18 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Helper loaded: url_helper
INFO - 2017-05-24 10:40:19 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:40:19 --> Pagination Class Initialized
INFO - 2017-05-24 10:40:19 --> Form Validation Class Initialized
INFO - 2017-05-24 10:40:19 --> Jquery Class Initialized
INFO - 2017-05-24 10:40:19 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:40:19 --> Upload Class Initialized
INFO - 2017-05-24 10:40:19 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:40:19 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:40:19 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 10:40:19 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 10:40:19 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 10:40:19 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 10:40:19 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 10:40:19 --> Final output sent to browser
DEBUG - 2017-05-24 10:40:19 --> Total execution time: 1.3435
INFO - 2017-05-24 10:40:20 --> Config Class Initialized
INFO - 2017-05-24 10:40:20 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:40:20 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:40:20 --> Utf8 Class Initialized
INFO - 2017-05-24 10:40:20 --> URI Class Initialized
INFO - 2017-05-24 10:40:20 --> Router Class Initialized
INFO - 2017-05-24 10:40:20 --> Output Class Initialized
INFO - 2017-05-24 10:40:20 --> Security Class Initialized
DEBUG - 2017-05-24 10:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:40:20 --> Input Class Initialized
INFO - 2017-05-24 10:40:20 --> Language Class Initialized
INFO - 2017-05-24 10:40:20 --> Loader Class Initialized
INFO - 2017-05-24 10:40:20 --> Controller Class Initialized
INFO - 2017-05-24 10:40:20 --> Model Class Initialized
INFO - 2017-05-24 10:40:20 --> Database Driver Class Initialized
INFO - 2017-05-24 10:40:20 --> Helper loaded: file_helper
INFO - 2017-05-24 10:40:20 --> Helper loaded: date_helper
INFO - 2017-05-24 10:40:20 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:40:20 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:20 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:20 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:20 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:20 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:20 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:20 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:21 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:21 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:21 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:21 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:21 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:21 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:21 --> Helper loaded: url_helper
INFO - 2017-05-24 10:40:21 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:40:21 --> Pagination Class Initialized
INFO - 2017-05-24 10:40:21 --> Form Validation Class Initialized
INFO - 2017-05-24 10:40:21 --> Jquery Class Initialized
INFO - 2017-05-24 10:40:21 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:40:21 --> Upload Class Initialized
INFO - 2017-05-24 10:40:21 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:40:21 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:40:21 --> Final output sent to browser
DEBUG - 2017-05-24 10:40:21 --> Total execution time: 1.2741
INFO - 2017-05-24 10:40:45 --> Config Class Initialized
INFO - 2017-05-24 10:40:45 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:40:45 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:40:45 --> Utf8 Class Initialized
INFO - 2017-05-24 10:40:45 --> URI Class Initialized
INFO - 2017-05-24 10:40:45 --> Router Class Initialized
INFO - 2017-05-24 10:40:45 --> Output Class Initialized
INFO - 2017-05-24 10:40:45 --> Security Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:40:45 --> Input Class Initialized
INFO - 2017-05-24 10:40:45 --> Language Class Initialized
INFO - 2017-05-24 10:40:45 --> Loader Class Initialized
INFO - 2017-05-24 10:40:45 --> Controller Class Initialized
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
INFO - 2017-05-24 10:40:45 --> Database Driver Class Initialized
INFO - 2017-05-24 10:40:45 --> Helper loaded: file_helper
INFO - 2017-05-24 10:40:45 --> Helper loaded: date_helper
INFO - 2017-05-24 10:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Helper loaded: url_helper
INFO - 2017-05-24 10:40:45 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:40:45 --> Pagination Class Initialized
INFO - 2017-05-24 10:40:45 --> Form Validation Class Initialized
INFO - 2017-05-24 10:40:45 --> Jquery Class Initialized
INFO - 2017-05-24 10:40:45 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:40:45 --> Upload Class Initialized
INFO - 2017-05-24 10:40:45 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:40:45 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:40:46 --> Final output sent to browser
DEBUG - 2017-05-24 10:40:46 --> Total execution time: 1.1977
INFO - 2017-05-24 10:40:46 --> Config Class Initialized
INFO - 2017-05-24 10:40:46 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:40:46 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:40:46 --> Utf8 Class Initialized
INFO - 2017-05-24 10:40:46 --> URI Class Initialized
INFO - 2017-05-24 10:40:46 --> Router Class Initialized
INFO - 2017-05-24 10:40:46 --> Output Class Initialized
INFO - 2017-05-24 10:40:46 --> Security Class Initialized
DEBUG - 2017-05-24 10:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:40:46 --> Input Class Initialized
INFO - 2017-05-24 10:40:46 --> Language Class Initialized
INFO - 2017-05-24 10:40:46 --> Loader Class Initialized
INFO - 2017-05-24 10:40:46 --> Controller Class Initialized
INFO - 2017-05-24 10:40:46 --> Model Class Initialized
INFO - 2017-05-24 10:40:46 --> Database Driver Class Initialized
INFO - 2017-05-24 10:40:46 --> Helper loaded: file_helper
INFO - 2017-05-24 10:40:47 --> Helper loaded: date_helper
INFO - 2017-05-24 10:40:47 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Helper loaded: url_helper
INFO - 2017-05-24 10:40:47 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:40:47 --> Pagination Class Initialized
INFO - 2017-05-24 10:40:47 --> Form Validation Class Initialized
INFO - 2017-05-24 10:40:47 --> Jquery Class Initialized
INFO - 2017-05-24 10:40:47 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:40:47 --> Upload Class Initialized
INFO - 2017-05-24 10:40:47 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:40:47 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:40:47 --> Final output sent to browser
DEBUG - 2017-05-24 10:40:47 --> Total execution time: 1.2238
INFO - 2017-05-24 10:40:50 --> Config Class Initialized
INFO - 2017-05-24 10:40:50 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:40:50 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:40:50 --> Utf8 Class Initialized
INFO - 2017-05-24 10:40:50 --> URI Class Initialized
INFO - 2017-05-24 10:40:50 --> Router Class Initialized
INFO - 2017-05-24 10:40:50 --> Output Class Initialized
INFO - 2017-05-24 10:40:50 --> Security Class Initialized
DEBUG - 2017-05-24 10:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:40:50 --> Input Class Initialized
INFO - 2017-05-24 10:40:50 --> Language Class Initialized
INFO - 2017-05-24 10:40:50 --> Loader Class Initialized
INFO - 2017-05-24 10:40:50 --> Controller Class Initialized
INFO - 2017-05-24 10:40:50 --> Model Class Initialized
INFO - 2017-05-24 10:40:50 --> Database Driver Class Initialized
INFO - 2017-05-24 10:40:50 --> Helper loaded: file_helper
INFO - 2017-05-24 10:40:50 --> Helper loaded: date_helper
INFO - 2017-05-24 10:40:50 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Helper loaded: url_helper
INFO - 2017-05-24 10:40:51 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:40:51 --> Pagination Class Initialized
INFO - 2017-05-24 10:40:51 --> Form Validation Class Initialized
INFO - 2017-05-24 10:40:51 --> Jquery Class Initialized
INFO - 2017-05-24 10:40:51 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:40:51 --> Upload Class Initialized
INFO - 2017-05-24 10:40:51 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:40:51 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:40:51 --> Final output sent to browser
DEBUG - 2017-05-24 10:40:51 --> Total execution time: 1.2704
INFO - 2017-05-24 10:40:53 --> Config Class Initialized
INFO - 2017-05-24 10:40:53 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:40:53 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:40:53 --> Utf8 Class Initialized
INFO - 2017-05-24 10:40:53 --> URI Class Initialized
INFO - 2017-05-24 10:40:53 --> Router Class Initialized
INFO - 2017-05-24 10:40:53 --> Output Class Initialized
INFO - 2017-05-24 10:40:53 --> Security Class Initialized
DEBUG - 2017-05-24 10:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:40:53 --> Input Class Initialized
INFO - 2017-05-24 10:40:53 --> Language Class Initialized
INFO - 2017-05-24 10:40:53 --> Loader Class Initialized
INFO - 2017-05-24 10:40:53 --> Controller Class Initialized
INFO - 2017-05-24 10:40:53 --> Model Class Initialized
INFO - 2017-05-24 10:40:53 --> Database Driver Class Initialized
INFO - 2017-05-24 10:40:53 --> Helper loaded: file_helper
INFO - 2017-05-24 10:40:53 --> Helper loaded: date_helper
INFO - 2017-05-24 10:40:53 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:40:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Helper loaded: url_helper
INFO - 2017-05-24 10:40:54 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:40:54 --> Pagination Class Initialized
INFO - 2017-05-24 10:40:54 --> Form Validation Class Initialized
INFO - 2017-05-24 10:40:54 --> Jquery Class Initialized
INFO - 2017-05-24 10:40:54 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:40:54 --> Upload Class Initialized
INFO - 2017-05-24 10:40:54 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:40:54 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:40:54 --> Final output sent to browser
DEBUG - 2017-05-24 10:40:54 --> Total execution time: 1.2531
INFO - 2017-05-24 10:40:54 --> Config Class Initialized
INFO - 2017-05-24 10:40:54 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:40:54 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:40:54 --> Utf8 Class Initialized
INFO - 2017-05-24 10:40:54 --> URI Class Initialized
INFO - 2017-05-24 10:40:54 --> Router Class Initialized
INFO - 2017-05-24 10:40:54 --> Output Class Initialized
INFO - 2017-05-24 10:40:54 --> Security Class Initialized
DEBUG - 2017-05-24 10:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:40:54 --> Input Class Initialized
INFO - 2017-05-24 10:40:54 --> Language Class Initialized
INFO - 2017-05-24 10:40:54 --> Loader Class Initialized
INFO - 2017-05-24 10:40:54 --> Controller Class Initialized
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
INFO - 2017-05-24 10:40:55 --> Database Driver Class Initialized
INFO - 2017-05-24 10:40:55 --> Helper loaded: file_helper
INFO - 2017-05-24 10:40:55 --> Helper loaded: date_helper
INFO - 2017-05-24 10:40:55 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Model Class Initialized
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Helper loaded: url_helper
INFO - 2017-05-24 10:40:55 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:40:55 --> Pagination Class Initialized
INFO - 2017-05-24 10:40:55 --> Form Validation Class Initialized
INFO - 2017-05-24 10:40:55 --> Jquery Class Initialized
INFO - 2017-05-24 10:40:55 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:40:55 --> Upload Class Initialized
INFO - 2017-05-24 10:40:55 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:40:55 --> Language file loaded: language/english/accounttype_lang.php
ERROR - 2017-05-24 10:40:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query:  SELECT  districts_name AS value FROM emedirec_1_districts WHERE  districts_deleted = 0 AND districts_name LIKE '%B%' AND provinces_id = 
INFO - 2017-05-24 10:40:55 --> Language file loaded: language/english/db_lang.php
INFO - 2017-05-24 10:41:02 --> Config Class Initialized
INFO - 2017-05-24 10:41:02 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:41:02 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:41:02 --> Utf8 Class Initialized
INFO - 2017-05-24 10:41:02 --> URI Class Initialized
INFO - 2017-05-24 10:41:02 --> Router Class Initialized
INFO - 2017-05-24 10:41:02 --> Output Class Initialized
INFO - 2017-05-24 10:41:02 --> Security Class Initialized
DEBUG - 2017-05-24 10:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:41:02 --> Input Class Initialized
INFO - 2017-05-24 10:41:02 --> Language Class Initialized
INFO - 2017-05-24 10:41:02 --> Loader Class Initialized
INFO - 2017-05-24 10:41:02 --> Controller Class Initialized
INFO - 2017-05-24 10:41:02 --> Model Class Initialized
INFO - 2017-05-24 10:41:03 --> Database Driver Class Initialized
INFO - 2017-05-24 10:41:03 --> Helper loaded: file_helper
INFO - 2017-05-24 10:41:03 --> Helper loaded: date_helper
INFO - 2017-05-24 10:41:03 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Helper loaded: url_helper
INFO - 2017-05-24 10:41:03 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:41:03 --> Pagination Class Initialized
INFO - 2017-05-24 10:41:03 --> Form Validation Class Initialized
INFO - 2017-05-24 10:41:03 --> Jquery Class Initialized
INFO - 2017-05-24 10:41:03 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:41:03 --> Upload Class Initialized
INFO - 2017-05-24 10:41:03 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:41:03 --> Config Class Initialized
INFO - 2017-05-24 10:41:03 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:41:03 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:41:03 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:41:03 --> Utf8 Class Initialized
INFO - 2017-05-24 10:41:03 --> URI Class Initialized
INFO - 2017-05-24 10:41:03 --> Router Class Initialized
INFO - 2017-05-24 10:41:03 --> Output Class Initialized
INFO - 2017-05-24 10:41:03 --> Security Class Initialized
DEBUG - 2017-05-24 10:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:41:03 --> Input Class Initialized
INFO - 2017-05-24 10:41:03 --> Language Class Initialized
INFO - 2017-05-24 10:41:03 --> Loader Class Initialized
INFO - 2017-05-24 10:41:03 --> Controller Class Initialized
INFO - 2017-05-24 10:41:03 --> Model Class Initialized
INFO - 2017-05-24 10:41:03 --> Database Driver Class Initialized
INFO - 2017-05-24 10:41:04 --> Helper loaded: file_helper
INFO - 2017-05-24 10:41:04 --> Helper loaded: date_helper
INFO - 2017-05-24 10:41:04 --> Final output sent to browser
DEBUG - 2017-05-24 10:41:04 --> Total execution time: 1.3169
INFO - 2017-05-24 10:41:04 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Helper loaded: url_helper
INFO - 2017-05-24 10:41:04 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:41:04 --> Pagination Class Initialized
INFO - 2017-05-24 10:41:04 --> Form Validation Class Initialized
INFO - 2017-05-24 10:41:04 --> Jquery Class Initialized
INFO - 2017-05-24 10:41:04 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:41:04 --> Upload Class Initialized
INFO - 2017-05-24 10:41:04 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:41:04 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:41:05 --> Final output sent to browser
DEBUG - 2017-05-24 10:41:05 --> Total execution time: 1.3617
INFO - 2017-05-24 10:41:06 --> Config Class Initialized
INFO - 2017-05-24 10:41:06 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:41:06 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:41:06 --> Utf8 Class Initialized
INFO - 2017-05-24 10:41:06 --> URI Class Initialized
INFO - 2017-05-24 10:41:06 --> Router Class Initialized
INFO - 2017-05-24 10:41:06 --> Output Class Initialized
INFO - 2017-05-24 10:41:06 --> Security Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:41:06 --> Input Class Initialized
INFO - 2017-05-24 10:41:06 --> Language Class Initialized
INFO - 2017-05-24 10:41:06 --> Loader Class Initialized
INFO - 2017-05-24 10:41:06 --> Controller Class Initialized
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
INFO - 2017-05-24 10:41:06 --> Database Driver Class Initialized
INFO - 2017-05-24 10:41:06 --> Helper loaded: file_helper
INFO - 2017-05-24 10:41:06 --> Helper loaded: date_helper
INFO - 2017-05-24 10:41:06 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:06 --> Helper loaded: url_helper
INFO - 2017-05-24 10:41:06 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:41:07 --> Pagination Class Initialized
INFO - 2017-05-24 10:41:07 --> Form Validation Class Initialized
INFO - 2017-05-24 10:41:07 --> Jquery Class Initialized
INFO - 2017-05-24 10:41:07 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:41:07 --> Config Class Initialized
INFO - 2017-05-24 10:41:07 --> Upload Class Initialized
INFO - 2017-05-24 10:41:07 --> Hooks Class Initialized
INFO - 2017-05-24 10:41:07 --> Language file loaded: language/english/common_lang.php
DEBUG - 2017-05-24 10:41:07 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:41:07 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:41:07 --> Utf8 Class Initialized
INFO - 2017-05-24 10:41:07 --> URI Class Initialized
INFO - 2017-05-24 10:41:07 --> Router Class Initialized
INFO - 2017-05-24 10:41:07 --> Output Class Initialized
INFO - 2017-05-24 10:41:07 --> Security Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:41:07 --> Input Class Initialized
INFO - 2017-05-24 10:41:07 --> Language Class Initialized
INFO - 2017-05-24 10:41:07 --> Loader Class Initialized
INFO - 2017-05-24 10:41:07 --> Controller Class Initialized
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
INFO - 2017-05-24 10:41:07 --> Database Driver Class Initialized
INFO - 2017-05-24 10:41:07 --> Helper loaded: file_helper
INFO - 2017-05-24 10:41:07 --> Helper loaded: date_helper
INFO - 2017-05-24 10:41:07 --> Final output sent to browser
DEBUG - 2017-05-24 10:41:07 --> Total execution time: 1.4427
INFO - 2017-05-24 10:41:07 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:08 --> Helper loaded: url_helper
INFO - 2017-05-24 10:41:08 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:41:08 --> Pagination Class Initialized
INFO - 2017-05-24 10:41:08 --> Form Validation Class Initialized
INFO - 2017-05-24 10:41:08 --> Jquery Class Initialized
INFO - 2017-05-24 10:41:08 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:41:08 --> Upload Class Initialized
INFO - 2017-05-24 10:41:08 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:41:08 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:41:08 --> Final output sent to browser
DEBUG - 2017-05-24 10:41:08 --> Total execution time: 1.4067
INFO - 2017-05-24 10:41:11 --> Config Class Initialized
INFO - 2017-05-24 10:41:11 --> Hooks Class Initialized
INFO - 2017-05-24 10:41:11 --> Config Class Initialized
DEBUG - 2017-05-24 10:41:12 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:41:12 --> Hooks Class Initialized
INFO - 2017-05-24 10:41:12 --> Utf8 Class Initialized
DEBUG - 2017-05-24 10:41:12 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:41:12 --> URI Class Initialized
INFO - 2017-05-24 10:41:12 --> Utf8 Class Initialized
INFO - 2017-05-24 10:41:12 --> URI Class Initialized
INFO - 2017-05-24 10:41:12 --> Router Class Initialized
INFO - 2017-05-24 10:41:12 --> Router Class Initialized
INFO - 2017-05-24 10:41:12 --> Output Class Initialized
INFO - 2017-05-24 10:41:12 --> Output Class Initialized
INFO - 2017-05-24 10:41:12 --> Security Class Initialized
INFO - 2017-05-24 10:41:12 --> Security Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 10:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:41:12 --> Input Class Initialized
INFO - 2017-05-24 10:41:12 --> Input Class Initialized
INFO - 2017-05-24 10:41:12 --> Language Class Initialized
INFO - 2017-05-24 10:41:12 --> Language Class Initialized
INFO - 2017-05-24 10:41:12 --> Loader Class Initialized
INFO - 2017-05-24 10:41:12 --> Loader Class Initialized
INFO - 2017-05-24 10:41:12 --> Controller Class Initialized
INFO - 2017-05-24 10:41:12 --> Controller Class Initialized
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
INFO - 2017-05-24 10:41:12 --> Database Driver Class Initialized
INFO - 2017-05-24 10:41:12 --> Database Driver Class Initialized
INFO - 2017-05-24 10:41:12 --> Helper loaded: file_helper
INFO - 2017-05-24 10:41:12 --> Helper loaded: file_helper
INFO - 2017-05-24 10:41:12 --> Helper loaded: date_helper
INFO - 2017-05-24 10:41:12 --> Helper loaded: date_helper
INFO - 2017-05-24 10:41:12 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:12 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:13 --> Helper loaded: url_helper
INFO - 2017-05-24 10:41:13 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:41:13 --> Pagination Class Initialized
INFO - 2017-05-24 10:41:13 --> Form Validation Class Initialized
INFO - 2017-05-24 10:41:13 --> Jquery Class Initialized
INFO - 2017-05-24 10:41:13 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:41:13 --> Upload Class Initialized
INFO - 2017-05-24 10:41:13 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:41:13 --> Language file loaded: language/english/accounttype_lang.php
ERROR - 2017-05-24 10:41:13 --> Query error: Duplicate entry 'P00016360' for key 'patient_code' - Invalid query: INSERT INTO `emedirec_1_patient` (`patient_code`, `patient_kh_name`, `patient_en_name`, `patient_gender`, `patient_phone`, `patient_emergency_phone`, `patient_dob`, `patient_occupation`, `is_heart`, `is_respiratory`, `is_diabetes`, `is_digestive`, `is_kidney`, `is_endocrine`, `is_neuro_sys`, `is_lung`, `is_allergy`, `pulse_mm`, `heart_rate_mm`, `blood_pressure_mm`, `respirateory_rate_mm`, `temperature_mm`, `patient_id_card`, `patient_id_poor`, `patient_inssurance`, `patient_assurance_card`, `patient_assurance_company`, `patient_motor_card`, `patient_car_card`, `patient_bank_card1`, `patient_bank_card2`, `patient_student_card`, `patient_status`, `patient_pregnancy`, `patient_pre_pregnancy`, `patient_breastfeeding`, `patient_disease`, `patient_desc`, `patient_district`, `patient_province`, `patient_ready`) VALUES ('P00016360', 'patient name', '', 'f', '12389', '', '2017-05-17', 'occupation', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '', '', '', '', '0', '0', '', '', '', '', '', '', '', '0', '', '', '', '', 'history', '5', '2', '0')
INFO - 2017-05-24 10:41:13 --> Language file loaded: language/english/db_lang.php
INFO - 2017-05-24 10:41:13 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:41:13 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:13 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Helper loaded: url_helper
INFO - 2017-05-24 10:41:14 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:41:14 --> Pagination Class Initialized
INFO - 2017-05-24 10:41:14 --> Form Validation Class Initialized
INFO - 2017-05-24 10:41:14 --> Jquery Class Initialized
INFO - 2017-05-24 10:41:14 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:41:14 --> Upload Class Initialized
INFO - 2017-05-24 10:41:14 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:41:14 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:41:14 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 10:41:14 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 10:41:14 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 10:41:14 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 10:41:14 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 10:41:15 --> Final output sent to browser
DEBUG - 2017-05-24 10:41:15 --> Total execution time: 3.0318
INFO - 2017-05-24 10:41:15 --> Config Class Initialized
INFO - 2017-05-24 10:41:15 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:41:15 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:41:15 --> Utf8 Class Initialized
INFO - 2017-05-24 10:41:15 --> URI Class Initialized
INFO - 2017-05-24 10:41:15 --> Router Class Initialized
INFO - 2017-05-24 10:41:15 --> Output Class Initialized
INFO - 2017-05-24 10:41:15 --> Security Class Initialized
DEBUG - 2017-05-24 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:41:15 --> Input Class Initialized
INFO - 2017-05-24 10:41:15 --> Language Class Initialized
INFO - 2017-05-24 10:41:15 --> Loader Class Initialized
INFO - 2017-05-24 10:41:15 --> Controller Class Initialized
INFO - 2017-05-24 10:41:15 --> Model Class Initialized
INFO - 2017-05-24 10:41:15 --> Database Driver Class Initialized
INFO - 2017-05-24 10:41:15 --> Helper loaded: file_helper
INFO - 2017-05-24 10:41:15 --> Helper loaded: date_helper
INFO - 2017-05-24 10:41:15 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:41:15 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:15 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:15 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Model Class Initialized
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Helper loaded: url_helper
INFO - 2017-05-24 10:41:16 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:41:16 --> Pagination Class Initialized
INFO - 2017-05-24 10:41:16 --> Form Validation Class Initialized
INFO - 2017-05-24 10:41:16 --> Jquery Class Initialized
INFO - 2017-05-24 10:41:16 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:41:16 --> Upload Class Initialized
INFO - 2017-05-24 10:41:16 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:41:16 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:41:17 --> Final output sent to browser
DEBUG - 2017-05-24 10:41:17 --> Total execution time: 1.5223
INFO - 2017-05-24 10:45:49 --> Config Class Initialized
INFO - 2017-05-24 10:45:49 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:45:49 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:45:49 --> Utf8 Class Initialized
INFO - 2017-05-24 10:45:49 --> URI Class Initialized
INFO - 2017-05-24 10:45:49 --> Router Class Initialized
INFO - 2017-05-24 10:45:49 --> Output Class Initialized
INFO - 2017-05-24 10:45:49 --> Security Class Initialized
DEBUG - 2017-05-24 10:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:45:49 --> Input Class Initialized
INFO - 2017-05-24 10:45:49 --> Language Class Initialized
INFO - 2017-05-24 10:45:49 --> Loader Class Initialized
INFO - 2017-05-24 10:45:49 --> Controller Class Initialized
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
INFO - 2017-05-24 10:45:50 --> Database Driver Class Initialized
INFO - 2017-05-24 10:45:50 --> Helper loaded: file_helper
INFO - 2017-05-24 10:45:50 --> Helper loaded: date_helper
INFO - 2017-05-24 10:45:50 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Helper loaded: url_helper
INFO - 2017-05-24 10:45:50 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:45:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:45:50 --> Pagination Class Initialized
INFO - 2017-05-24 10:45:50 --> Form Validation Class Initialized
INFO - 2017-05-24 10:45:50 --> Jquery Class Initialized
INFO - 2017-05-24 10:45:50 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:45:50 --> Upload Class Initialized
INFO - 2017-05-24 10:45:50 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:45:50 --> Language file loaded: language/english/accounttype_lang.php
ERROR - 2017-05-24 10:45:51 --> Query error: Column 'patient_kh_name' cannot be null - Invalid query: INSERT INTO `emedirec_1_patient` (`patient_code`, `patient_kh_name`, `patient_en_name`, `patient_gender`, `patient_phone`, `patient_emergency_phone`, `patient_dob`, `patient_occupation`, `is_heart`, `is_respiratory`, `is_diabetes`, `is_digestive`, `is_kidney`, `is_endocrine`, `is_neuro_sys`, `is_lung`, `is_allergy`, `pulse_mm`, `heart_rate_mm`, `blood_pressure_mm`, `respirateory_rate_mm`, `temperature_mm`, `patient_id_card`, `patient_id_poor`, `patient_inssurance`, `patient_assurance_card`, `patient_assurance_company`, `patient_motor_card`, `patient_car_card`, `patient_bank_card1`, `patient_bank_card2`, `patient_student_card`, `patient_status`, `patient_pregnancy`, `patient_pre_pregnancy`, `patient_breastfeeding`, `patient_disease`, `patient_desc`, `patient_district`, `patient_province`, `patient_ready`) VALUES ('P00016360', NULL, NULL, 'm', NULL, NULL, '1970-01-01', NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, '0')
INFO - 2017-05-24 10:45:51 --> Language file loaded: language/english/db_lang.php
INFO - 2017-05-24 10:50:32 --> Config Class Initialized
INFO - 2017-05-24 10:50:32 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:50:32 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:50:32 --> Utf8 Class Initialized
INFO - 2017-05-24 10:50:32 --> URI Class Initialized
INFO - 2017-05-24 10:50:32 --> Router Class Initialized
INFO - 2017-05-24 10:50:32 --> Output Class Initialized
INFO - 2017-05-24 10:50:32 --> Security Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:50:32 --> Input Class Initialized
INFO - 2017-05-24 10:50:32 --> Language Class Initialized
INFO - 2017-05-24 10:50:32 --> Loader Class Initialized
INFO - 2017-05-24 10:50:32 --> Controller Class Initialized
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
INFO - 2017-05-24 10:50:32 --> Database Driver Class Initialized
INFO - 2017-05-24 10:50:32 --> Helper loaded: file_helper
INFO - 2017-05-24 10:50:32 --> Helper loaded: date_helper
INFO - 2017-05-24 10:50:32 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:32 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:33 --> Helper loaded: url_helper
INFO - 2017-05-24 10:50:33 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:50:33 --> Pagination Class Initialized
INFO - 2017-05-24 10:50:33 --> Form Validation Class Initialized
INFO - 2017-05-24 10:50:33 --> Jquery Class Initialized
INFO - 2017-05-24 10:50:33 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:50:33 --> Upload Class Initialized
INFO - 2017-05-24 10:50:33 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:50:33 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:50:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 10:50:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 10:50:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 10:50:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 10:50:33 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 10:50:33 --> Final output sent to browser
DEBUG - 2017-05-24 10:50:33 --> Total execution time: 1.5003
INFO - 2017-05-24 10:50:34 --> Config Class Initialized
INFO - 2017-05-24 10:50:34 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:50:34 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:50:34 --> Utf8 Class Initialized
INFO - 2017-05-24 10:50:34 --> URI Class Initialized
INFO - 2017-05-24 10:50:34 --> Router Class Initialized
INFO - 2017-05-24 10:50:34 --> Output Class Initialized
INFO - 2017-05-24 10:50:34 --> Security Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:50:34 --> Input Class Initialized
INFO - 2017-05-24 10:50:34 --> Language Class Initialized
INFO - 2017-05-24 10:50:34 --> Loader Class Initialized
INFO - 2017-05-24 10:50:34 --> Controller Class Initialized
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
INFO - 2017-05-24 10:50:34 --> Database Driver Class Initialized
INFO - 2017-05-24 10:50:34 --> Helper loaded: file_helper
INFO - 2017-05-24 10:50:34 --> Helper loaded: date_helper
INFO - 2017-05-24 10:50:34 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:35 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:35 --> Helper loaded: url_helper
INFO - 2017-05-24 10:50:35 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:50:35 --> Pagination Class Initialized
INFO - 2017-05-24 10:50:35 --> Form Validation Class Initialized
INFO - 2017-05-24 10:50:35 --> Jquery Class Initialized
INFO - 2017-05-24 10:50:35 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:50:35 --> Upload Class Initialized
INFO - 2017-05-24 10:50:35 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:50:35 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:50:35 --> Final output sent to browser
DEBUG - 2017-05-24 10:50:35 --> Total execution time: 1.4227
INFO - 2017-05-24 10:50:47 --> Config Class Initialized
INFO - 2017-05-24 10:50:47 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:50:47 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:50:47 --> Utf8 Class Initialized
INFO - 2017-05-24 10:50:47 --> URI Class Initialized
INFO - 2017-05-24 10:50:47 --> Router Class Initialized
INFO - 2017-05-24 10:50:48 --> Output Class Initialized
INFO - 2017-05-24 10:50:48 --> Security Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:50:48 --> Input Class Initialized
INFO - 2017-05-24 10:50:48 --> Language Class Initialized
INFO - 2017-05-24 10:50:48 --> Loader Class Initialized
INFO - 2017-05-24 10:50:48 --> Controller Class Initialized
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
INFO - 2017-05-24 10:50:48 --> Database Driver Class Initialized
INFO - 2017-05-24 10:50:48 --> Helper loaded: file_helper
INFO - 2017-05-24 10:50:48 --> Helper loaded: date_helper
INFO - 2017-05-24 10:50:48 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Helper loaded: url_helper
INFO - 2017-05-24 10:50:48 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:50:48 --> Pagination Class Initialized
INFO - 2017-05-24 10:50:48 --> Form Validation Class Initialized
INFO - 2017-05-24 10:50:48 --> Jquery Class Initialized
INFO - 2017-05-24 10:50:48 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:50:48 --> Upload Class Initialized
INFO - 2017-05-24 10:50:48 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:50:48 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:50:49 --> Final output sent to browser
DEBUG - 2017-05-24 10:50:49 --> Total execution time: 1.2602
INFO - 2017-05-24 10:50:50 --> Config Class Initialized
INFO - 2017-05-24 10:50:50 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:50:50 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:50:50 --> Utf8 Class Initialized
INFO - 2017-05-24 10:50:50 --> URI Class Initialized
INFO - 2017-05-24 10:50:50 --> Router Class Initialized
INFO - 2017-05-24 10:50:50 --> Output Class Initialized
INFO - 2017-05-24 10:50:50 --> Security Class Initialized
DEBUG - 2017-05-24 10:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:50:50 --> Input Class Initialized
INFO - 2017-05-24 10:50:50 --> Language Class Initialized
INFO - 2017-05-24 10:50:50 --> Loader Class Initialized
INFO - 2017-05-24 10:50:50 --> Controller Class Initialized
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
INFO - 2017-05-24 10:50:50 --> Database Driver Class Initialized
INFO - 2017-05-24 10:50:50 --> Helper loaded: file_helper
INFO - 2017-05-24 10:50:50 --> Helper loaded: date_helper
INFO - 2017-05-24 10:50:50 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:50 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:51 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:51 --> Helper loaded: url_helper
INFO - 2017-05-24 10:50:51 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:50:51 --> Pagination Class Initialized
INFO - 2017-05-24 10:50:51 --> Form Validation Class Initialized
INFO - 2017-05-24 10:50:51 --> Jquery Class Initialized
INFO - 2017-05-24 10:50:51 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:50:51 --> Upload Class Initialized
INFO - 2017-05-24 10:50:51 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:50:51 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:50:51 --> Final output sent to browser
DEBUG - 2017-05-24 10:50:51 --> Total execution time: 1.3845
INFO - 2017-05-24 10:50:51 --> Config Class Initialized
INFO - 2017-05-24 10:50:51 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:50:51 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:50:51 --> Utf8 Class Initialized
INFO - 2017-05-24 10:50:51 --> URI Class Initialized
INFO - 2017-05-24 10:50:51 --> Router Class Initialized
INFO - 2017-05-24 10:50:51 --> Output Class Initialized
INFO - 2017-05-24 10:50:52 --> Security Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:50:52 --> Input Class Initialized
INFO - 2017-05-24 10:50:52 --> Language Class Initialized
INFO - 2017-05-24 10:50:52 --> Loader Class Initialized
INFO - 2017-05-24 10:50:52 --> Controller Class Initialized
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
INFO - 2017-05-24 10:50:52 --> Database Driver Class Initialized
INFO - 2017-05-24 10:50:52 --> Helper loaded: file_helper
INFO - 2017-05-24 10:50:52 --> Helper loaded: date_helper
INFO - 2017-05-24 10:50:52 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Model Class Initialized
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Helper loaded: url_helper
INFO - 2017-05-24 10:50:52 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:50:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:50:52 --> Pagination Class Initialized
INFO - 2017-05-24 10:50:52 --> Form Validation Class Initialized
INFO - 2017-05-24 10:50:52 --> Jquery Class Initialized
INFO - 2017-05-24 10:50:52 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:50:52 --> Upload Class Initialized
INFO - 2017-05-24 10:50:52 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:50:52 --> Language file loaded: language/english/accounttype_lang.php
ERROR - 2017-05-24 10:50:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query:  SELECT  districts_name AS value FROM emedirec_1_districts WHERE  districts_deleted = 0 AND districts_name LIKE '%b%' AND provinces_id = 
INFO - 2017-05-24 10:50:53 --> Language file loaded: language/english/db_lang.php
INFO - 2017-05-24 10:51:01 --> Config Class Initialized
INFO - 2017-05-24 10:51:01 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:51:01 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:51:01 --> Utf8 Class Initialized
INFO - 2017-05-24 10:51:01 --> URI Class Initialized
INFO - 2017-05-24 10:51:01 --> Router Class Initialized
INFO - 2017-05-24 10:51:01 --> Output Class Initialized
INFO - 2017-05-24 10:51:01 --> Security Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:51:01 --> Input Class Initialized
INFO - 2017-05-24 10:51:01 --> Language Class Initialized
INFO - 2017-05-24 10:51:01 --> Loader Class Initialized
INFO - 2017-05-24 10:51:01 --> Controller Class Initialized
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
INFO - 2017-05-24 10:51:01 --> Database Driver Class Initialized
INFO - 2017-05-24 10:51:01 --> Helper loaded: file_helper
INFO - 2017-05-24 10:51:01 --> Helper loaded: date_helper
INFO - 2017-05-24 10:51:01 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Helper loaded: url_helper
INFO - 2017-05-24 10:51:01 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:51:02 --> Pagination Class Initialized
INFO - 2017-05-24 10:51:02 --> Form Validation Class Initialized
INFO - 2017-05-24 10:51:02 --> Jquery Class Initialized
INFO - 2017-05-24 10:51:02 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:51:02 --> Upload Class Initialized
INFO - 2017-05-24 10:51:02 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:51:02 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:51:02 --> Config Class Initialized
INFO - 2017-05-24 10:51:02 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:51:02 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:51:02 --> Utf8 Class Initialized
INFO - 2017-05-24 10:51:02 --> URI Class Initialized
INFO - 2017-05-24 10:51:02 --> Router Class Initialized
INFO - 2017-05-24 10:51:02 --> Output Class Initialized
INFO - 2017-05-24 10:51:02 --> Security Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:51:02 --> Input Class Initialized
INFO - 2017-05-24 10:51:02 --> Language Class Initialized
INFO - 2017-05-24 10:51:02 --> Loader Class Initialized
INFO - 2017-05-24 10:51:02 --> Controller Class Initialized
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
INFO - 2017-05-24 10:51:02 --> Final output sent to browser
INFO - 2017-05-24 10:51:02 --> Database Driver Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Total execution time: 1.4091
INFO - 2017-05-24 10:51:02 --> Helper loaded: file_helper
INFO - 2017-05-24 10:51:02 --> Helper loaded: date_helper
INFO - 2017-05-24 10:51:02 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:02 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:03 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:03 --> Helper loaded: url_helper
INFO - 2017-05-24 10:51:03 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:51:03 --> Pagination Class Initialized
INFO - 2017-05-24 10:51:03 --> Form Validation Class Initialized
INFO - 2017-05-24 10:51:03 --> Jquery Class Initialized
INFO - 2017-05-24 10:51:03 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:51:03 --> Upload Class Initialized
INFO - 2017-05-24 10:51:03 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:51:03 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:51:03 --> Final output sent to browser
DEBUG - 2017-05-24 10:51:03 --> Total execution time: 1.4048
INFO - 2017-05-24 10:51:04 --> Config Class Initialized
INFO - 2017-05-24 10:51:04 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:51:05 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:51:05 --> Utf8 Class Initialized
INFO - 2017-05-24 10:51:05 --> URI Class Initialized
INFO - 2017-05-24 10:51:05 --> Router Class Initialized
INFO - 2017-05-24 10:51:05 --> Output Class Initialized
INFO - 2017-05-24 10:51:05 --> Security Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:51:05 --> Input Class Initialized
INFO - 2017-05-24 10:51:05 --> Language Class Initialized
INFO - 2017-05-24 10:51:05 --> Loader Class Initialized
INFO - 2017-05-24 10:51:05 --> Controller Class Initialized
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
INFO - 2017-05-24 10:51:05 --> Database Driver Class Initialized
INFO - 2017-05-24 10:51:05 --> Helper loaded: file_helper
INFO - 2017-05-24 10:51:05 --> Helper loaded: date_helper
INFO - 2017-05-24 10:51:05 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Helper loaded: url_helper
INFO - 2017-05-24 10:51:05 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:51:05 --> Pagination Class Initialized
INFO - 2017-05-24 10:51:06 --> Form Validation Class Initialized
INFO - 2017-05-24 10:51:06 --> Jquery Class Initialized
INFO - 2017-05-24 10:51:06 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:51:06 --> Upload Class Initialized
INFO - 2017-05-24 10:51:06 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:51:06 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:51:06 --> Config Class Initialized
INFO - 2017-05-24 10:51:06 --> Hooks Class Initialized
INFO - 2017-05-24 10:51:06 --> Config Class Initialized
DEBUG - 2017-05-24 10:51:06 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:51:06 --> Hooks Class Initialized
INFO - 2017-05-24 10:51:06 --> Final output sent to browser
INFO - 2017-05-24 10:51:06 --> Utf8 Class Initialized
DEBUG - 2017-05-24 10:51:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 10:51:06 --> Total execution time: 1.4774
INFO - 2017-05-24 10:51:06 --> URI Class Initialized
INFO - 2017-05-24 10:51:06 --> Utf8 Class Initialized
INFO - 2017-05-24 10:51:06 --> URI Class Initialized
INFO - 2017-05-24 10:51:06 --> Router Class Initialized
INFO - 2017-05-24 10:51:06 --> Router Class Initialized
INFO - 2017-05-24 10:51:06 --> Output Class Initialized
INFO - 2017-05-24 10:51:06 --> Output Class Initialized
INFO - 2017-05-24 10:51:06 --> Security Class Initialized
INFO - 2017-05-24 10:51:06 --> Security Class Initialized
DEBUG - 2017-05-24 10:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 10:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:51:06 --> Input Class Initialized
INFO - 2017-05-24 10:51:06 --> Input Class Initialized
INFO - 2017-05-24 10:51:06 --> Language Class Initialized
INFO - 2017-05-24 10:51:06 --> Language Class Initialized
INFO - 2017-05-24 10:51:06 --> Loader Class Initialized
INFO - 2017-05-24 10:51:06 --> Loader Class Initialized
INFO - 2017-05-24 10:51:06 --> Controller Class Initialized
INFO - 2017-05-24 10:51:06 --> Controller Class Initialized
INFO - 2017-05-24 10:51:06 --> Model Class Initialized
INFO - 2017-05-24 10:51:06 --> Model Class Initialized
INFO - 2017-05-24 10:51:06 --> Database Driver Class Initialized
INFO - 2017-05-24 10:51:06 --> Database Driver Class Initialized
INFO - 2017-05-24 10:51:06 --> Helper loaded: file_helper
INFO - 2017-05-24 10:51:06 --> Helper loaded: file_helper
INFO - 2017-05-24 10:51:06 --> Helper loaded: date_helper
INFO - 2017-05-24 10:51:06 --> Helper loaded: date_helper
INFO - 2017-05-24 10:51:06 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:51:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Helper loaded: url_helper
INFO - 2017-05-24 10:51:07 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:51:07 --> Pagination Class Initialized
INFO - 2017-05-24 10:51:07 --> Form Validation Class Initialized
INFO - 2017-05-24 10:51:07 --> Jquery Class Initialized
INFO - 2017-05-24 10:51:07 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:51:07 --> Upload Class Initialized
INFO - 2017-05-24 10:51:07 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:51:07 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:51:08 --> Final output sent to browser
DEBUG - 2017-05-24 10:51:08 --> Total execution time: 1.8613
INFO - 2017-05-24 10:51:08 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Helper loaded: url_helper
INFO - 2017-05-24 10:51:08 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:51:08 --> Pagination Class Initialized
INFO - 2017-05-24 10:51:08 --> Form Validation Class Initialized
INFO - 2017-05-24 10:51:08 --> Jquery Class Initialized
INFO - 2017-05-24 10:51:08 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:51:09 --> Upload Class Initialized
INFO - 2017-05-24 10:51:09 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:51:09 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:51:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 10:51:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 10:51:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 10:51:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 10:51:09 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 10:51:09 --> Final output sent to browser
DEBUG - 2017-05-24 10:51:09 --> Total execution time: 2.9728
INFO - 2017-05-24 10:51:09 --> Config Class Initialized
INFO - 2017-05-24 10:51:09 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:51:09 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:51:09 --> Utf8 Class Initialized
INFO - 2017-05-24 10:51:09 --> URI Class Initialized
INFO - 2017-05-24 10:51:10 --> Router Class Initialized
INFO - 2017-05-24 10:51:10 --> Output Class Initialized
INFO - 2017-05-24 10:51:10 --> Security Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:51:10 --> Input Class Initialized
INFO - 2017-05-24 10:51:10 --> Language Class Initialized
INFO - 2017-05-24 10:51:10 --> Loader Class Initialized
INFO - 2017-05-24 10:51:10 --> Controller Class Initialized
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
INFO - 2017-05-24 10:51:10 --> Database Driver Class Initialized
INFO - 2017-05-24 10:51:10 --> Helper loaded: file_helper
INFO - 2017-05-24 10:51:10 --> Helper loaded: date_helper
INFO - 2017-05-24 10:51:10 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Model Class Initialized
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Helper loaded: url_helper
INFO - 2017-05-24 10:51:10 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:51:10 --> Pagination Class Initialized
INFO - 2017-05-24 10:51:10 --> Form Validation Class Initialized
INFO - 2017-05-24 10:51:10 --> Jquery Class Initialized
INFO - 2017-05-24 10:51:10 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:51:10 --> Upload Class Initialized
INFO - 2017-05-24 10:51:10 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:51:11 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:51:11 --> Final output sent to browser
DEBUG - 2017-05-24 10:51:11 --> Total execution time: 1.3955
INFO - 2017-05-24 10:54:23 --> Config Class Initialized
INFO - 2017-05-24 10:54:23 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:54:23 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:54:23 --> Utf8 Class Initialized
INFO - 2017-05-24 10:54:23 --> URI Class Initialized
INFO - 2017-05-24 10:54:23 --> Router Class Initialized
INFO - 2017-05-24 10:54:23 --> Output Class Initialized
INFO - 2017-05-24 10:54:23 --> Security Class Initialized
DEBUG - 2017-05-24 10:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:54:23 --> Input Class Initialized
INFO - 2017-05-24 10:54:23 --> Language Class Initialized
INFO - 2017-05-24 10:54:23 --> Loader Class Initialized
INFO - 2017-05-24 10:54:23 --> Controller Class Initialized
INFO - 2017-05-24 10:54:23 --> Model Class Initialized
INFO - 2017-05-24 10:54:23 --> Database Driver Class Initialized
INFO - 2017-05-24 10:54:23 --> Helper loaded: file_helper
INFO - 2017-05-24 10:54:23 --> Helper loaded: date_helper
INFO - 2017-05-24 10:54:23 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Helper loaded: url_helper
INFO - 2017-05-24 10:54:24 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:54:24 --> Pagination Class Initialized
INFO - 2017-05-24 10:54:24 --> Form Validation Class Initialized
INFO - 2017-05-24 10:54:24 --> Jquery Class Initialized
INFO - 2017-05-24 10:54:24 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:54:24 --> Upload Class Initialized
INFO - 2017-05-24 10:54:24 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:54:24 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:54:24 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 10:54:24 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 10:54:24 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 10:54:24 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list_visited.php
INFO - 2017-05-24 10:54:24 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 10:54:24 --> Final output sent to browser
DEBUG - 2017-05-24 10:54:25 --> Total execution time: 1.4148
INFO - 2017-05-24 10:54:25 --> Config Class Initialized
INFO - 2017-05-24 10:54:25 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:54:25 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:54:25 --> Utf8 Class Initialized
INFO - 2017-05-24 10:54:25 --> URI Class Initialized
INFO - 2017-05-24 10:54:25 --> Router Class Initialized
INFO - 2017-05-24 10:54:25 --> Output Class Initialized
INFO - 2017-05-24 10:54:25 --> Security Class Initialized
DEBUG - 2017-05-24 10:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:54:25 --> Input Class Initialized
INFO - 2017-05-24 10:54:25 --> Language Class Initialized
INFO - 2017-05-24 10:54:25 --> Loader Class Initialized
INFO - 2017-05-24 10:54:25 --> Controller Class Initialized
INFO - 2017-05-24 10:54:25 --> Model Class Initialized
INFO - 2017-05-24 10:54:25 --> Database Driver Class Initialized
INFO - 2017-05-24 10:54:25 --> Helper loaded: file_helper
INFO - 2017-05-24 10:54:25 --> Helper loaded: date_helper
INFO - 2017-05-24 10:54:25 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:54:25 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:25 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:25 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Helper loaded: url_helper
INFO - 2017-05-24 10:54:26 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:54:26 --> Pagination Class Initialized
INFO - 2017-05-24 10:54:26 --> Form Validation Class Initialized
INFO - 2017-05-24 10:54:26 --> Jquery Class Initialized
INFO - 2017-05-24 10:54:26 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:54:26 --> Upload Class Initialized
INFO - 2017-05-24 10:54:26 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:54:26 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:54:26 --> Final output sent to browser
DEBUG - 2017-05-24 10:54:26 --> Total execution time: 1.5265
INFO - 2017-05-24 10:54:27 --> Config Class Initialized
INFO - 2017-05-24 10:54:27 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:54:27 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:54:27 --> Utf8 Class Initialized
INFO - 2017-05-24 10:54:27 --> URI Class Initialized
INFO - 2017-05-24 10:54:27 --> Router Class Initialized
INFO - 2017-05-24 10:54:27 --> Output Class Initialized
INFO - 2017-05-24 10:54:27 --> Security Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:54:28 --> Input Class Initialized
INFO - 2017-05-24 10:54:28 --> Language Class Initialized
INFO - 2017-05-24 10:54:28 --> Loader Class Initialized
INFO - 2017-05-24 10:54:28 --> Controller Class Initialized
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
INFO - 2017-05-24 10:54:28 --> Database Driver Class Initialized
INFO - 2017-05-24 10:54:28 --> Helper loaded: file_helper
INFO - 2017-05-24 10:54:28 --> Helper loaded: date_helper
INFO - 2017-05-24 10:54:28 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Helper loaded: url_helper
INFO - 2017-05-24 10:54:28 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:54:28 --> Pagination Class Initialized
INFO - 2017-05-24 10:54:28 --> Form Validation Class Initialized
INFO - 2017-05-24 10:54:28 --> Jquery Class Initialized
INFO - 2017-05-24 10:54:28 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:54:28 --> Upload Class Initialized
INFO - 2017-05-24 10:54:28 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:54:28 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:54:29 --> Final output sent to browser
DEBUG - 2017-05-24 10:54:29 --> Total execution time: 1.3012
INFO - 2017-05-24 10:54:29 --> Config Class Initialized
INFO - 2017-05-24 10:54:29 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:54:29 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:54:29 --> Utf8 Class Initialized
INFO - 2017-05-24 10:54:29 --> URI Class Initialized
INFO - 2017-05-24 10:54:29 --> Router Class Initialized
INFO - 2017-05-24 10:54:29 --> Output Class Initialized
INFO - 2017-05-24 10:54:29 --> Security Class Initialized
DEBUG - 2017-05-24 10:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:54:29 --> Input Class Initialized
INFO - 2017-05-24 10:54:29 --> Language Class Initialized
INFO - 2017-05-24 10:54:29 --> Loader Class Initialized
INFO - 2017-05-24 10:54:29 --> Controller Class Initialized
INFO - 2017-05-24 10:54:29 --> Model Class Initialized
INFO - 2017-05-24 10:54:29 --> Database Driver Class Initialized
INFO - 2017-05-24 10:54:29 --> Helper loaded: file_helper
INFO - 2017-05-24 10:54:29 --> Helper loaded: date_helper
INFO - 2017-05-24 10:54:29 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:54:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:29 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Helper loaded: url_helper
INFO - 2017-05-24 10:54:30 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:54:30 --> Pagination Class Initialized
INFO - 2017-05-24 10:54:30 --> Form Validation Class Initialized
INFO - 2017-05-24 10:54:30 --> Jquery Class Initialized
INFO - 2017-05-24 10:54:30 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:54:30 --> Upload Class Initialized
INFO - 2017-05-24 10:54:30 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:54:30 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:54:30 --> Final output sent to browser
DEBUG - 2017-05-24 10:54:30 --> Total execution time: 1.3341
INFO - 2017-05-24 10:54:53 --> Config Class Initialized
INFO - 2017-05-24 10:54:53 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:54:53 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:54:53 --> Utf8 Class Initialized
INFO - 2017-05-24 10:54:53 --> URI Class Initialized
INFO - 2017-05-24 10:54:53 --> Router Class Initialized
INFO - 2017-05-24 10:54:53 --> Output Class Initialized
INFO - 2017-05-24 10:54:53 --> Security Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:54:53 --> Input Class Initialized
INFO - 2017-05-24 10:54:53 --> Language Class Initialized
INFO - 2017-05-24 10:54:53 --> Loader Class Initialized
INFO - 2017-05-24 10:54:53 --> Controller Class Initialized
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
INFO - 2017-05-24 10:54:53 --> Database Driver Class Initialized
INFO - 2017-05-24 10:54:53 --> Helper loaded: file_helper
INFO - 2017-05-24 10:54:53 --> Helper loaded: date_helper
INFO - 2017-05-24 10:54:53 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Model Class Initialized
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Helper loaded: url_helper
INFO - 2017-05-24 10:54:53 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:54:53 --> Pagination Class Initialized
INFO - 2017-05-24 10:54:54 --> Form Validation Class Initialized
INFO - 2017-05-24 10:54:54 --> Jquery Class Initialized
INFO - 2017-05-24 10:54:54 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:54:54 --> Upload Class Initialized
INFO - 2017-05-24 10:54:54 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:54:54 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:54:54 --> Final output sent to browser
DEBUG - 2017-05-24 10:54:54 --> Total execution time: 1.3300
INFO - 2017-05-24 10:55:04 --> Config Class Initialized
INFO - 2017-05-24 10:55:04 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:55:04 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:55:04 --> Utf8 Class Initialized
INFO - 2017-05-24 10:55:04 --> URI Class Initialized
INFO - 2017-05-24 10:55:04 --> Router Class Initialized
INFO - 2017-05-24 10:55:04 --> Output Class Initialized
INFO - 2017-05-24 10:55:04 --> Security Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:55:04 --> Input Class Initialized
INFO - 2017-05-24 10:55:04 --> Language Class Initialized
INFO - 2017-05-24 10:55:04 --> Loader Class Initialized
INFO - 2017-05-24 10:55:04 --> Controller Class Initialized
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
INFO - 2017-05-24 10:55:04 --> Database Driver Class Initialized
INFO - 2017-05-24 10:55:04 --> Helper loaded: file_helper
INFO - 2017-05-24 10:55:04 --> Helper loaded: date_helper
INFO - 2017-05-24 10:55:04 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:04 --> Helper loaded: url_helper
INFO - 2017-05-24 10:55:04 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:55:05 --> Pagination Class Initialized
INFO - 2017-05-24 10:55:05 --> Form Validation Class Initialized
INFO - 2017-05-24 10:55:05 --> Jquery Class Initialized
INFO - 2017-05-24 10:55:05 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:55:05 --> Upload Class Initialized
INFO - 2017-05-24 10:55:05 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:55:05 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:55:05 --> Final output sent to browser
DEBUG - 2017-05-24 10:55:05 --> Total execution time: 1.5743
INFO - 2017-05-24 10:55:05 --> Config Class Initialized
INFO - 2017-05-24 10:55:05 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:55:05 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:55:05 --> Utf8 Class Initialized
INFO - 2017-05-24 10:55:05 --> URI Class Initialized
INFO - 2017-05-24 10:55:05 --> Router Class Initialized
INFO - 2017-05-24 10:55:05 --> Output Class Initialized
INFO - 2017-05-24 10:55:05 --> Security Class Initialized
DEBUG - 2017-05-24 10:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:55:05 --> Input Class Initialized
INFO - 2017-05-24 10:55:05 --> Language Class Initialized
INFO - 2017-05-24 10:55:05 --> Loader Class Initialized
INFO - 2017-05-24 10:55:05 --> Controller Class Initialized
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
INFO - 2017-05-24 10:55:06 --> Database Driver Class Initialized
INFO - 2017-05-24 10:55:06 --> Helper loaded: file_helper
INFO - 2017-05-24 10:55:06 --> Helper loaded: date_helper
INFO - 2017-05-24 10:55:06 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Helper loaded: url_helper
INFO - 2017-05-24 10:55:06 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:55:06 --> Pagination Class Initialized
INFO - 2017-05-24 10:55:06 --> Form Validation Class Initialized
INFO - 2017-05-24 10:55:06 --> Jquery Class Initialized
INFO - 2017-05-24 10:55:06 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:55:06 --> Upload Class Initialized
INFO - 2017-05-24 10:55:06 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:55:06 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:55:07 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 10:55:07 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 10:55:07 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 10:55:07 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/visitors/list.php
INFO - 2017-05-24 10:55:07 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 10:55:07 --> Final output sent to browser
DEBUG - 2017-05-24 10:55:07 --> Total execution time: 1.5028
INFO - 2017-05-24 10:55:07 --> Config Class Initialized
INFO - 2017-05-24 10:55:07 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:55:07 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:55:07 --> Utf8 Class Initialized
INFO - 2017-05-24 10:55:07 --> URI Class Initialized
INFO - 2017-05-24 10:55:07 --> Router Class Initialized
INFO - 2017-05-24 10:55:07 --> Output Class Initialized
INFO - 2017-05-24 10:55:07 --> Security Class Initialized
DEBUG - 2017-05-24 10:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:55:07 --> Input Class Initialized
INFO - 2017-05-24 10:55:07 --> Language Class Initialized
INFO - 2017-05-24 10:55:07 --> Loader Class Initialized
INFO - 2017-05-24 10:55:08 --> Controller Class Initialized
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
INFO - 2017-05-24 10:55:08 --> Database Driver Class Initialized
INFO - 2017-05-24 10:55:08 --> Helper loaded: file_helper
INFO - 2017-05-24 10:55:08 --> Helper loaded: date_helper
INFO - 2017-05-24 10:55:08 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Model Class Initialized
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Helper loaded: url_helper
INFO - 2017-05-24 10:55:08 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:55:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:55:08 --> Pagination Class Initialized
INFO - 2017-05-24 10:55:08 --> Form Validation Class Initialized
INFO - 2017-05-24 10:55:08 --> Jquery Class Initialized
INFO - 2017-05-24 10:55:08 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:55:08 --> Upload Class Initialized
INFO - 2017-05-24 10:55:08 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:55:08 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:55:09 --> Final output sent to browser
DEBUG - 2017-05-24 10:55:09 --> Total execution time: 1.4043
INFO - 2017-05-24 10:59:55 --> Config Class Initialized
INFO - 2017-05-24 10:59:55 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:59:55 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:59:55 --> Utf8 Class Initialized
INFO - 2017-05-24 10:59:55 --> URI Class Initialized
INFO - 2017-05-24 10:59:55 --> Router Class Initialized
INFO - 2017-05-24 10:59:55 --> Output Class Initialized
INFO - 2017-05-24 10:59:55 --> Security Class Initialized
DEBUG - 2017-05-24 10:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:59:55 --> Input Class Initialized
INFO - 2017-05-24 10:59:55 --> Language Class Initialized
INFO - 2017-05-24 10:59:55 --> Loader Class Initialized
INFO - 2017-05-24 10:59:55 --> Controller Class Initialized
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
INFO - 2017-05-24 10:59:56 --> Database Driver Class Initialized
INFO - 2017-05-24 10:59:56 --> Helper loaded: file_helper
INFO - 2017-05-24 10:59:56 --> Helper loaded: date_helper
INFO - 2017-05-24 10:59:56 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Helper loaded: url_helper
INFO - 2017-05-24 10:59:56 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:59:56 --> Pagination Class Initialized
INFO - 2017-05-24 10:59:56 --> Form Validation Class Initialized
INFO - 2017-05-24 10:59:56 --> Jquery Class Initialized
INFO - 2017-05-24 10:59:56 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:59:56 --> Upload Class Initialized
INFO - 2017-05-24 10:59:56 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:59:56 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:59:57 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 10:59:57 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 10:59:57 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 10:59:57 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/visitors/list.php
INFO - 2017-05-24 10:59:57 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 10:59:57 --> Final output sent to browser
DEBUG - 2017-05-24 10:59:57 --> Total execution time: 1.5440
INFO - 2017-05-24 10:59:57 --> Config Class Initialized
INFO - 2017-05-24 10:59:57 --> Hooks Class Initialized
DEBUG - 2017-05-24 10:59:57 --> UTF-8 Support Enabled
INFO - 2017-05-24 10:59:57 --> Utf8 Class Initialized
INFO - 2017-05-24 10:59:57 --> URI Class Initialized
INFO - 2017-05-24 10:59:57 --> Router Class Initialized
INFO - 2017-05-24 10:59:57 --> Output Class Initialized
INFO - 2017-05-24 10:59:57 --> Security Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 10:59:58 --> Input Class Initialized
INFO - 2017-05-24 10:59:58 --> Language Class Initialized
INFO - 2017-05-24 10:59:58 --> Loader Class Initialized
INFO - 2017-05-24 10:59:58 --> Controller Class Initialized
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
INFO - 2017-05-24 10:59:58 --> Database Driver Class Initialized
INFO - 2017-05-24 10:59:58 --> Helper loaded: file_helper
INFO - 2017-05-24 10:59:58 --> Helper loaded: date_helper
INFO - 2017-05-24 10:59:58 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Model Class Initialized
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Helper loaded: url_helper
INFO - 2017-05-24 10:59:58 --> Helper loaded: form_helper
DEBUG - 2017-05-24 10:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 10:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 10:59:58 --> Pagination Class Initialized
INFO - 2017-05-24 10:59:58 --> Form Validation Class Initialized
INFO - 2017-05-24 10:59:58 --> Jquery Class Initialized
INFO - 2017-05-24 10:59:58 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 10:59:58 --> Upload Class Initialized
INFO - 2017-05-24 10:59:58 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 10:59:58 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 10:59:59 --> Final output sent to browser
DEBUG - 2017-05-24 10:59:59 --> Total execution time: 1.4357
INFO - 2017-05-24 11:00:04 --> Config Class Initialized
INFO - 2017-05-24 11:00:04 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:04 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:04 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:04 --> URI Class Initialized
INFO - 2017-05-24 11:00:04 --> Router Class Initialized
INFO - 2017-05-24 11:00:04 --> Output Class Initialized
INFO - 2017-05-24 11:00:04 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:04 --> Input Class Initialized
INFO - 2017-05-24 11:00:04 --> Language Class Initialized
INFO - 2017-05-24 11:00:04 --> Loader Class Initialized
INFO - 2017-05-24 11:00:04 --> Controller Class Initialized
INFO - 2017-05-24 11:00:04 --> Model Class Initialized
INFO - 2017-05-24 11:00:04 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:04 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:04 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:04 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:04 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:04 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:04 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:04 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:04 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:04 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:04 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:05 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:05 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:05 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:05 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:05 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:05 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:05 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:05 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:05 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:05 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:05 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:05 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:05 --> Upload Class Initialized
INFO - 2017-05-24 11:00:05 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:05 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:05 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 11:00:05 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 11:00:05 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 11:00:05 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 11:00:05 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 11:00:05 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:06 --> Total execution time: 1.6115
INFO - 2017-05-24 11:00:06 --> Config Class Initialized
INFO - 2017-05-24 11:00:06 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:06 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:06 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:06 --> URI Class Initialized
INFO - 2017-05-24 11:00:06 --> Router Class Initialized
INFO - 2017-05-24 11:00:06 --> Output Class Initialized
INFO - 2017-05-24 11:00:06 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:06 --> Input Class Initialized
INFO - 2017-05-24 11:00:06 --> Language Class Initialized
INFO - 2017-05-24 11:00:06 --> Loader Class Initialized
INFO - 2017-05-24 11:00:06 --> Controller Class Initialized
INFO - 2017-05-24 11:00:06 --> Model Class Initialized
INFO - 2017-05-24 11:00:06 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:06 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:06 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:06 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:06 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:07 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:07 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:07 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:07 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:07 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:07 --> Upload Class Initialized
INFO - 2017-05-24 11:00:07 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:07 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:08 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:08 --> Total execution time: 1.5082
INFO - 2017-05-24 11:00:17 --> Config Class Initialized
INFO - 2017-05-24 11:00:18 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:18 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:18 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:18 --> URI Class Initialized
INFO - 2017-05-24 11:00:18 --> Router Class Initialized
INFO - 2017-05-24 11:00:18 --> Output Class Initialized
INFO - 2017-05-24 11:00:18 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:18 --> Input Class Initialized
INFO - 2017-05-24 11:00:18 --> Language Class Initialized
INFO - 2017-05-24 11:00:18 --> Loader Class Initialized
INFO - 2017-05-24 11:00:18 --> Controller Class Initialized
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
INFO - 2017-05-24 11:00:18 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:18 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:18 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:18 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:18 --> Config Class Initialized
INFO - 2017-05-24 11:00:18 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:18 --> Hooks Class Initialized
INFO - 2017-05-24 11:00:18 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:19 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:19 --> URI Class Initialized
INFO - 2017-05-24 11:00:19 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:19 --> Router Class Initialized
INFO - 2017-05-24 11:00:19 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:19 --> Output Class Initialized
INFO - 2017-05-24 11:00:19 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:19 --> Security Class Initialized
INFO - 2017-05-24 11:00:19 --> Javascript Class Initialized and loaded. Driver used: jquery
DEBUG - 2017-05-24 11:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:19 --> Upload Class Initialized
INFO - 2017-05-24 11:00:19 --> Input Class Initialized
INFO - 2017-05-24 11:00:19 --> Language Class Initialized
INFO - 2017-05-24 11:00:19 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:19 --> Loader Class Initialized
INFO - 2017-05-24 11:00:19 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:19 --> Controller Class Initialized
INFO - 2017-05-24 11:00:19 --> Model Class Initialized
INFO - 2017-05-24 11:00:19 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:19 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:19 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:19 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:19 --> Total execution time: 1.5824
INFO - 2017-05-24 11:00:19 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:19 --> Model Class Initialized
INFO - 2017-05-24 11:00:19 --> Config Class Initialized
DEBUG - 2017-05-24 11:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:19 --> Hooks Class Initialized
INFO - 2017-05-24 11:00:19 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-24 11:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:19 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:19 --> URI Class Initialized
INFO - 2017-05-24 11:00:19 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:19 --> Router Class Initialized
INFO - 2017-05-24 11:00:19 --> Model Class Initialized
INFO - 2017-05-24 11:00:19 --> Output Class Initialized
DEBUG - 2017-05-24 11:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:19 --> Security Class Initialized
INFO - 2017-05-24 11:00:19 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Input Class Initialized
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
INFO - 2017-05-24 11:00:20 --> Language Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Loader Class Initialized
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
INFO - 2017-05-24 11:00:20 --> Controller Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
INFO - 2017-05-24 11:00:20 --> Database Driver Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
INFO - 2017-05-24 11:00:20 --> Helper loaded: date_helper
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:20 --> Helper loaded: form_helper
INFO - 2017-05-24 11:00:20 --> Config Class Initialized
DEBUG - 2017-05-24 11:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:20 --> Hooks Class Initialized
INFO - 2017-05-24 11:00:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2017-05-24 11:00:20 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:20 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:20 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:20 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:20 --> URI Class Initialized
INFO - 2017-05-24 11:00:20 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:20 --> Router Class Initialized
INFO - 2017-05-24 11:00:20 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:20 --> Upload Class Initialized
INFO - 2017-05-24 11:00:20 --> Output Class Initialized
INFO - 2017-05-24 11:00:20 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:20 --> Security Class Initialized
INFO - 2017-05-24 11:00:20 --> Language file loaded: language/english/accounttype_lang.php
DEBUG - 2017-05-24 11:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:20 --> Input Class Initialized
INFO - 2017-05-24 11:00:20 --> Language Class Initialized
INFO - 2017-05-24 11:00:20 --> Loader Class Initialized
INFO - 2017-05-24 11:00:20 --> Controller Class Initialized
INFO - 2017-05-24 11:00:20 --> Model Class Initialized
INFO - 2017-05-24 11:00:20 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:20 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:21 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:21 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:21 --> Total execution time: 2.2199
INFO - 2017-05-24 11:00:21 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:21 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:21 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:21 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:21 --> Config Class Initialized
INFO - 2017-05-24 11:00:21 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:21 --> Hooks Class Initialized
INFO - 2017-05-24 11:00:21 --> Javascript Class Initialized and loaded. Driver used: jquery
DEBUG - 2017-05-24 11:00:21 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:21 --> Upload Class Initialized
INFO - 2017-05-24 11:00:21 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:22 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:22 --> URI Class Initialized
INFO - 2017-05-24 11:00:22 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:22 --> Router Class Initialized
INFO - 2017-05-24 11:00:22 --> Output Class Initialized
INFO - 2017-05-24 11:00:22 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:22 --> Input Class Initialized
INFO - 2017-05-24 11:00:22 --> Language Class Initialized
INFO - 2017-05-24 11:00:22 --> Loader Class Initialized
INFO - 2017-05-24 11:00:22 --> Controller Class Initialized
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
INFO - 2017-05-24 11:00:22 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:22 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:22 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:22 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:22 --> Total execution time: 2.6439
INFO - 2017-05-24 11:00:22 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:22 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:23 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:23 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:23 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:23 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:23 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:23 --> Upload Class Initialized
INFO - 2017-05-24 11:00:23 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:23 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:23 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:23 --> Total execution time: 3.0055
INFO - 2017-05-24 11:00:23 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:23 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:24 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:24 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:24 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:24 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:24 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:24 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:24 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:24 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:24 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:24 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:24 --> Upload Class Initialized
INFO - 2017-05-24 11:00:24 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:24 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:24 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:24 --> Total execution time: 2.7845
INFO - 2017-05-24 11:00:26 --> Config Class Initialized
INFO - 2017-05-24 11:00:26 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:26 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:26 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:26 --> URI Class Initialized
INFO - 2017-05-24 11:00:26 --> Router Class Initialized
INFO - 2017-05-24 11:00:26 --> Output Class Initialized
INFO - 2017-05-24 11:00:26 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:26 --> Input Class Initialized
INFO - 2017-05-24 11:00:26 --> Language Class Initialized
INFO - 2017-05-24 11:00:26 --> Loader Class Initialized
INFO - 2017-05-24 11:00:26 --> Controller Class Initialized
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
INFO - 2017-05-24 11:00:26 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:26 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:26 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:26 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:26 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:27 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:27 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:27 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:27 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:27 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:27 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:27 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:27 --> Upload Class Initialized
INFO - 2017-05-24 11:00:27 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:27 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:27 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:27 --> Total execution time: 1.5018
INFO - 2017-05-24 11:00:29 --> Config Class Initialized
INFO - 2017-05-24 11:00:29 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:29 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:29 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:29 --> URI Class Initialized
INFO - 2017-05-24 11:00:29 --> Router Class Initialized
INFO - 2017-05-24 11:00:29 --> Output Class Initialized
INFO - 2017-05-24 11:00:29 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:29 --> Input Class Initialized
INFO - 2017-05-24 11:00:29 --> Language Class Initialized
INFO - 2017-05-24 11:00:29 --> Loader Class Initialized
INFO - 2017-05-24 11:00:29 --> Controller Class Initialized
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
INFO - 2017-05-24 11:00:29 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:29 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:29 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:29 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:29 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:30 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:30 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:30 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:30 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:30 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:30 --> Upload Class Initialized
INFO - 2017-05-24 11:00:30 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:30 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:30 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:30 --> Total execution time: 1.4692
INFO - 2017-05-24 11:00:30 --> Config Class Initialized
INFO - 2017-05-24 11:00:30 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:30 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:30 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:30 --> URI Class Initialized
INFO - 2017-05-24 11:00:30 --> Router Class Initialized
INFO - 2017-05-24 11:00:30 --> Output Class Initialized
INFO - 2017-05-24 11:00:30 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:30 --> Input Class Initialized
INFO - 2017-05-24 11:00:31 --> Language Class Initialized
INFO - 2017-05-24 11:00:31 --> Loader Class Initialized
INFO - 2017-05-24 11:00:31 --> Controller Class Initialized
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
INFO - 2017-05-24 11:00:31 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:31 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:31 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:31 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:31 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:31 --> Config Class Initialized
INFO - 2017-05-24 11:00:31 --> Helper loaded: form_helper
INFO - 2017-05-24 11:00:31 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-24 11:00:31 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:31 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:31 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:31 --> URI Class Initialized
INFO - 2017-05-24 11:00:31 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:31 --> Router Class Initialized
INFO - 2017-05-24 11:00:31 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:31 --> Output Class Initialized
INFO - 2017-05-24 11:00:31 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:31 --> Security Class Initialized
INFO - 2017-05-24 11:00:32 --> Upload Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:32 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:32 --> Input Class Initialized
INFO - 2017-05-24 11:00:32 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:32 --> Language Class Initialized
INFO - 2017-05-24 11:00:32 --> Loader Class Initialized
INFO - 2017-05-24 11:00:32 --> Controller Class Initialized
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
INFO - 2017-05-24 11:00:32 --> Database Driver Class Initialized
ERROR - 2017-05-24 11:00:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query:  SELECT  districts_name AS value FROM emedirec_1_districts WHERE  districts_deleted = 0 AND provinces_id = 
INFO - 2017-05-24 11:00:32 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:32 --> Language file loaded: language/english/db_lang.php
INFO - 2017-05-24 11:00:32 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:32 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:32 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:32 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:33 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:33 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:33 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:33 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:33 --> Upload Class Initialized
INFO - 2017-05-24 11:00:33 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:33 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:33 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:33 --> Total execution time: 1.7002
INFO - 2017-05-24 11:00:36 --> Config Class Initialized
INFO - 2017-05-24 11:00:36 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:36 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:36 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:36 --> URI Class Initialized
INFO - 2017-05-24 11:00:36 --> Router Class Initialized
INFO - 2017-05-24 11:00:36 --> Output Class Initialized
INFO - 2017-05-24 11:00:36 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:36 --> Input Class Initialized
INFO - 2017-05-24 11:00:36 --> Language Class Initialized
INFO - 2017-05-24 11:00:36 --> Loader Class Initialized
INFO - 2017-05-24 11:00:36 --> Controller Class Initialized
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
INFO - 2017-05-24 11:00:36 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:36 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:36 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:36 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:36 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:37 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:37 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:37 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:37 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:37 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:37 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:37 --> Upload Class Initialized
INFO - 2017-05-24 11:00:37 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:37 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:37 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:37 --> Total execution time: 1.4236
INFO - 2017-05-24 11:00:37 --> Config Class Initialized
INFO - 2017-05-24 11:00:37 --> Hooks Class Initialized
INFO - 2017-05-24 11:00:37 --> Config Class Initialized
DEBUG - 2017-05-24 11:00:37 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:37 --> Hooks Class Initialized
INFO - 2017-05-24 11:00:37 --> Utf8 Class Initialized
DEBUG - 2017-05-24 11:00:37 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:37 --> URI Class Initialized
INFO - 2017-05-24 11:00:37 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:37 --> Router Class Initialized
INFO - 2017-05-24 11:00:37 --> URI Class Initialized
INFO - 2017-05-24 11:00:37 --> Output Class Initialized
INFO - 2017-05-24 11:00:37 --> Router Class Initialized
INFO - 2017-05-24 11:00:37 --> Security Class Initialized
INFO - 2017-05-24 11:00:37 --> Output Class Initialized
DEBUG - 2017-05-24 11:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:37 --> Security Class Initialized
INFO - 2017-05-24 11:00:37 --> Input Class Initialized
INFO - 2017-05-24 11:00:38 --> Language Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:38 --> Input Class Initialized
INFO - 2017-05-24 11:00:38 --> Loader Class Initialized
INFO - 2017-05-24 11:00:38 --> Controller Class Initialized
INFO - 2017-05-24 11:00:38 --> Language Class Initialized
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
INFO - 2017-05-24 11:00:38 --> Loader Class Initialized
INFO - 2017-05-24 11:00:38 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:38 --> Controller Class Initialized
INFO - 2017-05-24 11:00:38 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
INFO - 2017-05-24 11:00:38 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:38 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:38 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:38 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
INFO - 2017-05-24 11:00:38 --> Helper loaded: date_helper
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:38 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:39 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:39 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:39 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:39 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:39 --> Upload Class Initialized
INFO - 2017-05-24 11:00:39 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:39 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:39 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:39 --> Total execution time: 1.9790
INFO - 2017-05-24 11:00:39 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:39 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:39 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:39 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:39 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:39 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:40 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:40 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:40 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:40 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:40 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:40 --> Upload Class Initialized
INFO - 2017-05-24 11:00:40 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:40 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:40 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-24 11:00:40 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-24 11:00:40 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-24 11:00:40 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-24 11:00:40 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-24 11:00:40 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:40 --> Total execution time: 3.2045
INFO - 2017-05-24 11:00:41 --> Config Class Initialized
INFO - 2017-05-24 11:00:41 --> Hooks Class Initialized
DEBUG - 2017-05-24 11:00:41 --> UTF-8 Support Enabled
INFO - 2017-05-24 11:00:41 --> Utf8 Class Initialized
INFO - 2017-05-24 11:00:41 --> URI Class Initialized
INFO - 2017-05-24 11:00:41 --> Router Class Initialized
INFO - 2017-05-24 11:00:41 --> Output Class Initialized
INFO - 2017-05-24 11:00:41 --> Security Class Initialized
DEBUG - 2017-05-24 11:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-24 11:00:41 --> Input Class Initialized
INFO - 2017-05-24 11:00:41 --> Language Class Initialized
INFO - 2017-05-24 11:00:41 --> Loader Class Initialized
INFO - 2017-05-24 11:00:41 --> Controller Class Initialized
INFO - 2017-05-24 11:00:41 --> Model Class Initialized
INFO - 2017-05-24 11:00:41 --> Database Driver Class Initialized
INFO - 2017-05-24 11:00:41 --> Helper loaded: file_helper
INFO - 2017-05-24 11:00:41 --> Helper loaded: date_helper
INFO - 2017-05-24 11:00:41 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-24 11:00:41 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:41 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:41 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Model Class Initialized
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Helper loaded: url_helper
INFO - 2017-05-24 11:00:42 --> Helper loaded: form_helper
DEBUG - 2017-05-24 11:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-24 11:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-24 11:00:42 --> Pagination Class Initialized
INFO - 2017-05-24 11:00:42 --> Form Validation Class Initialized
INFO - 2017-05-24 11:00:42 --> Jquery Class Initialized
INFO - 2017-05-24 11:00:42 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-24 11:00:42 --> Upload Class Initialized
INFO - 2017-05-24 11:00:42 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-24 11:00:42 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-24 11:00:42 --> Final output sent to browser
DEBUG - 2017-05-24 11:00:42 --> Total execution time: 1.4947
