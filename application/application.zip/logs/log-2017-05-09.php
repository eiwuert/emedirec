<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-09 06:49:35 --> Config Class Initialized
INFO - 2017-05-09 06:49:35 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:49:35 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:49:35 --> Utf8 Class Initialized
INFO - 2017-05-09 06:49:35 --> URI Class Initialized
DEBUG - 2017-05-09 06:49:35 --> No URI present. Default controller set.
INFO - 2017-05-09 06:49:35 --> Router Class Initialized
INFO - 2017-05-09 06:49:35 --> Output Class Initialized
INFO - 2017-05-09 06:49:35 --> Security Class Initialized
DEBUG - 2017-05-09 06:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:49:35 --> Input Class Initialized
INFO - 2017-05-09 06:49:35 --> Language Class Initialized
INFO - 2017-05-09 06:49:35 --> Loader Class Initialized
INFO - 2017-05-09 06:49:35 --> Controller Class Initialized
INFO - 2017-05-09 06:49:35 --> Model Class Initialized
INFO - 2017-05-09 06:49:35 --> Database Driver Class Initialized
INFO - 2017-05-09 06:49:35 --> Helper loaded: file_helper
INFO - 2017-05-09 06:49:35 --> Helper loaded: date_helper
INFO - 2017-05-09 06:49:35 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:49:35 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:35 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:35 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:35 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:35 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:35 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Helper loaded: url_helper
INFO - 2017-05-09 06:49:36 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:49:36 --> Pagination Class Initialized
INFO - 2017-05-09 06:49:36 --> Form Validation Class Initialized
INFO - 2017-05-09 06:49:36 --> Jquery Class Initialized
INFO - 2017-05-09 06:49:36 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:49:36 --> Upload Class Initialized
INFO - 2017-05-09 06:49:36 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:49:36 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:49:36 --> Config Class Initialized
INFO - 2017-05-09 06:49:36 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:49:36 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:49:36 --> Utf8 Class Initialized
INFO - 2017-05-09 06:49:36 --> URI Class Initialized
INFO - 2017-05-09 06:49:36 --> Router Class Initialized
INFO - 2017-05-09 06:49:37 --> Output Class Initialized
INFO - 2017-05-09 06:49:37 --> Security Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:49:37 --> Input Class Initialized
INFO - 2017-05-09 06:49:37 --> Language Class Initialized
INFO - 2017-05-09 06:49:37 --> Loader Class Initialized
INFO - 2017-05-09 06:49:37 --> Controller Class Initialized
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
INFO - 2017-05-09 06:49:37 --> Database Driver Class Initialized
INFO - 2017-05-09 06:49:37 --> Helper loaded: file_helper
INFO - 2017-05-09 06:49:37 --> Helper loaded: date_helper
INFO - 2017-05-09 06:49:37 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:37 --> Helper loaded: url_helper
INFO - 2017-05-09 06:49:37 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:49:38 --> Pagination Class Initialized
INFO - 2017-05-09 06:49:38 --> Form Validation Class Initialized
INFO - 2017-05-09 06:49:38 --> Jquery Class Initialized
INFO - 2017-05-09 06:49:38 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:49:38 --> Upload Class Initialized
INFO - 2017-05-09 06:49:38 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:49:38 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:49:38 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/login.php
INFO - 2017-05-09 06:49:38 --> Final output sent to browser
DEBUG - 2017-05-09 06:49:38 --> Total execution time: 1.3901
INFO - 2017-05-09 06:49:46 --> Config Class Initialized
INFO - 2017-05-09 06:49:46 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:49:46 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:49:46 --> Utf8 Class Initialized
INFO - 2017-05-09 06:49:46 --> URI Class Initialized
INFO - 2017-05-09 06:49:46 --> Router Class Initialized
INFO - 2017-05-09 06:49:46 --> Output Class Initialized
INFO - 2017-05-09 06:49:46 --> Security Class Initialized
DEBUG - 2017-05-09 06:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:49:46 --> Input Class Initialized
INFO - 2017-05-09 06:49:46 --> Language Class Initialized
INFO - 2017-05-09 06:49:46 --> Loader Class Initialized
INFO - 2017-05-09 06:49:46 --> Controller Class Initialized
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
INFO - 2017-05-09 06:49:47 --> Database Driver Class Initialized
INFO - 2017-05-09 06:49:47 --> Helper loaded: file_helper
INFO - 2017-05-09 06:49:47 --> Helper loaded: date_helper
INFO - 2017-05-09 06:49:47 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Helper loaded: url_helper
INFO - 2017-05-09 06:49:47 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:49:47 --> Pagination Class Initialized
INFO - 2017-05-09 06:49:47 --> Form Validation Class Initialized
INFO - 2017-05-09 06:49:47 --> Jquery Class Initialized
INFO - 2017-05-09 06:49:47 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:49:48 --> Upload Class Initialized
INFO - 2017-05-09 06:49:48 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:49:48 --> Language file loaded: language/english/accounttype_lang.php
ERROR - 2017-05-09 06:49:48 --> Could not find the language line "not_match_username_password"
INFO - 2017-05-09 06:49:48 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/login.php
INFO - 2017-05-09 06:49:48 --> Final output sent to browser
DEBUG - 2017-05-09 06:49:48 --> Total execution time: 1.7146
INFO - 2017-05-09 06:49:56 --> Config Class Initialized
INFO - 2017-05-09 06:49:56 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:49:56 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:49:56 --> Utf8 Class Initialized
INFO - 2017-05-09 06:49:56 --> URI Class Initialized
INFO - 2017-05-09 06:49:56 --> Router Class Initialized
INFO - 2017-05-09 06:49:57 --> Output Class Initialized
INFO - 2017-05-09 06:49:57 --> Security Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:49:57 --> Input Class Initialized
INFO - 2017-05-09 06:49:57 --> Language Class Initialized
INFO - 2017-05-09 06:49:57 --> Loader Class Initialized
INFO - 2017-05-09 06:49:57 --> Controller Class Initialized
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
INFO - 2017-05-09 06:49:57 --> Database Driver Class Initialized
INFO - 2017-05-09 06:49:57 --> Helper loaded: file_helper
INFO - 2017-05-09 06:49:57 --> Helper loaded: date_helper
INFO - 2017-05-09 06:49:57 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:57 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:58 --> Helper loaded: url_helper
INFO - 2017-05-09 06:49:58 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:49:58 --> Pagination Class Initialized
INFO - 2017-05-09 06:49:58 --> Form Validation Class Initialized
INFO - 2017-05-09 06:49:58 --> Jquery Class Initialized
INFO - 2017-05-09 06:49:58 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:49:58 --> Upload Class Initialized
INFO - 2017-05-09 06:49:58 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:49:58 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:49:58 --> Config Class Initialized
INFO - 2017-05-09 06:49:58 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:49:58 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:49:58 --> Utf8 Class Initialized
INFO - 2017-05-09 06:49:58 --> URI Class Initialized
INFO - 2017-05-09 06:49:58 --> Router Class Initialized
INFO - 2017-05-09 06:49:58 --> Output Class Initialized
INFO - 2017-05-09 06:49:58 --> Security Class Initialized
DEBUG - 2017-05-09 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:49:58 --> Input Class Initialized
INFO - 2017-05-09 06:49:58 --> Language Class Initialized
INFO - 2017-05-09 06:49:58 --> Loader Class Initialized
INFO - 2017-05-09 06:49:59 --> Controller Class Initialized
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
INFO - 2017-05-09 06:49:59 --> Database Driver Class Initialized
INFO - 2017-05-09 06:49:59 --> Helper loaded: file_helper
INFO - 2017-05-09 06:49:59 --> Helper loaded: date_helper
INFO - 2017-05-09 06:49:59 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Model Class Initialized
DEBUG - 2017-05-09 06:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:49:59 --> Helper loaded: url_helper
INFO - 2017-05-09 06:49:59 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:00 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:00 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:00 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:00 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:00 --> Upload Class Initialized
INFO - 2017-05-09 06:50:00 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:00 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:00 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 06:50:00 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 06:50:00 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 06:50:00 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/main.php
INFO - 2017-05-09 06:50:00 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 06:50:00 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:00 --> Total execution time: 1.8711
INFO - 2017-05-09 06:50:01 --> Config Class Initialized
INFO - 2017-05-09 06:50:01 --> Hooks Class Initialized
INFO - 2017-05-09 06:50:01 --> Config Class Initialized
INFO - 2017-05-09 06:50:01 --> Config Class Initialized
INFO - 2017-05-09 06:50:01 --> Config Class Initialized
INFO - 2017-05-09 06:50:01 --> Config Class Initialized
DEBUG - 2017-05-09 06:50:01 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:50:01 --> Hooks Class Initialized
INFO - 2017-05-09 06:50:01 --> Hooks Class Initialized
INFO - 2017-05-09 06:50:01 --> Hooks Class Initialized
INFO - 2017-05-09 06:50:01 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 06:50:01 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:50:01 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:01 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:01 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:01 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:01 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:01 --> URI Class Initialized
INFO - 2017-05-09 06:50:01 --> URI Class Initialized
INFO - 2017-05-09 06:50:01 --> URI Class Initialized
INFO - 2017-05-09 06:50:01 --> Router Class Initialized
INFO - 2017-05-09 06:50:01 --> URI Class Initialized
INFO - 2017-05-09 06:50:01 --> URI Class Initialized
INFO - 2017-05-09 06:50:01 --> Router Class Initialized
INFO - 2017-05-09 06:50:01 --> Router Class Initialized
INFO - 2017-05-09 06:50:01 --> Output Class Initialized
INFO - 2017-05-09 06:50:01 --> Router Class Initialized
INFO - 2017-05-09 06:50:01 --> Router Class Initialized
INFO - 2017-05-09 06:50:01 --> Output Class Initialized
INFO - 2017-05-09 06:50:01 --> Output Class Initialized
INFO - 2017-05-09 06:50:01 --> Security Class Initialized
INFO - 2017-05-09 06:50:01 --> Output Class Initialized
INFO - 2017-05-09 06:50:01 --> Output Class Initialized
INFO - 2017-05-09 06:50:01 --> Security Class Initialized
INFO - 2017-05-09 06:50:01 --> Security Class Initialized
INFO - 2017-05-09 06:50:01 --> Security Class Initialized
INFO - 2017-05-09 06:50:01 --> Security Class Initialized
DEBUG - 2017-05-09 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:50:02 --> Input Class Initialized
DEBUG - 2017-05-09 06:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:50:02 --> Language Class Initialized
DEBUG - 2017-05-09 06:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:50:02 --> Input Class Initialized
INFO - 2017-05-09 06:50:02 --> Input Class Initialized
INFO - 2017-05-09 06:50:02 --> Input Class Initialized
INFO - 2017-05-09 06:50:02 --> Loader Class Initialized
INFO - 2017-05-09 06:50:02 --> Input Class Initialized
INFO - 2017-05-09 06:50:02 --> Language Class Initialized
INFO - 2017-05-09 06:50:02 --> Language Class Initialized
INFO - 2017-05-09 06:50:02 --> Language Class Initialized
INFO - 2017-05-09 06:50:02 --> Language Class Initialized
INFO - 2017-05-09 06:50:02 --> Controller Class Initialized
INFO - 2017-05-09 06:50:02 --> Loader Class Initialized
INFO - 2017-05-09 06:50:02 --> Controller Class Initialized
INFO - 2017-05-09 06:50:02 --> Loader Class Initialized
INFO - 2017-05-09 06:50:02 --> Loader Class Initialized
INFO - 2017-05-09 06:50:02 --> Loader Class Initialized
INFO - 2017-05-09 06:50:02 --> Controller Class Initialized
INFO - 2017-05-09 06:50:02 --> Controller Class Initialized
INFO - 2017-05-09 06:50:02 --> Controller Class Initialized
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
INFO - 2017-05-09 06:50:02 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:02 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
INFO - 2017-05-09 06:50:02 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:02 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:02 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:02 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:02 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:02 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:02 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:02 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:02 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:02 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:02 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:02 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:02 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:02 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:02 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:03 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:03 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:03 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:03 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:03 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:03 --> Upload Class Initialized
INFO - 2017-05-09 06:50:03 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:03 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:04 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:04 --> Total execution time: 3.0210
INFO - 2017-05-09 06:50:04 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:04 --> Model Class Initialized
INFO - 2017-05-09 06:50:04 --> Config Class Initialized
DEBUG - 2017-05-09 06:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:04 --> Hooks Class Initialized
INFO - 2017-05-09 06:50:04 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 06:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:04 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:04 --> Model Class Initialized
INFO - 2017-05-09 06:50:04 --> URI Class Initialized
DEBUG - 2017-05-09 06:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:04 --> Router Class Initialized
INFO - 2017-05-09 06:50:04 --> Model Class Initialized
INFO - 2017-05-09 06:50:04 --> Output Class Initialized
DEBUG - 2017-05-09 06:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:04 --> Security Class Initialized
INFO - 2017-05-09 06:50:04 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Input Class Initialized
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
INFO - 2017-05-09 06:50:05 --> Language Class Initialized
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Loader Class Initialized
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
INFO - 2017-05-09 06:50:05 --> Controller Class Initialized
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
INFO - 2017-05-09 06:50:05 --> Helper loaded: file_helper
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:05 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:05 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:05 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:05 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:05 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:05 --> Upload Class Initialized
INFO - 2017-05-09 06:50:05 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:05 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:06 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:06 --> Total execution time: 5.0669
INFO - 2017-05-09 06:50:06 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:06 --> Config Class Initialized
INFO - 2017-05-09 06:50:06 --> Model Class Initialized
INFO - 2017-05-09 06:50:06 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 06:50:06 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:50:06 --> Model Class Initialized
INFO - 2017-05-09 06:50:06 --> Utf8 Class Initialized
DEBUG - 2017-05-09 06:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:06 --> URI Class Initialized
INFO - 2017-05-09 06:50:06 --> Model Class Initialized
INFO - 2017-05-09 06:50:06 --> Router Class Initialized
DEBUG - 2017-05-09 06:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:06 --> Output Class Initialized
INFO - 2017-05-09 06:50:06 --> Model Class Initialized
INFO - 2017-05-09 06:50:07 --> Security Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 06:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
INFO - 2017-05-09 06:50:07 --> Input Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Language Class Initialized
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
INFO - 2017-05-09 06:50:07 --> Loader Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Controller Class Initialized
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
INFO - 2017-05-09 06:50:07 --> Helper loaded: file_helper
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:07 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:07 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:07 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:07 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:07 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:07 --> Upload Class Initialized
INFO - 2017-05-09 06:50:08 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:08 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:08 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:08 --> Total execution time: 7.3737
INFO - 2017-05-09 06:50:08 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:08 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:09 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:09 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:09 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:09 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:09 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:09 --> Upload Class Initialized
INFO - 2017-05-09 06:50:10 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:10 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:11 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:11 --> Total execution time: 9.9292
INFO - 2017-05-09 06:50:11 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:11 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:12 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:12 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:12 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:12 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:12 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:12 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:12 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:12 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:12 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:12 --> Upload Class Initialized
INFO - 2017-05-09 06:50:12 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:12 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:13 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:13 --> Total execution time: 11.7707
INFO - 2017-05-09 06:50:13 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:13 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:14 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:14 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:14 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:14 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:14 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:14 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:14 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:14 --> Upload Class Initialized
INFO - 2017-05-09 06:50:14 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:14 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:15 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:15 --> Total execution time: 10.5411
INFO - 2017-05-09 06:50:15 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:15 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:15 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:15 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:15 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:15 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:15 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:15 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:15 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:16 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:16 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:16 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:16 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:16 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:16 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:16 --> Helper loaded: form_helper
INFO - 2017-05-09 06:50:16 --> Config Class Initialized
DEBUG - 2017-05-09 06:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:16 --> Hooks Class Initialized
INFO - 2017-05-09 06:50:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2017-05-09 06:50:16 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:50:16 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:16 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:16 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:16 --> URI Class Initialized
INFO - 2017-05-09 06:50:16 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:16 --> Router Class Initialized
INFO - 2017-05-09 06:50:16 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:16 --> Output Class Initialized
INFO - 2017-05-09 06:50:16 --> Upload Class Initialized
INFO - 2017-05-09 06:50:16 --> Security Class Initialized
INFO - 2017-05-09 06:50:16 --> Language file loaded: language/english/common_lang.php
DEBUG - 2017-05-09 06:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:50:16 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:16 --> Input Class Initialized
INFO - 2017-05-09 06:50:16 --> Language Class Initialized
INFO - 2017-05-09 06:50:16 --> Loader Class Initialized
INFO - 2017-05-09 06:50:16 --> Controller Class Initialized
INFO - 2017-05-09 06:50:16 --> Model Class Initialized
INFO - 2017-05-09 06:50:16 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:17 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:17 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:17 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:17 --> Total execution time: 10.8300
INFO - 2017-05-09 06:50:17 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:17 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:17 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:17 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:17 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:17 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:18 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:18 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:18 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:18 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:18 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:18 --> Upload Class Initialized
INFO - 2017-05-09 06:50:18 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:18 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:19 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 06:50:19 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 06:50:19 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 06:50:19 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list_visited.php
INFO - 2017-05-09 06:50:19 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 06:50:19 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:19 --> Total execution time: 2.9503
INFO - 2017-05-09 06:50:20 --> Config Class Initialized
INFO - 2017-05-09 06:50:20 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:50:20 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:50:20 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:20 --> URI Class Initialized
INFO - 2017-05-09 06:50:20 --> Router Class Initialized
INFO - 2017-05-09 06:50:20 --> Output Class Initialized
INFO - 2017-05-09 06:50:20 --> Security Class Initialized
DEBUG - 2017-05-09 06:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:50:20 --> Input Class Initialized
INFO - 2017-05-09 06:50:20 --> Language Class Initialized
INFO - 2017-05-09 06:50:20 --> Loader Class Initialized
INFO - 2017-05-09 06:50:20 --> Controller Class Initialized
INFO - 2017-05-09 06:50:20 --> Model Class Initialized
INFO - 2017-05-09 06:50:20 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:20 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:20 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:20 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:20 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:21 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:21 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:21 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:21 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:21 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:22 --> Upload Class Initialized
INFO - 2017-05-09 06:50:22 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:22 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:22 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:22 --> Total execution time: 2.5751
INFO - 2017-05-09 06:50:26 --> Config Class Initialized
INFO - 2017-05-09 06:50:26 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:50:26 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:50:26 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:26 --> URI Class Initialized
INFO - 2017-05-09 06:50:26 --> Router Class Initialized
INFO - 2017-05-09 06:50:26 --> Output Class Initialized
INFO - 2017-05-09 06:50:26 --> Security Class Initialized
DEBUG - 2017-05-09 06:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:50:26 --> Input Class Initialized
INFO - 2017-05-09 06:50:26 --> Language Class Initialized
INFO - 2017-05-09 06:50:26 --> Loader Class Initialized
INFO - 2017-05-09 06:50:26 --> Controller Class Initialized
INFO - 2017-05-09 06:50:26 --> Model Class Initialized
INFO - 2017-05-09 06:50:26 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:26 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:26 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:26 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:26 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:26 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:26 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:26 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:26 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:26 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:27 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:27 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:27 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:27 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:27 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:27 --> Upload Class Initialized
INFO - 2017-05-09 06:50:27 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:27 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:28 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 06:50:28 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 06:50:28 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 06:50:28 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list.php
INFO - 2017-05-09 06:50:28 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 06:50:28 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:28 --> Total execution time: 2.5298
INFO - 2017-05-09 06:50:29 --> Config Class Initialized
INFO - 2017-05-09 06:50:29 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:50:29 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:50:29 --> Utf8 Class Initialized
INFO - 2017-05-09 06:50:29 --> URI Class Initialized
INFO - 2017-05-09 06:50:29 --> Router Class Initialized
INFO - 2017-05-09 06:50:29 --> Output Class Initialized
INFO - 2017-05-09 06:50:29 --> Security Class Initialized
DEBUG - 2017-05-09 06:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:50:29 --> Input Class Initialized
INFO - 2017-05-09 06:50:29 --> Language Class Initialized
INFO - 2017-05-09 06:50:29 --> Loader Class Initialized
INFO - 2017-05-09 06:50:29 --> Controller Class Initialized
INFO - 2017-05-09 06:50:29 --> Model Class Initialized
INFO - 2017-05-09 06:50:29 --> Database Driver Class Initialized
INFO - 2017-05-09 06:50:29 --> Helper loaded: file_helper
INFO - 2017-05-09 06:50:29 --> Helper loaded: date_helper
INFO - 2017-05-09 06:50:29 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:50:29 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:29 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Model Class Initialized
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Helper loaded: url_helper
INFO - 2017-05-09 06:50:30 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:50:30 --> Pagination Class Initialized
INFO - 2017-05-09 06:50:30 --> Form Validation Class Initialized
INFO - 2017-05-09 06:50:30 --> Jquery Class Initialized
INFO - 2017-05-09 06:50:30 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:50:30 --> Upload Class Initialized
INFO - 2017-05-09 06:50:30 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:50:31 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:50:34 --> Final output sent to browser
DEBUG - 2017-05-09 06:50:34 --> Total execution time: 4.9402
INFO - 2017-05-09 06:59:50 --> Config Class Initialized
INFO - 2017-05-09 06:59:50 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:59:50 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:59:50 --> Utf8 Class Initialized
INFO - 2017-05-09 06:59:50 --> URI Class Initialized
INFO - 2017-05-09 06:59:50 --> Router Class Initialized
INFO - 2017-05-09 06:59:50 --> Output Class Initialized
INFO - 2017-05-09 06:59:50 --> Security Class Initialized
DEBUG - 2017-05-09 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:59:50 --> Input Class Initialized
INFO - 2017-05-09 06:59:50 --> Language Class Initialized
INFO - 2017-05-09 06:59:50 --> Loader Class Initialized
INFO - 2017-05-09 06:59:50 --> Controller Class Initialized
INFO - 2017-05-09 06:59:50 --> Model Class Initialized
INFO - 2017-05-09 06:59:50 --> Database Driver Class Initialized
INFO - 2017-05-09 06:59:50 --> Helper loaded: file_helper
INFO - 2017-05-09 06:59:50 --> Helper loaded: date_helper
INFO - 2017-05-09 06:59:50 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:59:50 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Helper loaded: url_helper
INFO - 2017-05-09 06:59:51 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:59:52 --> Pagination Class Initialized
INFO - 2017-05-09 06:59:52 --> Form Validation Class Initialized
INFO - 2017-05-09 06:59:52 --> Jquery Class Initialized
INFO - 2017-05-09 06:59:52 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:59:52 --> Upload Class Initialized
INFO - 2017-05-09 06:59:52 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:59:52 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:59:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 06:59:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 06:59:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 06:59:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list_visited.php
INFO - 2017-05-09 06:59:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 06:59:52 --> Final output sent to browser
DEBUG - 2017-05-09 06:59:52 --> Total execution time: 2.5034
INFO - 2017-05-09 06:59:54 --> Config Class Initialized
INFO - 2017-05-09 06:59:54 --> Hooks Class Initialized
DEBUG - 2017-05-09 06:59:54 --> UTF-8 Support Enabled
INFO - 2017-05-09 06:59:54 --> Utf8 Class Initialized
INFO - 2017-05-09 06:59:54 --> URI Class Initialized
INFO - 2017-05-09 06:59:54 --> Router Class Initialized
INFO - 2017-05-09 06:59:54 --> Output Class Initialized
INFO - 2017-05-09 06:59:54 --> Security Class Initialized
DEBUG - 2017-05-09 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 06:59:54 --> Input Class Initialized
INFO - 2017-05-09 06:59:54 --> Language Class Initialized
INFO - 2017-05-09 06:59:54 --> Loader Class Initialized
INFO - 2017-05-09 06:59:54 --> Controller Class Initialized
INFO - 2017-05-09 06:59:54 --> Model Class Initialized
INFO - 2017-05-09 06:59:55 --> Database Driver Class Initialized
INFO - 2017-05-09 06:59:55 --> Helper loaded: file_helper
INFO - 2017-05-09 06:59:55 --> Helper loaded: date_helper
INFO - 2017-05-09 06:59:55 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Model Class Initialized
DEBUG - 2017-05-09 06:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:55 --> Helper loaded: url_helper
INFO - 2017-05-09 06:59:55 --> Helper loaded: form_helper
DEBUG - 2017-05-09 06:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 06:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 06:59:56 --> Pagination Class Initialized
INFO - 2017-05-09 06:59:56 --> Form Validation Class Initialized
INFO - 2017-05-09 06:59:56 --> Jquery Class Initialized
INFO - 2017-05-09 06:59:56 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 06:59:56 --> Upload Class Initialized
INFO - 2017-05-09 06:59:56 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 06:59:56 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 06:59:57 --> Final output sent to browser
DEBUG - 2017-05-09 06:59:57 --> Total execution time: 2.6632
INFO - 2017-05-09 07:00:33 --> Config Class Initialized
INFO - 2017-05-09 07:00:33 --> Hooks Class Initialized
DEBUG - 2017-05-09 07:00:33 --> UTF-8 Support Enabled
INFO - 2017-05-09 07:00:33 --> Utf8 Class Initialized
INFO - 2017-05-09 07:00:33 --> URI Class Initialized
INFO - 2017-05-09 07:00:33 --> Router Class Initialized
INFO - 2017-05-09 07:00:33 --> Output Class Initialized
INFO - 2017-05-09 07:00:33 --> Security Class Initialized
DEBUG - 2017-05-09 07:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 07:00:33 --> Input Class Initialized
INFO - 2017-05-09 07:00:33 --> Language Class Initialized
INFO - 2017-05-09 07:00:33 --> Loader Class Initialized
INFO - 2017-05-09 07:00:33 --> Controller Class Initialized
INFO - 2017-05-09 07:00:33 --> Model Class Initialized
INFO - 2017-05-09 07:00:33 --> Database Driver Class Initialized
INFO - 2017-05-09 07:00:33 --> Helper loaded: file_helper
INFO - 2017-05-09 07:00:33 --> Helper loaded: date_helper
INFO - 2017-05-09 07:00:33 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 07:00:33 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Model Class Initialized
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Helper loaded: url_helper
INFO - 2017-05-09 07:00:34 --> Helper loaded: form_helper
DEBUG - 2017-05-09 07:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 07:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 07:00:34 --> Pagination Class Initialized
INFO - 2017-05-09 07:00:34 --> Form Validation Class Initialized
INFO - 2017-05-09 07:00:34 --> Jquery Class Initialized
INFO - 2017-05-09 07:00:34 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 07:00:34 --> Upload Class Initialized
INFO - 2017-05-09 07:00:34 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 07:00:35 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 07:00:35 --> Final output sent to browser
DEBUG - 2017-05-09 07:00:35 --> Total execution time: 2.2860
INFO - 2017-05-09 10:42:43 --> Config Class Initialized
INFO - 2017-05-09 10:42:43 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:42:43 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:42:43 --> Utf8 Class Initialized
INFO - 2017-05-09 10:42:43 --> URI Class Initialized
INFO - 2017-05-09 10:42:44 --> Router Class Initialized
INFO - 2017-05-09 10:42:44 --> Output Class Initialized
INFO - 2017-05-09 10:42:44 --> Security Class Initialized
DEBUG - 2017-05-09 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:42:44 --> Input Class Initialized
INFO - 2017-05-09 10:42:44 --> Language Class Initialized
INFO - 2017-05-09 10:42:44 --> Loader Class Initialized
INFO - 2017-05-09 10:42:45 --> Controller Class Initialized
INFO - 2017-05-09 10:42:45 --> Model Class Initialized
INFO - 2017-05-09 10:42:45 --> Database Driver Class Initialized
INFO - 2017-05-09 10:42:46 --> Helper loaded: file_helper
INFO - 2017-05-09 10:42:46 --> Helper loaded: date_helper
INFO - 2017-05-09 10:42:46 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:42:46 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:47 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:47 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:47 --> Config Class Initialized
INFO - 2017-05-09 10:42:47 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:42:47 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:42:47 --> Utf8 Class Initialized
INFO - 2017-05-09 10:42:47 --> URI Class Initialized
INFO - 2017-05-09 10:42:47 --> Router Class Initialized
INFO - 2017-05-09 10:42:47 --> Output Class Initialized
INFO - 2017-05-09 10:42:47 --> Model Class Initialized
INFO - 2017-05-09 10:42:47 --> Security Class Initialized
DEBUG - 2017-05-09 10:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:42:47 --> Input Class Initialized
INFO - 2017-05-09 10:42:47 --> Language Class Initialized
INFO - 2017-05-09 10:42:47 --> Loader Class Initialized
INFO - 2017-05-09 10:42:47 --> Controller Class Initialized
INFO - 2017-05-09 10:42:47 --> Model Class Initialized
INFO - 2017-05-09 10:42:47 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:47 --> Database Driver Class Initialized
INFO - 2017-05-09 10:42:47 --> Helper loaded: file_helper
INFO - 2017-05-09 10:42:47 --> Model Class Initialized
INFO - 2017-05-09 10:42:48 --> Helper loaded: date_helper
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
INFO - 2017-05-09 10:42:48 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:49 --> Model Class Initialized
INFO - 2017-05-09 10:42:49 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:49 --> Model Class Initialized
INFO - 2017-05-09 10:42:49 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:49 --> Model Class Initialized
INFO - 2017-05-09 10:42:49 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:49 --> Model Class Initialized
INFO - 2017-05-09 10:42:49 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:49 --> Helper loaded: url_helper
INFO - 2017-05-09 10:42:49 --> Helper loaded: url_helper
INFO - 2017-05-09 10:42:49 --> Helper loaded: form_helper
INFO - 2017-05-09 10:42:49 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:42:49 --> Pagination Class Initialized
INFO - 2017-05-09 10:42:49 --> Pagination Class Initialized
INFO - 2017-05-09 10:42:50 --> Form Validation Class Initialized
INFO - 2017-05-09 10:42:50 --> Form Validation Class Initialized
INFO - 2017-05-09 10:42:50 --> Jquery Class Initialized
INFO - 2017-05-09 10:42:50 --> Jquery Class Initialized
INFO - 2017-05-09 10:42:50 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:42:50 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:42:50 --> Upload Class Initialized
INFO - 2017-05-09 10:42:50 --> Upload Class Initialized
INFO - 2017-05-09 10:42:50 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:42:50 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:42:50 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:42:50 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:42:51 --> Config Class Initialized
INFO - 2017-05-09 10:42:51 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:42:51 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:42:51 --> Utf8 Class Initialized
INFO - 2017-05-09 10:42:51 --> URI Class Initialized
INFO - 2017-05-09 10:42:51 --> Router Class Initialized
INFO - 2017-05-09 10:42:51 --> Output Class Initialized
INFO - 2017-05-09 10:42:51 --> Security Class Initialized
DEBUG - 2017-05-09 10:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:42:51 --> Input Class Initialized
INFO - 2017-05-09 10:42:52 --> Language Class Initialized
INFO - 2017-05-09 10:42:52 --> Loader Class Initialized
INFO - 2017-05-09 10:42:52 --> Controller Class Initialized
INFO - 2017-05-09 10:42:52 --> Model Class Initialized
INFO - 2017-05-09 10:42:52 --> Database Driver Class Initialized
INFO - 2017-05-09 10:42:52 --> Helper loaded: file_helper
INFO - 2017-05-09 10:42:52 --> Helper loaded: date_helper
INFO - 2017-05-09 10:42:52 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:42:52 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:52 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:52 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:52 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:52 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:52 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:52 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:53 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:53 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:53 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:53 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:53 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:53 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:53 --> Helper loaded: url_helper
INFO - 2017-05-09 10:42:53 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:42:53 --> Pagination Class Initialized
INFO - 2017-05-09 10:42:53 --> Form Validation Class Initialized
INFO - 2017-05-09 10:42:53 --> Jquery Class Initialized
INFO - 2017-05-09 10:42:54 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:42:54 --> Upload Class Initialized
INFO - 2017-05-09 10:42:54 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:42:54 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:42:54 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/login.php
INFO - 2017-05-09 10:42:54 --> Final output sent to browser
DEBUG - 2017-05-09 10:42:54 --> Total execution time: 3.2262
INFO - 2017-05-09 10:42:57 --> Config Class Initialized
INFO - 2017-05-09 10:42:57 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:42:57 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:42:57 --> Utf8 Class Initialized
INFO - 2017-05-09 10:42:57 --> URI Class Initialized
INFO - 2017-05-09 10:42:57 --> Router Class Initialized
INFO - 2017-05-09 10:42:57 --> Output Class Initialized
INFO - 2017-05-09 10:42:57 --> Security Class Initialized
DEBUG - 2017-05-09 10:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:42:57 --> Input Class Initialized
INFO - 2017-05-09 10:42:57 --> Language Class Initialized
INFO - 2017-05-09 10:42:58 --> Loader Class Initialized
INFO - 2017-05-09 10:42:58 --> Controller Class Initialized
INFO - 2017-05-09 10:42:58 --> Model Class Initialized
INFO - 2017-05-09 10:42:58 --> Database Driver Class Initialized
INFO - 2017-05-09 10:42:58 --> Helper loaded: file_helper
INFO - 2017-05-09 10:42:58 --> Helper loaded: date_helper
INFO - 2017-05-09 10:42:58 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:42:58 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:58 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:58 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:58 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:58 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:58 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:58 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:59 --> Helper loaded: url_helper
INFO - 2017-05-09 10:42:59 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:42:59 --> Pagination Class Initialized
INFO - 2017-05-09 10:42:59 --> Form Validation Class Initialized
INFO - 2017-05-09 10:42:59 --> Jquery Class Initialized
INFO - 2017-05-09 10:42:59 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:42:59 --> Upload Class Initialized
INFO - 2017-05-09 10:42:59 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:42:59 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:05 --> Config Class Initialized
INFO - 2017-05-09 10:43:05 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:43:05 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:43:05 --> Utf8 Class Initialized
INFO - 2017-05-09 10:43:05 --> URI Class Initialized
INFO - 2017-05-09 10:43:05 --> Router Class Initialized
INFO - 2017-05-09 10:43:05 --> Output Class Initialized
INFO - 2017-05-09 10:43:05 --> Security Class Initialized
DEBUG - 2017-05-09 10:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:43:05 --> Input Class Initialized
INFO - 2017-05-09 10:43:05 --> Language Class Initialized
INFO - 2017-05-09 10:43:05 --> Loader Class Initialized
INFO - 2017-05-09 10:43:05 --> Controller Class Initialized
INFO - 2017-05-09 10:43:05 --> Model Class Initialized
INFO - 2017-05-09 10:43:05 --> Database Driver Class Initialized
INFO - 2017-05-09 10:43:05 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:05 --> Helper loaded: date_helper
INFO - 2017-05-09 10:43:05 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:05 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:05 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:05 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:05 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:06 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:06 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:07 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:07 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:07 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:07 --> Upload Class Initialized
INFO - 2017-05-09 10:43:07 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:07 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:07 --> Config Class Initialized
INFO - 2017-05-09 10:43:07 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:43:08 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:43:08 --> Utf8 Class Initialized
INFO - 2017-05-09 10:43:08 --> URI Class Initialized
INFO - 2017-05-09 10:43:08 --> Router Class Initialized
INFO - 2017-05-09 10:43:08 --> Output Class Initialized
INFO - 2017-05-09 10:43:08 --> Security Class Initialized
DEBUG - 2017-05-09 10:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:43:08 --> Input Class Initialized
INFO - 2017-05-09 10:43:08 --> Language Class Initialized
INFO - 2017-05-09 10:43:08 --> Loader Class Initialized
INFO - 2017-05-09 10:43:08 --> Controller Class Initialized
INFO - 2017-05-09 10:43:08 --> Model Class Initialized
INFO - 2017-05-09 10:43:08 --> Database Driver Class Initialized
INFO - 2017-05-09 10:43:08 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:08 --> Helper loaded: date_helper
INFO - 2017-05-09 10:43:08 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:08 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:08 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:08 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:09 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:10 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:10 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:10 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:10 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:10 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:10 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:10 --> Upload Class Initialized
INFO - 2017-05-09 10:43:10 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:10 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:11 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 10:43:11 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 10:43:11 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 10:43:11 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/main.php
INFO - 2017-05-09 10:43:11 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 10:43:11 --> Final output sent to browser
DEBUG - 2017-05-09 10:43:11 --> Total execution time: 3.3971
INFO - 2017-05-09 10:43:12 --> Config Class Initialized
INFO - 2017-05-09 10:43:12 --> Hooks Class Initialized
INFO - 2017-05-09 10:43:12 --> Config Class Initialized
INFO - 2017-05-09 10:43:12 --> Config Class Initialized
INFO - 2017-05-09 10:43:12 --> Config Class Initialized
INFO - 2017-05-09 10:43:12 --> Config Class Initialized
INFO - 2017-05-09 10:43:12 --> Hooks Class Initialized
INFO - 2017-05-09 10:43:12 --> Config Class Initialized
DEBUG - 2017-05-09 10:43:12 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:43:12 --> Hooks Class Initialized
INFO - 2017-05-09 10:43:12 --> Hooks Class Initialized
INFO - 2017-05-09 10:43:12 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:43:12 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:43:12 --> Hooks Class Initialized
INFO - 2017-05-09 10:43:12 --> Utf8 Class Initialized
INFO - 2017-05-09 10:43:12 --> Utf8 Class Initialized
DEBUG - 2017-05-09 10:43:12 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 10:43:12 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 10:43:12 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:43:12 --> Utf8 Class Initialized
INFO - 2017-05-09 10:43:12 --> Utf8 Class Initialized
INFO - 2017-05-09 10:43:12 --> Utf8 Class Initialized
DEBUG - 2017-05-09 10:43:12 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:43:12 --> URI Class Initialized
INFO - 2017-05-09 10:43:12 --> URI Class Initialized
INFO - 2017-05-09 10:43:12 --> URI Class Initialized
INFO - 2017-05-09 10:43:12 --> Utf8 Class Initialized
INFO - 2017-05-09 10:43:12 --> URI Class Initialized
INFO - 2017-05-09 10:43:12 --> URI Class Initialized
INFO - 2017-05-09 10:43:12 --> Router Class Initialized
INFO - 2017-05-09 10:43:12 --> Router Class Initialized
INFO - 2017-05-09 10:43:12 --> Output Class Initialized
INFO - 2017-05-09 10:43:12 --> Router Class Initialized
INFO - 2017-05-09 10:43:12 --> Router Class Initialized
INFO - 2017-05-09 10:43:12 --> Router Class Initialized
INFO - 2017-05-09 10:43:12 --> URI Class Initialized
INFO - 2017-05-09 10:43:12 --> Output Class Initialized
INFO - 2017-05-09 10:43:12 --> Output Class Initialized
INFO - 2017-05-09 10:43:12 --> Router Class Initialized
INFO - 2017-05-09 10:43:12 --> Security Class Initialized
INFO - 2017-05-09 10:43:12 --> Output Class Initialized
INFO - 2017-05-09 10:43:12 --> Output Class Initialized
INFO - 2017-05-09 10:43:12 --> Security Class Initialized
INFO - 2017-05-09 10:43:12 --> Security Class Initialized
INFO - 2017-05-09 10:43:12 --> Output Class Initialized
INFO - 2017-05-09 10:43:12 --> Security Class Initialized
DEBUG - 2017-05-09 10:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:43:12 --> Security Class Initialized
DEBUG - 2017-05-09 10:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:43:12 --> Input Class Initialized
INFO - 2017-05-09 10:43:12 --> Input Class Initialized
DEBUG - 2017-05-09 10:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 10:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 10:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:43:12 --> Security Class Initialized
INFO - 2017-05-09 10:43:12 --> Language Class Initialized
INFO - 2017-05-09 10:43:12 --> Language Class Initialized
DEBUG - 2017-05-09 10:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:43:12 --> Input Class Initialized
INFO - 2017-05-09 10:43:12 --> Input Class Initialized
INFO - 2017-05-09 10:43:12 --> Input Class Initialized
INFO - 2017-05-09 10:43:12 --> Language Class Initialized
INFO - 2017-05-09 10:43:13 --> Language Class Initialized
INFO - 2017-05-09 10:43:13 --> Input Class Initialized
INFO - 2017-05-09 10:43:13 --> Language Class Initialized
INFO - 2017-05-09 10:43:13 --> Loader Class Initialized
INFO - 2017-05-09 10:43:13 --> Language Class Initialized
INFO - 2017-05-09 10:43:13 --> Loader Class Initialized
INFO - 2017-05-09 10:43:13 --> Controller Class Initialized
INFO - 2017-05-09 10:43:13 --> Loader Class Initialized
INFO - 2017-05-09 10:43:13 --> Loader Class Initialized
INFO - 2017-05-09 10:43:13 --> Controller Class Initialized
INFO - 2017-05-09 10:43:13 --> Loader Class Initialized
INFO - 2017-05-09 10:43:13 --> Loader Class Initialized
INFO - 2017-05-09 10:43:13 --> Controller Class Initialized
INFO - 2017-05-09 10:43:13 --> Model Class Initialized
INFO - 2017-05-09 10:43:13 --> Controller Class Initialized
INFO - 2017-05-09 10:43:13 --> Controller Class Initialized
INFO - 2017-05-09 10:43:13 --> Controller Class Initialized
INFO - 2017-05-09 10:43:13 --> Model Class Initialized
INFO - 2017-05-09 10:43:13 --> Database Driver Class Initialized
INFO - 2017-05-09 10:43:13 --> Model Class Initialized
INFO - 2017-05-09 10:43:13 --> Model Class Initialized
INFO - 2017-05-09 10:43:13 --> Model Class Initialized
INFO - 2017-05-09 10:43:13 --> Model Class Initialized
INFO - 2017-05-09 10:43:13 --> Database Driver Class Initialized
INFO - 2017-05-09 10:43:13 --> Database Driver Class Initialized
INFO - 2017-05-09 10:43:13 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:13 --> Database Driver Class Initialized
INFO - 2017-05-09 10:43:13 --> Database Driver Class Initialized
INFO - 2017-05-09 10:43:13 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:13 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:13 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:13 --> Database Driver Class Initialized
INFO - 2017-05-09 10:43:13 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:13 --> Helper loaded: date_helper
INFO - 2017-05-09 10:43:13 --> Helper loaded: date_helper
INFO - 2017-05-09 10:43:13 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:13 --> Helper loaded: date_helper
INFO - 2017-05-09 10:43:13 --> Helper loaded: date_helper
INFO - 2017-05-09 10:43:13 --> Helper loaded: date_helper
INFO - 2017-05-09 10:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:13 --> Helper loaded: date_helper
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:14 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:14 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:15 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:15 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:15 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:15 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:15 --> Upload Class Initialized
INFO - 2017-05-09 10:43:15 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:15 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:16 --> Final output sent to browser
DEBUG - 2017-05-09 10:43:16 --> Total execution time: 4.3818
INFO - 2017-05-09 10:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:16 --> Config Class Initialized
INFO - 2017-05-09 10:43:16 --> Model Class Initialized
INFO - 2017-05-09 10:43:16 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:43:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 10:43:16 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:43:16 --> Model Class Initialized
INFO - 2017-05-09 10:43:16 --> Utf8 Class Initialized
DEBUG - 2017-05-09 10:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:16 --> URI Class Initialized
INFO - 2017-05-09 10:43:16 --> Model Class Initialized
INFO - 2017-05-09 10:43:16 --> Router Class Initialized
DEBUG - 2017-05-09 10:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Output Class Initialized
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Security Class Initialized
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Input Class Initialized
INFO - 2017-05-09 10:43:17 --> Language Class Initialized
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Loader Class Initialized
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
INFO - 2017-05-09 10:43:17 --> Controller Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
INFO - 2017-05-09 10:43:17 --> Database Driver Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Helper loaded: file_helper
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
INFO - 2017-05-09 10:43:17 --> Helper loaded: date_helper
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:17 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:18 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:18 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:18 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:18 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:18 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:18 --> Upload Class Initialized
INFO - 2017-05-09 10:43:18 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:18 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:19 --> Final output sent to browser
DEBUG - 2017-05-09 10:43:19 --> Total execution time: 6.8441
INFO - 2017-05-09 10:43:19 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:19 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:20 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:20 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:20 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:20 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:20 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:20 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:20 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:20 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:20 --> Upload Class Initialized
INFO - 2017-05-09 10:43:20 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:20 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:21 --> Final output sent to browser
DEBUG - 2017-05-09 10:43:21 --> Total execution time: 9.0389
INFO - 2017-05-09 10:43:21 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:21 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:22 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:22 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:22 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:22 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:22 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:22 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:22 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:22 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:22 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:22 --> Upload Class Initialized
INFO - 2017-05-09 10:43:22 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:22 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:23 --> Final output sent to browser
DEBUG - 2017-05-09 10:43:23 --> Total execution time: 11.0531
INFO - 2017-05-09 10:43:23 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:23 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:24 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:24 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:24 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:24 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:24 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:24 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:24 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:24 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:24 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:24 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:24 --> Upload Class Initialized
INFO - 2017-05-09 10:43:24 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:24 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:25 --> Final output sent to browser
DEBUG - 2017-05-09 10:43:25 --> Total execution time: 13.5142
INFO - 2017-05-09 10:43:25 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:25 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:25 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:25 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:26 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:26 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:27 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:27 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:27 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:27 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:27 --> Upload Class Initialized
INFO - 2017-05-09 10:43:27 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:27 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:28 --> Final output sent to browser
DEBUG - 2017-05-09 10:43:28 --> Total execution time: 16.1722
INFO - 2017-05-09 10:43:28 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:43:28 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:28 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:28 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:28 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:28 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:28 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Model Class Initialized
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Helper loaded: url_helper
INFO - 2017-05-09 10:43:29 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:43:29 --> Pagination Class Initialized
INFO - 2017-05-09 10:43:29 --> Form Validation Class Initialized
INFO - 2017-05-09 10:43:29 --> Jquery Class Initialized
INFO - 2017-05-09 10:43:29 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:43:30 --> Upload Class Initialized
INFO - 2017-05-09 10:43:30 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:43:30 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:43:31 --> Final output sent to browser
DEBUG - 2017-05-09 10:43:31 --> Total execution time: 14.4904
INFO - 2017-05-09 10:47:55 --> Config Class Initialized
INFO - 2017-05-09 10:47:55 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:47:55 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:47:55 --> Utf8 Class Initialized
INFO - 2017-05-09 10:47:55 --> URI Class Initialized
INFO - 2017-05-09 10:47:55 --> Router Class Initialized
INFO - 2017-05-09 10:47:55 --> Output Class Initialized
INFO - 2017-05-09 10:47:55 --> Security Class Initialized
DEBUG - 2017-05-09 10:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:47:55 --> Input Class Initialized
INFO - 2017-05-09 10:47:55 --> Language Class Initialized
INFO - 2017-05-09 10:47:55 --> Loader Class Initialized
INFO - 2017-05-09 10:47:55 --> Controller Class Initialized
INFO - 2017-05-09 10:47:55 --> Model Class Initialized
INFO - 2017-05-09 10:47:55 --> Database Driver Class Initialized
INFO - 2017-05-09 10:47:55 --> Helper loaded: file_helper
INFO - 2017-05-09 10:47:55 --> Helper loaded: date_helper
INFO - 2017-05-09 10:47:55 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:47:55 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Helper loaded: url_helper
INFO - 2017-05-09 10:47:56 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:47:56 --> Pagination Class Initialized
INFO - 2017-05-09 10:47:56 --> Form Validation Class Initialized
INFO - 2017-05-09 10:47:56 --> Jquery Class Initialized
INFO - 2017-05-09 10:47:57 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:47:57 --> Upload Class Initialized
INFO - 2017-05-09 10:47:57 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:47:57 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:47:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 10:47:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 10:47:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 10:47:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list_visited.php
INFO - 2017-05-09 10:47:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 10:47:57 --> Final output sent to browser
DEBUG - 2017-05-09 10:47:57 --> Total execution time: 2.5125
INFO - 2017-05-09 10:47:58 --> Config Class Initialized
INFO - 2017-05-09 10:47:58 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:47:58 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:47:58 --> Utf8 Class Initialized
INFO - 2017-05-09 10:47:58 --> URI Class Initialized
INFO - 2017-05-09 10:47:58 --> Router Class Initialized
INFO - 2017-05-09 10:47:58 --> Output Class Initialized
INFO - 2017-05-09 10:47:58 --> Security Class Initialized
DEBUG - 2017-05-09 10:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:47:58 --> Input Class Initialized
INFO - 2017-05-09 10:47:58 --> Language Class Initialized
INFO - 2017-05-09 10:47:58 --> Loader Class Initialized
INFO - 2017-05-09 10:47:59 --> Controller Class Initialized
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
INFO - 2017-05-09 10:47:59 --> Database Driver Class Initialized
INFO - 2017-05-09 10:47:59 --> Helper loaded: file_helper
INFO - 2017-05-09 10:47:59 --> Helper loaded: date_helper
INFO - 2017-05-09 10:47:59 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:47:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:00 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:00 --> Helper loaded: url_helper
INFO - 2017-05-09 10:48:00 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:48:00 --> Pagination Class Initialized
INFO - 2017-05-09 10:48:00 --> Form Validation Class Initialized
INFO - 2017-05-09 10:48:00 --> Jquery Class Initialized
INFO - 2017-05-09 10:48:00 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:48:00 --> Upload Class Initialized
INFO - 2017-05-09 10:48:00 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:48:00 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:48:01 --> Final output sent to browser
DEBUG - 2017-05-09 10:48:01 --> Total execution time: 2.5752
INFO - 2017-05-09 10:48:03 --> Config Class Initialized
INFO - 2017-05-09 10:48:03 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:48:03 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:48:03 --> Utf8 Class Initialized
INFO - 2017-05-09 10:48:03 --> URI Class Initialized
INFO - 2017-05-09 10:48:03 --> Router Class Initialized
INFO - 2017-05-09 10:48:03 --> Output Class Initialized
INFO - 2017-05-09 10:48:03 --> Security Class Initialized
DEBUG - 2017-05-09 10:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:48:03 --> Input Class Initialized
INFO - 2017-05-09 10:48:03 --> Language Class Initialized
INFO - 2017-05-09 10:48:03 --> Loader Class Initialized
INFO - 2017-05-09 10:48:03 --> Controller Class Initialized
INFO - 2017-05-09 10:48:03 --> Model Class Initialized
INFO - 2017-05-09 10:48:03 --> Database Driver Class Initialized
INFO - 2017-05-09 10:48:03 --> Helper loaded: file_helper
INFO - 2017-05-09 10:48:03 --> Helper loaded: date_helper
INFO - 2017-05-09 10:48:03 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:48:03 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:03 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:03 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:03 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:03 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:03 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Helper loaded: url_helper
INFO - 2017-05-09 10:48:04 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:48:04 --> Pagination Class Initialized
INFO - 2017-05-09 10:48:04 --> Form Validation Class Initialized
INFO - 2017-05-09 10:48:04 --> Jquery Class Initialized
INFO - 2017-05-09 10:48:04 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:48:04 --> Upload Class Initialized
INFO - 2017-05-09 10:48:04 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:48:04 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:48:05 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 10:48:05 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 10:48:05 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 10:48:05 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list.php
INFO - 2017-05-09 10:48:05 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 10:48:05 --> Final output sent to browser
DEBUG - 2017-05-09 10:48:05 --> Total execution time: 2.6230
INFO - 2017-05-09 10:48:06 --> Config Class Initialized
INFO - 2017-05-09 10:48:06 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:48:06 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:48:06 --> Utf8 Class Initialized
INFO - 2017-05-09 10:48:06 --> URI Class Initialized
INFO - 2017-05-09 10:48:06 --> Router Class Initialized
INFO - 2017-05-09 10:48:06 --> Output Class Initialized
INFO - 2017-05-09 10:48:06 --> Security Class Initialized
DEBUG - 2017-05-09 10:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:48:06 --> Input Class Initialized
INFO - 2017-05-09 10:48:06 --> Language Class Initialized
INFO - 2017-05-09 10:48:06 --> Loader Class Initialized
INFO - 2017-05-09 10:48:06 --> Controller Class Initialized
INFO - 2017-05-09 10:48:06 --> Model Class Initialized
INFO - 2017-05-09 10:48:06 --> Database Driver Class Initialized
INFO - 2017-05-09 10:48:06 --> Helper loaded: file_helper
INFO - 2017-05-09 10:48:06 --> Helper loaded: date_helper
INFO - 2017-05-09 10:48:06 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:48:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:06 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Helper loaded: url_helper
INFO - 2017-05-09 10:48:07 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:48:07 --> Pagination Class Initialized
INFO - 2017-05-09 10:48:07 --> Form Validation Class Initialized
INFO - 2017-05-09 10:48:07 --> Jquery Class Initialized
INFO - 2017-05-09 10:48:07 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:48:07 --> Upload Class Initialized
INFO - 2017-05-09 10:48:07 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:48:07 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:48:12 --> Final output sent to browser
DEBUG - 2017-05-09 10:48:12 --> Total execution time: 6.4955
INFO - 2017-05-09 10:48:55 --> Config Class Initialized
INFO - 2017-05-09 10:48:55 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:48:55 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:48:55 --> Utf8 Class Initialized
INFO - 2017-05-09 10:48:55 --> URI Class Initialized
INFO - 2017-05-09 10:48:55 --> Router Class Initialized
INFO - 2017-05-09 10:48:55 --> Output Class Initialized
INFO - 2017-05-09 10:48:55 --> Security Class Initialized
DEBUG - 2017-05-09 10:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:48:55 --> Input Class Initialized
INFO - 2017-05-09 10:48:55 --> Language Class Initialized
INFO - 2017-05-09 10:48:55 --> Loader Class Initialized
INFO - 2017-05-09 10:48:55 --> Controller Class Initialized
INFO - 2017-05-09 10:48:55 --> Model Class Initialized
INFO - 2017-05-09 10:48:55 --> Database Driver Class Initialized
INFO - 2017-05-09 10:48:55 --> Helper loaded: file_helper
INFO - 2017-05-09 10:48:55 --> Helper loaded: date_helper
INFO - 2017-05-09 10:48:55 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:48:55 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:55 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:55 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:55 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:55 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:55 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Helper loaded: url_helper
INFO - 2017-05-09 10:48:56 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:48:56 --> Pagination Class Initialized
INFO - 2017-05-09 10:48:56 --> Form Validation Class Initialized
INFO - 2017-05-09 10:48:56 --> Jquery Class Initialized
INFO - 2017-05-09 10:48:56 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:48:56 --> Upload Class Initialized
INFO - 2017-05-09 10:48:56 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:48:56 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:48:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 10:48:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 10:48:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 10:48:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list.php
INFO - 2017-05-09 10:48:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 10:48:57 --> Final output sent to browser
DEBUG - 2017-05-09 10:48:57 --> Total execution time: 2.5691
INFO - 2017-05-09 10:48:58 --> Config Class Initialized
INFO - 2017-05-09 10:48:58 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:48:58 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:48:58 --> Utf8 Class Initialized
INFO - 2017-05-09 10:48:58 --> URI Class Initialized
INFO - 2017-05-09 10:48:58 --> Router Class Initialized
INFO - 2017-05-09 10:48:58 --> Output Class Initialized
INFO - 2017-05-09 10:48:59 --> Security Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:48:59 --> Input Class Initialized
INFO - 2017-05-09 10:48:59 --> Language Class Initialized
INFO - 2017-05-09 10:48:59 --> Loader Class Initialized
INFO - 2017-05-09 10:48:59 --> Controller Class Initialized
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
INFO - 2017-05-09 10:48:59 --> Database Driver Class Initialized
INFO - 2017-05-09 10:48:59 --> Helper loaded: file_helper
INFO - 2017-05-09 10:48:59 --> Helper loaded: date_helper
INFO - 2017-05-09 10:48:59 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:48:59 --> Model Class Initialized
DEBUG - 2017-05-09 10:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:49:00 --> Model Class Initialized
DEBUG - 2017-05-09 10:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:49:00 --> Model Class Initialized
DEBUG - 2017-05-09 10:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:49:00 --> Model Class Initialized
DEBUG - 2017-05-09 10:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:49:00 --> Model Class Initialized
DEBUG - 2017-05-09 10:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:49:00 --> Model Class Initialized
DEBUG - 2017-05-09 10:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:49:00 --> Helper loaded: url_helper
INFO - 2017-05-09 10:49:00 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:49:00 --> Pagination Class Initialized
INFO - 2017-05-09 10:49:00 --> Form Validation Class Initialized
INFO - 2017-05-09 10:49:00 --> Jquery Class Initialized
INFO - 2017-05-09 10:49:00 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:49:00 --> Upload Class Initialized
INFO - 2017-05-09 10:49:00 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:49:00 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:49:05 --> Final output sent to browser
DEBUG - 2017-05-09 10:49:05 --> Total execution time: 6.6776
INFO - 2017-05-09 10:50:32 --> Config Class Initialized
INFO - 2017-05-09 10:50:32 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:50:32 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:50:32 --> Utf8 Class Initialized
INFO - 2017-05-09 10:50:33 --> URI Class Initialized
INFO - 2017-05-09 10:50:33 --> Router Class Initialized
INFO - 2017-05-09 10:50:33 --> Output Class Initialized
INFO - 2017-05-09 10:50:33 --> Security Class Initialized
DEBUG - 2017-05-09 10:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:50:33 --> Input Class Initialized
INFO - 2017-05-09 10:50:33 --> Language Class Initialized
INFO - 2017-05-09 10:50:33 --> Loader Class Initialized
INFO - 2017-05-09 10:50:33 --> Controller Class Initialized
INFO - 2017-05-09 10:50:33 --> Model Class Initialized
INFO - 2017-05-09 10:50:33 --> Database Driver Class Initialized
INFO - 2017-05-09 10:50:33 --> Helper loaded: file_helper
INFO - 2017-05-09 10:50:33 --> Helper loaded: date_helper
INFO - 2017-05-09 10:50:33 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:33 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:34 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:34 --> Helper loaded: url_helper
INFO - 2017-05-09 10:50:34 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:50:34 --> Pagination Class Initialized
INFO - 2017-05-09 10:50:34 --> Form Validation Class Initialized
INFO - 2017-05-09 10:50:34 --> Jquery Class Initialized
INFO - 2017-05-09 10:50:34 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:50:34 --> Upload Class Initialized
INFO - 2017-05-09 10:50:34 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:50:34 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:50:35 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 10:50:35 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 10:50:35 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 10:50:35 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list_visited.php
INFO - 2017-05-09 10:50:35 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 10:50:35 --> Final output sent to browser
DEBUG - 2017-05-09 10:50:35 --> Total execution time: 2.3377
INFO - 2017-05-09 10:50:37 --> Config Class Initialized
INFO - 2017-05-09 10:50:37 --> Hooks Class Initialized
DEBUG - 2017-05-09 10:50:37 --> UTF-8 Support Enabled
INFO - 2017-05-09 10:50:37 --> Utf8 Class Initialized
INFO - 2017-05-09 10:50:38 --> URI Class Initialized
INFO - 2017-05-09 10:50:38 --> Router Class Initialized
INFO - 2017-05-09 10:50:38 --> Output Class Initialized
INFO - 2017-05-09 10:50:38 --> Security Class Initialized
DEBUG - 2017-05-09 10:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 10:50:38 --> Input Class Initialized
INFO - 2017-05-09 10:50:38 --> Language Class Initialized
INFO - 2017-05-09 10:50:38 --> Loader Class Initialized
INFO - 2017-05-09 10:50:38 --> Controller Class Initialized
INFO - 2017-05-09 10:50:38 --> Model Class Initialized
INFO - 2017-05-09 10:50:38 --> Database Driver Class Initialized
INFO - 2017-05-09 10:50:38 --> Helper loaded: file_helper
INFO - 2017-05-09 10:50:38 --> Helper loaded: date_helper
INFO - 2017-05-09 10:50:38 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 10:50:38 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:38 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:38 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:38 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:38 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Model Class Initialized
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Helper loaded: url_helper
INFO - 2017-05-09 10:50:39 --> Helper loaded: form_helper
DEBUG - 2017-05-09 10:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 10:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 10:50:39 --> Pagination Class Initialized
INFO - 2017-05-09 10:50:39 --> Form Validation Class Initialized
INFO - 2017-05-09 10:50:39 --> Jquery Class Initialized
INFO - 2017-05-09 10:50:39 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 10:50:39 --> Upload Class Initialized
INFO - 2017-05-09 10:50:39 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 10:50:39 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 10:50:40 --> Final output sent to browser
DEBUG - 2017-05-09 10:50:40 --> Total execution time: 2.7935
INFO - 2017-05-09 12:05:11 --> Config Class Initialized
INFO - 2017-05-09 12:05:11 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:11 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:11 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:12 --> URI Class Initialized
INFO - 2017-05-09 12:05:12 --> Router Class Initialized
INFO - 2017-05-09 12:05:12 --> Output Class Initialized
INFO - 2017-05-09 12:05:12 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:12 --> Input Class Initialized
INFO - 2017-05-09 12:05:12 --> Language Class Initialized
INFO - 2017-05-09 12:05:12 --> Loader Class Initialized
INFO - 2017-05-09 12:05:12 --> Controller Class Initialized
INFO - 2017-05-09 12:05:12 --> Model Class Initialized
INFO - 2017-05-09 12:05:12 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:12 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:12 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:12 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:12 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:12 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:12 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:12 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:12 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:12 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:13 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:13 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:13 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:13 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:13 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:13 --> Upload Class Initialized
INFO - 2017-05-09 12:05:13 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:13 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:14 --> Config Class Initialized
INFO - 2017-05-09 12:05:14 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:14 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:14 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:14 --> URI Class Initialized
INFO - 2017-05-09 12:05:14 --> Router Class Initialized
INFO - 2017-05-09 12:05:14 --> Output Class Initialized
INFO - 2017-05-09 12:05:14 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:14 --> Input Class Initialized
INFO - 2017-05-09 12:05:14 --> Language Class Initialized
INFO - 2017-05-09 12:05:14 --> Loader Class Initialized
INFO - 2017-05-09 12:05:14 --> Controller Class Initialized
INFO - 2017-05-09 12:05:14 --> Model Class Initialized
INFO - 2017-05-09 12:05:15 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:15 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:15 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:15 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:15 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:16 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:16 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:16 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:16 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:16 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:16 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:16 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:16 --> Upload Class Initialized
INFO - 2017-05-09 12:05:16 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:16 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:16 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/login.php
INFO - 2017-05-09 12:05:16 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:16 --> Total execution time: 2.2698
INFO - 2017-05-09 12:05:26 --> Config Class Initialized
INFO - 2017-05-09 12:05:26 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:26 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:26 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:26 --> URI Class Initialized
INFO - 2017-05-09 12:05:26 --> Router Class Initialized
INFO - 2017-05-09 12:05:26 --> Output Class Initialized
INFO - 2017-05-09 12:05:26 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:26 --> Input Class Initialized
INFO - 2017-05-09 12:05:26 --> Language Class Initialized
INFO - 2017-05-09 12:05:26 --> Loader Class Initialized
INFO - 2017-05-09 12:05:26 --> Controller Class Initialized
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
INFO - 2017-05-09 12:05:27 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:27 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:27 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:27 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:28 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:28 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:28 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:28 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:28 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:28 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:28 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:28 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:28 --> Upload Class Initialized
INFO - 2017-05-09 12:05:28 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:28 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:29 --> Config Class Initialized
INFO - 2017-05-09 12:05:29 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:29 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:29 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:29 --> URI Class Initialized
INFO - 2017-05-09 12:05:29 --> Router Class Initialized
INFO - 2017-05-09 12:05:29 --> Output Class Initialized
INFO - 2017-05-09 12:05:29 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:29 --> Input Class Initialized
INFO - 2017-05-09 12:05:29 --> Language Class Initialized
INFO - 2017-05-09 12:05:29 --> Loader Class Initialized
INFO - 2017-05-09 12:05:29 --> Controller Class Initialized
INFO - 2017-05-09 12:05:29 --> Model Class Initialized
INFO - 2017-05-09 12:05:30 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:30 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:30 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:30 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:31 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:31 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:31 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:31 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:31 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:31 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:31 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:31 --> Upload Class Initialized
INFO - 2017-05-09 12:05:31 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:31 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 12:05:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 12:05:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 12:05:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/main.php
INFO - 2017-05-09 12:05:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 12:05:31 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:32 --> Total execution time: 2.4963
INFO - 2017-05-09 12:05:33 --> Config Class Initialized
INFO - 2017-05-09 12:05:33 --> Config Class Initialized
INFO - 2017-05-09 12:05:33 --> Config Class Initialized
INFO - 2017-05-09 12:05:33 --> Config Class Initialized
INFO - 2017-05-09 12:05:33 --> Config Class Initialized
INFO - 2017-05-09 12:05:33 --> Hooks Class Initialized
INFO - 2017-05-09 12:05:33 --> Hooks Class Initialized
INFO - 2017-05-09 12:05:33 --> Hooks Class Initialized
INFO - 2017-05-09 12:05:33 --> Hooks Class Initialized
INFO - 2017-05-09 12:05:33 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 12:05:33 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:33 --> Utf8 Class Initialized
DEBUG - 2017-05-09 12:05:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 12:05:33 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:33 --> URI Class Initialized
DEBUG - 2017-05-09 12:05:33 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:33 --> URI Class Initialized
INFO - 2017-05-09 12:05:33 --> Router Class Initialized
INFO - 2017-05-09 12:05:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:05:33 --> URI Class Initialized
INFO - 2017-05-09 12:05:33 --> URI Class Initialized
INFO - 2017-05-09 12:05:33 --> Output Class Initialized
INFO - 2017-05-09 12:05:33 --> Router Class Initialized
INFO - 2017-05-09 12:05:33 --> URI Class Initialized
INFO - 2017-05-09 12:05:33 --> Router Class Initialized
INFO - 2017-05-09 12:05:33 --> Router Class Initialized
INFO - 2017-05-09 12:05:33 --> Router Class Initialized
INFO - 2017-05-09 12:05:33 --> Security Class Initialized
INFO - 2017-05-09 12:05:33 --> Output Class Initialized
INFO - 2017-05-09 12:05:33 --> Output Class Initialized
DEBUG - 2017-05-09 12:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:33 --> Output Class Initialized
INFO - 2017-05-09 12:05:33 --> Output Class Initialized
INFO - 2017-05-09 12:05:33 --> Input Class Initialized
INFO - 2017-05-09 12:05:33 --> Security Class Initialized
INFO - 2017-05-09 12:05:33 --> Security Class Initialized
INFO - 2017-05-09 12:05:33 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:33 --> Language Class Initialized
DEBUG - 2017-05-09 12:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:33 --> Security Class Initialized
INFO - 2017-05-09 12:05:33 --> Input Class Initialized
DEBUG - 2017-05-09 12:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:34 --> Input Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
INFO - 2017-05-09 12:05:34 --> Loader Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:34 --> Input Class Initialized
INFO - 2017-05-09 12:05:34 --> Input Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
INFO - 2017-05-09 12:05:34 --> Loader Class Initialized
INFO - 2017-05-09 12:05:34 --> Controller Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
INFO - 2017-05-09 12:05:34 --> Language Class Initialized
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
INFO - 2017-05-09 12:05:34 --> Loader Class Initialized
INFO - 2017-05-09 12:05:34 --> Controller Class Initialized
INFO - 2017-05-09 12:05:34 --> Loader Class Initialized
INFO - 2017-05-09 12:05:34 --> Loader Class Initialized
INFO - 2017-05-09 12:05:34 --> Controller Class Initialized
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
INFO - 2017-05-09 12:05:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:34 --> Controller Class Initialized
INFO - 2017-05-09 12:05:34 --> Controller Class Initialized
INFO - 2017-05-09 12:05:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
INFO - 2017-05-09 12:05:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
INFO - 2017-05-09 12:05:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
INFO - 2017-05-09 12:05:34 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
INFO - 2017-05-09 12:05:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:05:34 --> Helper loaded: date_helper
DEBUG - 2017-05-09 12:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:34 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:35 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:35 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:36 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:36 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:36 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:36 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:36 --> Upload Class Initialized
INFO - 2017-05-09 12:05:36 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:36 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:38 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:38 --> Total execution time: 5.4891
INFO - 2017-05-09 12:05:39 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:39 --> Config Class Initialized
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
INFO - 2017-05-09 12:05:39 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
INFO - 2017-05-09 12:05:39 --> Utf8 Class Initialized
DEBUG - 2017-05-09 12:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:39 --> URI Class Initialized
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
INFO - 2017-05-09 12:05:39 --> Router Class Initialized
DEBUG - 2017-05-09 12:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:39 --> Output Class Initialized
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
INFO - 2017-05-09 12:05:39 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
INFO - 2017-05-09 12:05:39 --> Input Class Initialized
DEBUG - 2017-05-09 12:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:39 --> Language Class Initialized
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
INFO - 2017-05-09 12:05:39 --> Loader Class Initialized
DEBUG - 2017-05-09 12:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:39 --> Controller Class Initialized
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:39 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:39 --> Model Class Initialized
INFO - 2017-05-09 12:05:40 --> Helper loaded: file_helper
DEBUG - 2017-05-09 12:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:40 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:40 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:40 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:40 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:40 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:40 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:40 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:40 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:40 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:40 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:40 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:40 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:40 --> Upload Class Initialized
INFO - 2017-05-09 12:05:40 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:40 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:44 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:44 --> Total execution time: 11.0950
INFO - 2017-05-09 12:05:44 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:44 --> Config Class Initialized
INFO - 2017-05-09 12:05:44 --> Model Class Initialized
INFO - 2017-05-09 12:05:44 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:05:44 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:44 --> Model Class Initialized
INFO - 2017-05-09 12:05:44 --> Utf8 Class Initialized
DEBUG - 2017-05-09 12:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:45 --> URI Class Initialized
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
INFO - 2017-05-09 12:05:45 --> Router Class Initialized
DEBUG - 2017-05-09 12:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:45 --> Output Class Initialized
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
INFO - 2017-05-09 12:05:45 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
INFO - 2017-05-09 12:05:45 --> Input Class Initialized
DEBUG - 2017-05-09 12:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:45 --> Language Class Initialized
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
INFO - 2017-05-09 12:05:45 --> Loader Class Initialized
DEBUG - 2017-05-09 12:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:45 --> Controller Class Initialized
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:45 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
INFO - 2017-05-09 12:05:45 --> Helper loaded: file_helper
DEBUG - 2017-05-09 12:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:45 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:45 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:46 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:46 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:46 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:46 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:46 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:46 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:46 --> Upload Class Initialized
INFO - 2017-05-09 12:05:46 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:46 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:48 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:48 --> Total execution time: 15.7534
INFO - 2017-05-09 12:05:49 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:49 --> Config Class Initialized
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
INFO - 2017-05-09 12:05:49 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:05:49 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
INFO - 2017-05-09 12:05:49 --> Utf8 Class Initialized
DEBUG - 2017-05-09 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:49 --> URI Class Initialized
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
INFO - 2017-05-09 12:05:49 --> Router Class Initialized
DEBUG - 2017-05-09 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:49 --> Output Class Initialized
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
INFO - 2017-05-09 12:05:49 --> Security Class Initialized
DEBUG - 2017-05-09 12:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
INFO - 2017-05-09 12:05:49 --> Input Class Initialized
DEBUG - 2017-05-09 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:49 --> Language Class Initialized
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
INFO - 2017-05-09 12:05:49 --> Loader Class Initialized
DEBUG - 2017-05-09 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:49 --> Controller Class Initialized
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:49 --> Database Driver Class Initialized
INFO - 2017-05-09 12:05:49 --> Model Class Initialized
INFO - 2017-05-09 12:05:50 --> Helper loaded: file_helper
DEBUG - 2017-05-09 12:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:50 --> Helper loaded: date_helper
INFO - 2017-05-09 12:05:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:50 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:50 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:50 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:50 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:50 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:50 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:50 --> Upload Class Initialized
INFO - 2017-05-09 12:05:50 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:50 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:51 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:51 --> Total execution time: 18.7276
INFO - 2017-05-09 12:05:52 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:53 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:53 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:53 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:53 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:53 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:53 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:53 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:53 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:53 --> Upload Class Initialized
INFO - 2017-05-09 12:05:53 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:53 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:55 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:55 --> Total execution time: 22.6347
INFO - 2017-05-09 12:05:56 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:57 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:57 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:57 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:05:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:05:57 --> Pagination Class Initialized
INFO - 2017-05-09 12:05:57 --> Form Validation Class Initialized
INFO - 2017-05-09 12:05:57 --> Jquery Class Initialized
INFO - 2017-05-09 12:05:57 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:05:57 --> Upload Class Initialized
INFO - 2017-05-09 12:05:57 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:05:57 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:05:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 12:05:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 12:05:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 12:05:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list_visited.php
INFO - 2017-05-09 12:05:57 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 12:05:57 --> Final output sent to browser
DEBUG - 2017-05-09 12:05:58 --> Total execution time: 18.9641
INFO - 2017-05-09 12:05:58 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:05:58 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:58 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:58 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:58 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:58 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:58 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:58 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:59 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:59 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:59 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:59 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:59 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:59 --> Model Class Initialized
DEBUG - 2017-05-09 12:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:59 --> Helper loaded: url_helper
INFO - 2017-05-09 12:05:59 --> Helper loaded: form_helper
INFO - 2017-05-09 12:05:59 --> Config Class Initialized
INFO - 2017-05-09 12:05:59 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:05:59 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 12:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:05:59 --> Utf8 Class Initialized
INFO - 2017-05-09 12:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:06:00 --> Pagination Class Initialized
INFO - 2017-05-09 12:06:00 --> URI Class Initialized
INFO - 2017-05-09 12:06:00 --> Form Validation Class Initialized
INFO - 2017-05-09 12:06:00 --> Router Class Initialized
INFO - 2017-05-09 12:06:00 --> Output Class Initialized
INFO - 2017-05-09 12:06:00 --> Jquery Class Initialized
INFO - 2017-05-09 12:06:00 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:06:00 --> Security Class Initialized
INFO - 2017-05-09 12:06:00 --> Upload Class Initialized
DEBUG - 2017-05-09 12:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:06:00 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:06:00 --> Input Class Initialized
INFO - 2017-05-09 12:06:00 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:06:00 --> Language Class Initialized
INFO - 2017-05-09 12:06:00 --> Loader Class Initialized
INFO - 2017-05-09 12:06:01 --> Controller Class Initialized
INFO - 2017-05-09 12:06:01 --> Model Class Initialized
INFO - 2017-05-09 12:06:01 --> Database Driver Class Initialized
INFO - 2017-05-09 12:06:01 --> Helper loaded: file_helper
INFO - 2017-05-09 12:06:01 --> Helper loaded: date_helper
INFO - 2017-05-09 12:06:01 --> Final output sent to browser
DEBUG - 2017-05-09 12:06:01 --> Total execution time: 16.9578
INFO - 2017-05-09 12:06:02 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:02 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:03 --> Helper loaded: url_helper
INFO - 2017-05-09 12:06:03 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:06:03 --> Pagination Class Initialized
INFO - 2017-05-09 12:06:03 --> Form Validation Class Initialized
INFO - 2017-05-09 12:06:03 --> Jquery Class Initialized
INFO - 2017-05-09 12:06:03 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:06:03 --> Upload Class Initialized
INFO - 2017-05-09 12:06:03 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:06:03 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:06:04 --> Final output sent to browser
DEBUG - 2017-05-09 12:06:04 --> Total execution time: 15.6227
INFO - 2017-05-09 12:06:05 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:05 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:06 --> Model Class Initialized
DEBUG - 2017-05-09 12:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:06 --> Helper loaded: url_helper
INFO - 2017-05-09 12:06:06 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:06:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:06:06 --> Pagination Class Initialized
INFO - 2017-05-09 12:06:06 --> Form Validation Class Initialized
INFO - 2017-05-09 12:06:06 --> Jquery Class Initialized
INFO - 2017-05-09 12:06:06 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:06:06 --> Upload Class Initialized
INFO - 2017-05-09 12:06:06 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:06:06 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:06:13 --> Final output sent to browser
DEBUG - 2017-05-09 12:06:13 --> Total execution time: 13.3275
INFO - 2017-05-09 12:23:02 --> Config Class Initialized
INFO - 2017-05-09 12:23:02 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:23:02 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:23:02 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:02 --> URI Class Initialized
INFO - 2017-05-09 12:23:02 --> Router Class Initialized
INFO - 2017-05-09 12:23:02 --> Output Class Initialized
INFO - 2017-05-09 12:23:02 --> Security Class Initialized
DEBUG - 2017-05-09 12:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:23:02 --> Input Class Initialized
INFO - 2017-05-09 12:23:02 --> Language Class Initialized
INFO - 2017-05-09 12:23:02 --> Loader Class Initialized
INFO - 2017-05-09 12:23:02 --> Controller Class Initialized
INFO - 2017-05-09 12:23:02 --> Model Class Initialized
INFO - 2017-05-09 12:23:02 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:02 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:03 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:03 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:03 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:04 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:04 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:04 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:04 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:04 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:04 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:04 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:04 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:04 --> Upload Class Initialized
INFO - 2017-05-09 12:23:04 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:04 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:05 --> Config Class Initialized
INFO - 2017-05-09 12:23:05 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:23:05 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:23:05 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:05 --> URI Class Initialized
INFO - 2017-05-09 12:23:05 --> Router Class Initialized
INFO - 2017-05-09 12:23:05 --> Output Class Initialized
INFO - 2017-05-09 12:23:05 --> Security Class Initialized
DEBUG - 2017-05-09 12:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:23:05 --> Input Class Initialized
INFO - 2017-05-09 12:23:05 --> Language Class Initialized
INFO - 2017-05-09 12:23:05 --> Loader Class Initialized
INFO - 2017-05-09 12:23:06 --> Controller Class Initialized
INFO - 2017-05-09 12:23:06 --> Model Class Initialized
INFO - 2017-05-09 12:23:06 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:06 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:06 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:06 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:06 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:06 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:06 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:06 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:06 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:07 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:07 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:08 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:08 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:08 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:08 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:08 --> Upload Class Initialized
INFO - 2017-05-09 12:23:08 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:08 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:08 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/login.php
INFO - 2017-05-09 12:23:08 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:08 --> Total execution time: 3.4363
INFO - 2017-05-09 12:23:26 --> Config Class Initialized
INFO - 2017-05-09 12:23:26 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:23:26 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:23:26 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:26 --> URI Class Initialized
INFO - 2017-05-09 12:23:26 --> Router Class Initialized
INFO - 2017-05-09 12:23:26 --> Output Class Initialized
INFO - 2017-05-09 12:23:26 --> Security Class Initialized
DEBUG - 2017-05-09 12:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:23:26 --> Input Class Initialized
INFO - 2017-05-09 12:23:26 --> Language Class Initialized
INFO - 2017-05-09 12:23:26 --> Loader Class Initialized
INFO - 2017-05-09 12:23:26 --> Controller Class Initialized
INFO - 2017-05-09 12:23:26 --> Model Class Initialized
INFO - 2017-05-09 12:23:26 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:26 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:26 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:27 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:28 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:28 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:28 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:28 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:28 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:28 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:28 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:28 --> Upload Class Initialized
INFO - 2017-05-09 12:23:28 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:28 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:29 --> Config Class Initialized
INFO - 2017-05-09 12:23:29 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:23:29 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:23:29 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:29 --> URI Class Initialized
INFO - 2017-05-09 12:23:29 --> Router Class Initialized
INFO - 2017-05-09 12:23:29 --> Output Class Initialized
INFO - 2017-05-09 12:23:29 --> Security Class Initialized
DEBUG - 2017-05-09 12:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:23:29 --> Input Class Initialized
INFO - 2017-05-09 12:23:29 --> Language Class Initialized
INFO - 2017-05-09 12:23:29 --> Loader Class Initialized
INFO - 2017-05-09 12:23:29 --> Controller Class Initialized
INFO - 2017-05-09 12:23:29 --> Model Class Initialized
INFO - 2017-05-09 12:23:29 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:29 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:29 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:29 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:29 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:29 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:30 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:30 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:31 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:31 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:31 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:31 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:31 --> Upload Class Initialized
INFO - 2017-05-09 12:23:31 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:31 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 12:23:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 12:23:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 12:23:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/main.php
INFO - 2017-05-09 12:23:31 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 12:23:31 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:31 --> Total execution time: 2.8935
INFO - 2017-05-09 12:23:32 --> Config Class Initialized
INFO - 2017-05-09 12:23:32 --> Config Class Initialized
INFO - 2017-05-09 12:23:32 --> Config Class Initialized
INFO - 2017-05-09 12:23:32 --> Config Class Initialized
INFO - 2017-05-09 12:23:32 --> Hooks Class Initialized
INFO - 2017-05-09 12:23:32 --> Config Class Initialized
INFO - 2017-05-09 12:23:32 --> Config Class Initialized
INFO - 2017-05-09 12:23:32 --> Hooks Class Initialized
INFO - 2017-05-09 12:23:32 --> Hooks Class Initialized
INFO - 2017-05-09 12:23:33 --> Hooks Class Initialized
INFO - 2017-05-09 12:23:33 --> Hooks Class Initialized
INFO - 2017-05-09 12:23:33 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 12:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 12:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 12:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 12:23:33 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:23:33 --> Utf8 Class Initialized
DEBUG - 2017-05-09 12:23:33 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:23:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:33 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:33 --> URI Class Initialized
INFO - 2017-05-09 12:23:33 --> URI Class Initialized
INFO - 2017-05-09 12:23:33 --> URI Class Initialized
INFO - 2017-05-09 12:23:33 --> URI Class Initialized
INFO - 2017-05-09 12:23:33 --> URI Class Initialized
INFO - 2017-05-09 12:23:33 --> Router Class Initialized
INFO - 2017-05-09 12:23:33 --> URI Class Initialized
INFO - 2017-05-09 12:23:33 --> Router Class Initialized
INFO - 2017-05-09 12:23:33 --> Router Class Initialized
INFO - 2017-05-09 12:23:33 --> Router Class Initialized
INFO - 2017-05-09 12:23:33 --> Router Class Initialized
INFO - 2017-05-09 12:23:33 --> Output Class Initialized
INFO - 2017-05-09 12:23:33 --> Router Class Initialized
INFO - 2017-05-09 12:23:33 --> Output Class Initialized
INFO - 2017-05-09 12:23:33 --> Output Class Initialized
INFO - 2017-05-09 12:23:33 --> Output Class Initialized
INFO - 2017-05-09 12:23:33 --> Output Class Initialized
INFO - 2017-05-09 12:23:33 --> Security Class Initialized
INFO - 2017-05-09 12:23:33 --> Security Class Initialized
INFO - 2017-05-09 12:23:33 --> Security Class Initialized
INFO - 2017-05-09 12:23:33 --> Output Class Initialized
INFO - 2017-05-09 12:23:33 --> Security Class Initialized
INFO - 2017-05-09 12:23:33 --> Security Class Initialized
INFO - 2017-05-09 12:23:33 --> Security Class Initialized
DEBUG - 2017-05-09 12:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 12:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 12:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 12:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:23:33 --> Input Class Initialized
DEBUG - 2017-05-09 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:23:33 --> Input Class Initialized
INFO - 2017-05-09 12:23:33 --> Input Class Initialized
INFO - 2017-05-09 12:23:33 --> Input Class Initialized
INFO - 2017-05-09 12:23:33 --> Language Class Initialized
INFO - 2017-05-09 12:23:33 --> Input Class Initialized
INFO - 2017-05-09 12:23:33 --> Language Class Initialized
INFO - 2017-05-09 12:23:33 --> Language Class Initialized
INFO - 2017-05-09 12:23:33 --> Input Class Initialized
INFO - 2017-05-09 12:23:33 --> Language Class Initialized
INFO - 2017-05-09 12:23:33 --> Language Class Initialized
INFO - 2017-05-09 12:23:33 --> Loader Class Initialized
INFO - 2017-05-09 12:23:33 --> Loader Class Initialized
INFO - 2017-05-09 12:23:33 --> Loader Class Initialized
INFO - 2017-05-09 12:23:33 --> Loader Class Initialized
INFO - 2017-05-09 12:23:33 --> Controller Class Initialized
INFO - 2017-05-09 12:23:33 --> Loader Class Initialized
INFO - 2017-05-09 12:23:33 --> Language Class Initialized
INFO - 2017-05-09 12:23:34 --> Controller Class Initialized
INFO - 2017-05-09 12:23:34 --> Controller Class Initialized
INFO - 2017-05-09 12:23:34 --> Controller Class Initialized
INFO - 2017-05-09 12:23:34 --> Controller Class Initialized
INFO - 2017-05-09 12:23:34 --> Loader Class Initialized
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
INFO - 2017-05-09 12:23:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:34 --> Controller Class Initialized
INFO - 2017-05-09 12:23:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
INFO - 2017-05-09 12:23:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:34 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:34 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:34 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:34 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
INFO - 2017-05-09 12:23:34 --> Helper loaded: date_helper
DEBUG - 2017-05-09 12:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:34 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:35 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:35 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:35 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:35 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:35 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:36 --> Upload Class Initialized
INFO - 2017-05-09 12:23:36 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:36 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:37 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:37 --> Total execution time: 4.3555
INFO - 2017-05-09 12:23:37 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:37 --> Config Class Initialized
INFO - 2017-05-09 12:23:37 --> Model Class Initialized
INFO - 2017-05-09 12:23:37 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:23:37 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:23:37 --> Model Class Initialized
INFO - 2017-05-09 12:23:37 --> Utf8 Class Initialized
DEBUG - 2017-05-09 12:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:37 --> URI Class Initialized
INFO - 2017-05-09 12:23:37 --> Model Class Initialized
INFO - 2017-05-09 12:23:37 --> Router Class Initialized
DEBUG - 2017-05-09 12:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:37 --> Output Class Initialized
INFO - 2017-05-09 12:23:37 --> Model Class Initialized
INFO - 2017-05-09 12:23:37 --> Security Class Initialized
DEBUG - 2017-05-09 12:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:23:37 --> Model Class Initialized
INFO - 2017-05-09 12:23:37 --> Input Class Initialized
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Language Class Initialized
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
INFO - 2017-05-09 12:23:38 --> Loader Class Initialized
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Controller Class Initialized
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
INFO - 2017-05-09 12:23:38 --> Helper loaded: file_helper
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:38 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:38 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:39 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:39 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:39 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:39 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:39 --> Upload Class Initialized
INFO - 2017-05-09 12:23:39 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:39 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:40 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:40 --> Total execution time: 7.2375
INFO - 2017-05-09 12:23:40 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:40 --> Config Class Initialized
INFO - 2017-05-09 12:23:40 --> Model Class Initialized
INFO - 2017-05-09 12:23:40 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:23:40 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:23:40 --> Model Class Initialized
INFO - 2017-05-09 12:23:40 --> Utf8 Class Initialized
DEBUG - 2017-05-09 12:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:40 --> URI Class Initialized
INFO - 2017-05-09 12:23:40 --> Model Class Initialized
INFO - 2017-05-09 12:23:40 --> Router Class Initialized
DEBUG - 2017-05-09 12:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:40 --> Output Class Initialized
INFO - 2017-05-09 12:23:40 --> Model Class Initialized
INFO - 2017-05-09 12:23:40 --> Security Class Initialized
DEBUG - 2017-05-09 12:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-09 12:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:23:40 --> Model Class Initialized
INFO - 2017-05-09 12:23:40 --> Input Class Initialized
DEBUG - 2017-05-09 12:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:40 --> Language Class Initialized
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
INFO - 2017-05-09 12:23:41 --> Loader Class Initialized
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Controller Class Initialized
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Database Driver Class Initialized
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
INFO - 2017-05-09 12:23:41 --> Helper loaded: file_helper
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:41 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:41 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:42 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:42 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:42 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:42 --> Upload Class Initialized
INFO - 2017-05-09 12:23:42 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:42 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:43 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:43 --> Total execution time: 10.3004
INFO - 2017-05-09 12:23:43 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:43 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:44 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:44 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:44 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:44 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:44 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:44 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:44 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:44 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:44 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:44 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:44 --> Upload Class Initialized
INFO - 2017-05-09 12:23:44 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:44 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:45 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:45 --> Total execution time: 12.6326
INFO - 2017-05-09 12:23:45 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:45 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:45 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:45 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:45 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:45 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:46 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:46 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:46 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:46 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:46 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:46 --> Upload Class Initialized
INFO - 2017-05-09 12:23:46 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:47 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:47 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:47 --> Total execution time: 15.0723
INFO - 2017-05-09 12:23:48 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:48 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:49 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:49 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:49 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:49 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:49 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:49 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:49 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:49 --> Upload Class Initialized
INFO - 2017-05-09 12:23:49 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:49 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:50 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:50 --> Total execution time: 17.4673
INFO - 2017-05-09 12:23:50 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:51 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:51 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:51 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:51 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:51 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:51 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:51 --> Upload Class Initialized
INFO - 2017-05-09 12:23:51 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:51 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 12:23:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 12:23:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 12:23:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list_visited.php
INFO - 2017-05-09 12:23:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 12:23:52 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:52 --> Total execution time: 15.1386
INFO - 2017-05-09 12:23:52 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:52 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:53 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:53 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:53 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:53 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:53 --> Config Class Initialized
INFO - 2017-05-09 12:23:53 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:53 --> Hooks Class Initialized
INFO - 2017-05-09 12:23:53 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-09 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:53 --> Utf8 Class Initialized
INFO - 2017-05-09 12:23:53 --> Model Class Initialized
INFO - 2017-05-09 12:23:53 --> URI Class Initialized
DEBUG - 2017-05-09 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:53 --> Router Class Initialized
INFO - 2017-05-09 12:23:53 --> Model Class Initialized
INFO - 2017-05-09 12:23:53 --> Output Class Initialized
DEBUG - 2017-05-09 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:54 --> Security Class Initialized
INFO - 2017-05-09 12:23:54 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-09 12:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:54 --> Input Class Initialized
INFO - 2017-05-09 12:23:54 --> Language Class Initialized
INFO - 2017-05-09 12:23:54 --> Model Class Initialized
INFO - 2017-05-09 12:23:54 --> Loader Class Initialized
DEBUG - 2017-05-09 12:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:54 --> Controller Class Initialized
INFO - 2017-05-09 12:23:54 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:54 --> Model Class Initialized
INFO - 2017-05-09 12:23:54 --> Helper loaded: form_helper
INFO - 2017-05-09 12:23:54 --> Database Driver Class Initialized
DEBUG - 2017-05-09 12:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:54 --> Helper loaded: file_helper
INFO - 2017-05-09 12:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:54 --> Helper loaded: date_helper
INFO - 2017-05-09 12:23:54 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:54 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:54 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:54 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:54 --> Upload Class Initialized
INFO - 2017-05-09 12:23:54 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:54 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:23:55 --> Final output sent to browser
DEBUG - 2017-05-09 12:23:55 --> Total execution time: 15.3620
INFO - 2017-05-09 12:23:55 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:23:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:56 --> Helper loaded: url_helper
INFO - 2017-05-09 12:23:56 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:23:57 --> Pagination Class Initialized
INFO - 2017-05-09 12:23:57 --> Form Validation Class Initialized
INFO - 2017-05-09 12:23:57 --> Jquery Class Initialized
INFO - 2017-05-09 12:23:57 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:23:57 --> Upload Class Initialized
INFO - 2017-05-09 12:23:57 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:23:57 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:24:00 --> Final output sent to browser
DEBUG - 2017-05-09 12:24:00 --> Total execution time: 7.3971
INFO - 2017-05-09 12:24:49 --> Config Class Initialized
INFO - 2017-05-09 12:24:49 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:24:49 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:24:49 --> Utf8 Class Initialized
INFO - 2017-05-09 12:24:49 --> URI Class Initialized
INFO - 2017-05-09 12:24:50 --> Router Class Initialized
INFO - 2017-05-09 12:24:50 --> Output Class Initialized
INFO - 2017-05-09 12:24:50 --> Security Class Initialized
DEBUG - 2017-05-09 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:24:50 --> Input Class Initialized
INFO - 2017-05-09 12:24:50 --> Language Class Initialized
INFO - 2017-05-09 12:24:50 --> Loader Class Initialized
INFO - 2017-05-09 12:24:50 --> Controller Class Initialized
INFO - 2017-05-09 12:24:50 --> Model Class Initialized
INFO - 2017-05-09 12:24:50 --> Database Driver Class Initialized
INFO - 2017-05-09 12:24:50 --> Helper loaded: file_helper
INFO - 2017-05-09 12:24:50 --> Helper loaded: date_helper
INFO - 2017-05-09 12:24:50 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:24:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:50 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Helper loaded: url_helper
INFO - 2017-05-09 12:24:51 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:24:51 --> Pagination Class Initialized
INFO - 2017-05-09 12:24:51 --> Form Validation Class Initialized
INFO - 2017-05-09 12:24:51 --> Jquery Class Initialized
INFO - 2017-05-09 12:24:51 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:24:51 --> Upload Class Initialized
INFO - 2017-05-09 12:24:52 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:24:52 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:24:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/header.php
INFO - 2017-05-09 12:24:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-09 12:24:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-09 12:24:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/patients/list.php
INFO - 2017-05-09 12:24:52 --> File loaded: C:\xampp\htdocs\emedirec_last_050917_tk\application\views\theme/defualt/template/footer.php
INFO - 2017-05-09 12:24:52 --> Final output sent to browser
DEBUG - 2017-05-09 12:24:52 --> Total execution time: 3.0759
INFO - 2017-05-09 12:24:54 --> Config Class Initialized
INFO - 2017-05-09 12:24:54 --> Hooks Class Initialized
DEBUG - 2017-05-09 12:24:54 --> UTF-8 Support Enabled
INFO - 2017-05-09 12:24:54 --> Utf8 Class Initialized
INFO - 2017-05-09 12:24:54 --> URI Class Initialized
INFO - 2017-05-09 12:24:54 --> Router Class Initialized
INFO - 2017-05-09 12:24:54 --> Output Class Initialized
INFO - 2017-05-09 12:24:54 --> Security Class Initialized
DEBUG - 2017-05-09 12:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-09 12:24:54 --> Input Class Initialized
INFO - 2017-05-09 12:24:54 --> Language Class Initialized
INFO - 2017-05-09 12:24:54 --> Loader Class Initialized
INFO - 2017-05-09 12:24:54 --> Controller Class Initialized
INFO - 2017-05-09 12:24:54 --> Model Class Initialized
INFO - 2017-05-09 12:24:54 --> Database Driver Class Initialized
INFO - 2017-05-09 12:24:54 --> Helper loaded: file_helper
INFO - 2017-05-09 12:24:55 --> Helper loaded: date_helper
INFO - 2017-05-09 12:24:55 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:55 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:56 --> Model Class Initialized
DEBUG - 2017-05-09 12:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:56 --> Helper loaded: url_helper
INFO - 2017-05-09 12:24:56 --> Helper loaded: form_helper
DEBUG - 2017-05-09 12:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-09 12:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-09 12:24:56 --> Pagination Class Initialized
INFO - 2017-05-09 12:24:56 --> Form Validation Class Initialized
INFO - 2017-05-09 12:24:56 --> Jquery Class Initialized
INFO - 2017-05-09 12:24:56 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-09 12:24:56 --> Upload Class Initialized
INFO - 2017-05-09 12:24:56 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-09 12:24:56 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-09 12:25:01 --> Final output sent to browser
DEBUG - 2017-05-09 12:25:01 --> Total execution time: 7.0239
