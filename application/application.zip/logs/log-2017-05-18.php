<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-18 04:43:13 --> Config Class Initialized
INFO - 2017-05-18 04:43:13 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:13 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:13 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:13 --> URI Class Initialized
INFO - 2017-05-18 04:43:13 --> Router Class Initialized
INFO - 2017-05-18 04:43:13 --> Output Class Initialized
INFO - 2017-05-18 04:43:13 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:13 --> Input Class Initialized
INFO - 2017-05-18 04:43:13 --> Language Class Initialized
INFO - 2017-05-18 04:43:14 --> Loader Class Initialized
INFO - 2017-05-18 04:43:14 --> Controller Class Initialized
INFO - 2017-05-18 04:43:14 --> Model Class Initialized
INFO - 2017-05-18 04:43:14 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:14 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:14 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:15 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:15 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:16 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:16 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:16 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:16 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:16 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:16 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:16 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:16 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:16 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:16 --> Upload Class Initialized
INFO - 2017-05-18 04:43:16 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:16 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:16 --> Config Class Initialized
INFO - 2017-05-18 04:43:16 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:16 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:16 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:16 --> URI Class Initialized
INFO - 2017-05-18 04:43:16 --> Router Class Initialized
INFO - 2017-05-18 04:43:17 --> Output Class Initialized
INFO - 2017-05-18 04:43:17 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:17 --> Input Class Initialized
INFO - 2017-05-18 04:43:17 --> Language Class Initialized
INFO - 2017-05-18 04:43:17 --> Loader Class Initialized
INFO - 2017-05-18 04:43:17 --> Controller Class Initialized
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
INFO - 2017-05-18 04:43:17 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:17 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:17 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:17 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:17 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:17 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:17 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:17 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:17 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:17 --> Upload Class Initialized
INFO - 2017-05-18 04:43:17 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:17 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:17 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-18 04:43:17 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-18 04:43:17 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-18 04:43:17 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/main.php
INFO - 2017-05-18 04:43:17 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-18 04:43:17 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:17 --> Total execution time: 0.9371
INFO - 2017-05-18 04:43:18 --> Config Class Initialized
INFO - 2017-05-18 04:43:18 --> Config Class Initialized
INFO - 2017-05-18 04:43:18 --> Config Class Initialized
INFO - 2017-05-18 04:43:18 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:18 --> Config Class Initialized
INFO - 2017-05-18 04:43:18 --> Config Class Initialized
INFO - 2017-05-18 04:43:18 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:18 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:18 --> Config Class Initialized
DEBUG - 2017-05-18 04:43:18 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:18 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:18 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:18 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:18 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:18 --> Utf8 Class Initialized
DEBUG - 2017-05-18 04:43:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-18 04:43:18 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:18 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:18 --> Utf8 Class Initialized
DEBUG - 2017-05-18 04:43:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-18 04:43:18 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:18 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:18 --> URI Class Initialized
INFO - 2017-05-18 04:43:19 --> URI Class Initialized
INFO - 2017-05-18 04:43:19 --> URI Class Initialized
INFO - 2017-05-18 04:43:19 --> URI Class Initialized
INFO - 2017-05-18 04:43:19 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:19 --> Router Class Initialized
INFO - 2017-05-18 04:43:19 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:19 --> Router Class Initialized
INFO - 2017-05-18 04:43:19 --> Router Class Initialized
INFO - 2017-05-18 04:43:19 --> Output Class Initialized
INFO - 2017-05-18 04:43:19 --> URI Class Initialized
INFO - 2017-05-18 04:43:19 --> URI Class Initialized
INFO - 2017-05-18 04:43:19 --> Security Class Initialized
INFO - 2017-05-18 04:43:19 --> Output Class Initialized
INFO - 2017-05-18 04:43:19 --> Router Class Initialized
INFO - 2017-05-18 04:43:19 --> Router Class Initialized
INFO - 2017-05-18 04:43:19 --> Output Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:19 --> Security Class Initialized
INFO - 2017-05-18 04:43:19 --> Router Class Initialized
INFO - 2017-05-18 04:43:19 --> Output Class Initialized
INFO - 2017-05-18 04:43:19 --> Security Class Initialized
INFO - 2017-05-18 04:43:19 --> Output Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-18 04:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:19 --> Input Class Initialized
INFO - 2017-05-18 04:43:19 --> Input Class Initialized
INFO - 2017-05-18 04:43:19 --> Security Class Initialized
INFO - 2017-05-18 04:43:19 --> Input Class Initialized
INFO - 2017-05-18 04:43:19 --> Output Class Initialized
INFO - 2017-05-18 04:43:19 --> Security Class Initialized
INFO - 2017-05-18 04:43:19 --> Language Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:19 --> Language Class Initialized
INFO - 2017-05-18 04:43:19 --> Language Class Initialized
INFO - 2017-05-18 04:43:19 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:19 --> Input Class Initialized
INFO - 2017-05-18 04:43:19 --> Input Class Initialized
INFO - 2017-05-18 04:43:19 --> Loader Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:19 --> Language Class Initialized
INFO - 2017-05-18 04:43:19 --> Controller Class Initialized
INFO - 2017-05-18 04:43:19 --> Input Class Initialized
INFO - 2017-05-18 04:43:19 --> Language Class Initialized
INFO - 2017-05-18 04:43:19 --> Language Class Initialized
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
INFO - 2017-05-18 04:43:19 --> Loader Class Initialized
INFO - 2017-05-18 04:43:19 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:19 --> Controller Class Initialized
INFO - 2017-05-18 04:43:19 --> Loader Class Initialized
INFO - 2017-05-18 04:43:19 --> Loader Class Initialized
INFO - 2017-05-18 04:43:19 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:19 --> Loader Class Initialized
INFO - 2017-05-18 04:43:19 --> Loader Class Initialized
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
INFO - 2017-05-18 04:43:19 --> Controller Class Initialized
INFO - 2017-05-18 04:43:19 --> Controller Class Initialized
INFO - 2017-05-18 04:43:19 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:19 --> Controller Class Initialized
INFO - 2017-05-18 04:43:19 --> Controller Class Initialized
INFO - 2017-05-18 04:43:19 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
INFO - 2017-05-18 04:43:19 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
INFO - 2017-05-18 04:43:19 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:19 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
INFO - 2017-05-18 04:43:19 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:19 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:19 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:19 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:19 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:19 --> Helper loaded: file_helper
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:19 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:19 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:19 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
INFO - 2017-05-18 04:43:19 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:19 --> Helper loaded: date_helper
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:19 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:19 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:19 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:19 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:19 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:19 --> Upload Class Initialized
INFO - 2017-05-18 04:43:19 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:19 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:20 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:20 --> Total execution time: 1.6281
INFO - 2017-05-18 04:43:20 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
INFO - 2017-05-18 04:43:20 --> Config Class Initialized
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:20 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:20 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
INFO - 2017-05-18 04:43:20 --> URI Class Initialized
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:20 --> Router Class Initialized
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
INFO - 2017-05-18 04:43:20 --> Output Class Initialized
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:20 --> Security Class Initialized
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:20 --> Input Class Initialized
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
INFO - 2017-05-18 04:43:20 --> Language Class Initialized
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:20 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Loader Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Controller Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Helper loaded: file_helper
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:21 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:21 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:21 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:21 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:21 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:21 --> Upload Class Initialized
INFO - 2017-05-18 04:43:21 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:21 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:21 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:21 --> Total execution time: 2.5498
INFO - 2017-05-18 04:43:21 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Config Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> URI Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Router Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Output Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Security Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Input Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Language Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Loader Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Controller Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Database Driver Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
INFO - 2017-05-18 04:43:21 --> Helper loaded: date_helper
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:21 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:22 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:22 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:22 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:22 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:22 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:22 --> Upload Class Initialized
INFO - 2017-05-18 04:43:22 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:22 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:22 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:22 --> Total execution time: 3.4275
INFO - 2017-05-18 04:43:22 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:22 --> Config Class Initialized
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
INFO - 2017-05-18 04:43:22 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-18 04:43:22 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
INFO - 2017-05-18 04:43:22 --> Utf8 Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> URI Class Initialized
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
INFO - 2017-05-18 04:43:22 --> Router Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Output Class Initialized
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
INFO - 2017-05-18 04:43:22 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-18 04:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
INFO - 2017-05-18 04:43:22 --> Input Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Language Class Initialized
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Loader Class Initialized
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
INFO - 2017-05-18 04:43:22 --> Controller Class Initialized
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Model Class Initialized
INFO - 2017-05-18 04:43:22 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:22 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:22 --> Helper loaded: form_helper
INFO - 2017-05-18 04:43:22 --> Helper loaded: file_helper
DEBUG - 2017-05-18 04:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:22 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:22 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:22 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:22 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:22 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:22 --> Upload Class Initialized
INFO - 2017-05-18 04:43:23 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:23 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:23 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:23 --> Total execution time: 4.3431
INFO - 2017-05-18 04:43:23 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:23 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:23 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:23 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:23 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:23 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:23 --> Upload Class Initialized
INFO - 2017-05-18 04:43:23 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:23 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:24 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:24 --> Total execution time: 5.1865
INFO - 2017-05-18 04:43:24 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:24 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:24 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:24 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:24 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:24 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:24 --> Upload Class Initialized
INFO - 2017-05-18 04:43:24 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:24 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:24 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:24 --> Total execution time: 5.9726
INFO - 2017-05-18 04:43:25 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:25 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:25 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:25 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:25 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:25 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:25 --> Upload Class Initialized
INFO - 2017-05-18 04:43:25 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:25 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:26 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:26 --> Total execution time: 5.3225
INFO - 2017-05-18 04:43:26 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:26 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:26 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:26 --> Config Class Initialized
INFO - 2017-05-18 04:43:26 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:26 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:26 --> Jquery Class Initialized
DEBUG - 2017-05-18 04:43:26 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:26 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:26 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:26 --> Upload Class Initialized
INFO - 2017-05-18 04:43:26 --> URI Class Initialized
INFO - 2017-05-18 04:43:26 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:26 --> Router Class Initialized
INFO - 2017-05-18 04:43:26 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:26 --> Output Class Initialized
INFO - 2017-05-18 04:43:26 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:26 --> Input Class Initialized
INFO - 2017-05-18 04:43:26 --> Language Class Initialized
INFO - 2017-05-18 04:43:26 --> Loader Class Initialized
INFO - 2017-05-18 04:43:26 --> Controller Class Initialized
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
INFO - 2017-05-18 04:43:26 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:26 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:26 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:26 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:26 --> Total execution time: 5.3254
INFO - 2017-05-18 04:43:26 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:26 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:27 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:27 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:27 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:27 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:27 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:27 --> Upload Class Initialized
INFO - 2017-05-18 04:43:27 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:27 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:27 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:27 --> Total execution time: 5.3139
INFO - 2017-05-18 04:43:27 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:27 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:28 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:28 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:28 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:28 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:28 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:28 --> Upload Class Initialized
INFO - 2017-05-18 04:43:28 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:28 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:28 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-18 04:43:28 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-18 04:43:28 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-18 04:43:28 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/diagnostics/list.php
INFO - 2017-05-18 04:43:28 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-18 04:43:28 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:28 --> Total execution time: 2.4159
INFO - 2017-05-18 04:43:29 --> Config Class Initialized
INFO - 2017-05-18 04:43:29 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:29 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:29 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:29 --> URI Class Initialized
INFO - 2017-05-18 04:43:29 --> Router Class Initialized
INFO - 2017-05-18 04:43:29 --> Output Class Initialized
INFO - 2017-05-18 04:43:29 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:29 --> Input Class Initialized
INFO - 2017-05-18 04:43:29 --> Language Class Initialized
INFO - 2017-05-18 04:43:29 --> Loader Class Initialized
INFO - 2017-05-18 04:43:29 --> Controller Class Initialized
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
INFO - 2017-05-18 04:43:29 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:29 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:29 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:29 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:29 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:30 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:30 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:30 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:30 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:30 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:30 --> Upload Class Initialized
INFO - 2017-05-18 04:43:30 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:30 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:30 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:30 --> Total execution time: 1.0874
INFO - 2017-05-18 04:43:33 --> Config Class Initialized
INFO - 2017-05-18 04:43:33 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:33 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:34 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:34 --> URI Class Initialized
INFO - 2017-05-18 04:43:34 --> Router Class Initialized
INFO - 2017-05-18 04:43:34 --> Output Class Initialized
INFO - 2017-05-18 04:43:34 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:34 --> Input Class Initialized
INFO - 2017-05-18 04:43:34 --> Language Class Initialized
INFO - 2017-05-18 04:43:34 --> Loader Class Initialized
INFO - 2017-05-18 04:43:34 --> Controller Class Initialized
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
INFO - 2017-05-18 04:43:34 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:34 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:34 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:34 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:34 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:34 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:34 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:34 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:34 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:34 --> Upload Class Initialized
INFO - 2017-05-18 04:43:34 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:34 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:34 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-18 04:43:35 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-18 04:43:35 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-18 04:43:35 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/diagnostics/list.php
INFO - 2017-05-18 04:43:35 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-18 04:43:35 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:35 --> Total execution time: 1.1047
INFO - 2017-05-18 04:43:35 --> Config Class Initialized
INFO - 2017-05-18 04:43:35 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:35 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:35 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:35 --> URI Class Initialized
INFO - 2017-05-18 04:43:35 --> Router Class Initialized
INFO - 2017-05-18 04:43:35 --> Output Class Initialized
INFO - 2017-05-18 04:43:35 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:35 --> Input Class Initialized
INFO - 2017-05-18 04:43:35 --> Language Class Initialized
INFO - 2017-05-18 04:43:35 --> Loader Class Initialized
INFO - 2017-05-18 04:43:35 --> Controller Class Initialized
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
INFO - 2017-05-18 04:43:35 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:35 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:35 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:35 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:35 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:36 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:36 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:36 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:36 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:36 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:36 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:36 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:36 --> Upload Class Initialized
INFO - 2017-05-18 04:43:36 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:36 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:36 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:36 --> Total execution time: 1.1933
INFO - 2017-05-18 04:43:37 --> Config Class Initialized
INFO - 2017-05-18 04:43:37 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:37 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:37 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:37 --> URI Class Initialized
DEBUG - 2017-05-18 04:43:37 --> No URI present. Default controller set.
INFO - 2017-05-18 04:43:37 --> Router Class Initialized
INFO - 2017-05-18 04:43:37 --> Output Class Initialized
INFO - 2017-05-18 04:43:37 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:37 --> Input Class Initialized
INFO - 2017-05-18 04:43:37 --> Language Class Initialized
INFO - 2017-05-18 04:43:37 --> Loader Class Initialized
INFO - 2017-05-18 04:43:37 --> Controller Class Initialized
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
INFO - 2017-05-18 04:43:37 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:37 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:37 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:37 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:37 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:37 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:37 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:37 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:37 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:37 --> Upload Class Initialized
INFO - 2017-05-18 04:43:37 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:37 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:38 --> Config Class Initialized
INFO - 2017-05-18 04:43:38 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:38 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:38 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:38 --> URI Class Initialized
INFO - 2017-05-18 04:43:38 --> Router Class Initialized
INFO - 2017-05-18 04:43:38 --> Output Class Initialized
INFO - 2017-05-18 04:43:38 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:38 --> Input Class Initialized
INFO - 2017-05-18 04:43:38 --> Language Class Initialized
INFO - 2017-05-18 04:43:38 --> Loader Class Initialized
INFO - 2017-05-18 04:43:38 --> Controller Class Initialized
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
INFO - 2017-05-18 04:43:38 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:38 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:38 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:38 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:38 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:38 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:38 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:38 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:38 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:38 --> Upload Class Initialized
INFO - 2017-05-18 04:43:38 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:38 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-18 04:43:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-18 04:43:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-18 04:43:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/main.php
INFO - 2017-05-18 04:43:39 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-18 04:43:39 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:39 --> Total execution time: 0.9182
INFO - 2017-05-18 04:43:39 --> Config Class Initialized
INFO - 2017-05-18 04:43:39 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:39 --> Config Class Initialized
DEBUG - 2017-05-18 04:43:39 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:39 --> Config Class Initialized
INFO - 2017-05-18 04:43:39 --> Config Class Initialized
INFO - 2017-05-18 04:43:39 --> Config Class Initialized
INFO - 2017-05-18 04:43:39 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:39 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:39 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:39 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:39 --> Config Class Initialized
DEBUG - 2017-05-18 04:43:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-18 04:43:39 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:39 --> URI Class Initialized
DEBUG - 2017-05-18 04:43:39 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:39 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:39 --> Hooks Class Initialized
INFO - 2017-05-18 04:43:39 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:39 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:39 --> Utf8 Class Initialized
DEBUG - 2017-05-18 04:43:39 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:39 --> Router Class Initialized
DEBUG - 2017-05-18 04:43:39 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:39 --> URI Class Initialized
INFO - 2017-05-18 04:43:39 --> URI Class Initialized
INFO - 2017-05-18 04:43:39 --> URI Class Initialized
INFO - 2017-05-18 04:43:39 --> Output Class Initialized
INFO - 2017-05-18 04:43:39 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:39 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:39 --> Router Class Initialized
INFO - 2017-05-18 04:43:39 --> Router Class Initialized
INFO - 2017-05-18 04:43:39 --> Router Class Initialized
INFO - 2017-05-18 04:43:39 --> URI Class Initialized
INFO - 2017-05-18 04:43:39 --> Security Class Initialized
INFO - 2017-05-18 04:43:39 --> URI Class Initialized
INFO - 2017-05-18 04:43:39 --> Output Class Initialized
INFO - 2017-05-18 04:43:39 --> Output Class Initialized
INFO - 2017-05-18 04:43:39 --> Output Class Initialized
INFO - 2017-05-18 04:43:39 --> Router Class Initialized
DEBUG - 2017-05-18 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:39 --> Router Class Initialized
INFO - 2017-05-18 04:43:39 --> Security Class Initialized
INFO - 2017-05-18 04:43:39 --> Security Class Initialized
INFO - 2017-05-18 04:43:39 --> Security Class Initialized
INFO - 2017-05-18 04:43:39 --> Input Class Initialized
INFO - 2017-05-18 04:43:39 --> Output Class Initialized
INFO - 2017-05-18 04:43:39 --> Output Class Initialized
DEBUG - 2017-05-18 04:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-18 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:39 --> Language Class Initialized
DEBUG - 2017-05-18 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:39 --> Security Class Initialized
INFO - 2017-05-18 04:43:39 --> Security Class Initialized
INFO - 2017-05-18 04:43:39 --> Input Class Initialized
INFO - 2017-05-18 04:43:39 --> Input Class Initialized
INFO - 2017-05-18 04:43:39 --> Loader Class Initialized
INFO - 2017-05-18 04:43:39 --> Input Class Initialized
DEBUG - 2017-05-18 04:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-18 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:39 --> Controller Class Initialized
INFO - 2017-05-18 04:43:39 --> Language Class Initialized
INFO - 2017-05-18 04:43:39 --> Language Class Initialized
INFO - 2017-05-18 04:43:39 --> Language Class Initialized
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
INFO - 2017-05-18 04:43:39 --> Loader Class Initialized
INFO - 2017-05-18 04:43:39 --> Input Class Initialized
INFO - 2017-05-18 04:43:39 --> Input Class Initialized
INFO - 2017-05-18 04:43:39 --> Loader Class Initialized
INFO - 2017-05-18 04:43:39 --> Loader Class Initialized
INFO - 2017-05-18 04:43:39 --> Controller Class Initialized
INFO - 2017-05-18 04:43:39 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:39 --> Language Class Initialized
INFO - 2017-05-18 04:43:39 --> Language Class Initialized
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
INFO - 2017-05-18 04:43:39 --> Controller Class Initialized
INFO - 2017-05-18 04:43:39 --> Controller Class Initialized
INFO - 2017-05-18 04:43:39 --> Loader Class Initialized
INFO - 2017-05-18 04:43:39 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:39 --> Loader Class Initialized
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
INFO - 2017-05-18 04:43:39 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
INFO - 2017-05-18 04:43:39 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:39 --> Controller Class Initialized
INFO - 2017-05-18 04:43:39 --> Controller Class Initialized
INFO - 2017-05-18 04:43:39 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:39 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:39 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:39 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
INFO - 2017-05-18 04:43:39 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:39 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:39 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
INFO - 2017-05-18 04:43:39 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:39 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:39 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:39 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:39 --> Helper loaded: file_helper
DEBUG - 2017-05-18 04:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:39 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
INFO - 2017-05-18 04:43:39 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:39 --> Helper loaded: date_helper
DEBUG - 2017-05-18 04:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:39 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:40 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:40 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:40 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:40 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:40 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:40 --> Upload Class Initialized
INFO - 2017-05-18 04:43:40 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:40 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:40 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:40 --> Total execution time: 1.6154
INFO - 2017-05-18 04:43:41 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:41 --> Config Class Initialized
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
INFO - 2017-05-18 04:43:41 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-18 04:43:41 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
INFO - 2017-05-18 04:43:41 --> Utf8 Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> URI Class Initialized
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
INFO - 2017-05-18 04:43:41 --> Router Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Output Class Initialized
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
INFO - 2017-05-18 04:43:41 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-18 04:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
INFO - 2017-05-18 04:43:41 --> Input Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Language Class Initialized
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
INFO - 2017-05-18 04:43:41 --> Loader Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Controller Class Initialized
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
INFO - 2017-05-18 04:43:41 --> Helper loaded: file_helper
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:41 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:41 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:41 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:41 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:41 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:41 --> Upload Class Initialized
INFO - 2017-05-18 04:43:41 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:41 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:42 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:42 --> Total execution time: 2.8341
INFO - 2017-05-18 04:43:42 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
INFO - 2017-05-18 04:43:42 --> Config Class Initialized
INFO - 2017-05-18 04:43:42 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-18 04:43:42 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
INFO - 2017-05-18 04:43:42 --> Utf8 Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> URI Class Initialized
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
INFO - 2017-05-18 04:43:42 --> Router Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Output Class Initialized
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
INFO - 2017-05-18 04:43:42 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-18 04:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
INFO - 2017-05-18 04:43:42 --> Input Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Language Class Initialized
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
INFO - 2017-05-18 04:43:42 --> Loader Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Controller Class Initialized
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
INFO - 2017-05-18 04:43:42 --> Helper loaded: file_helper
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:42 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:42 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:42 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:42 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:42 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:43 --> Upload Class Initialized
INFO - 2017-05-18 04:43:43 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:43 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:43 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:43 --> Total execution time: 4.0284
INFO - 2017-05-18 04:43:43 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:43 --> Config Class Initialized
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
INFO - 2017-05-18 04:43:43 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-18 04:43:43 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
INFO - 2017-05-18 04:43:43 --> Utf8 Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:43 --> URI Class Initialized
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
INFO - 2017-05-18 04:43:43 --> Router Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:43 --> Output Class Initialized
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
INFO - 2017-05-18 04:43:43 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-18 04:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
INFO - 2017-05-18 04:43:43 --> Input Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:43 --> Language Class Initialized
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
INFO - 2017-05-18 04:43:43 --> Loader Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:43 --> Controller Class Initialized
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:43 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
INFO - 2017-05-18 04:43:43 --> Helper loaded: file_helper
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:43 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:43 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:44 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:44 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:44 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:44 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:44 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:44 --> Upload Class Initialized
INFO - 2017-05-18 04:43:44 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:44 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:44 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:44 --> Total execution time: 5.1712
INFO - 2017-05-18 04:43:44 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:44 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:45 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:45 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:45 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:45 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:45 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:45 --> Upload Class Initialized
INFO - 2017-05-18 04:43:45 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:45 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:45 --> Config Class Initialized
INFO - 2017-05-18 04:43:45 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:45 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:45 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:45 --> URI Class Initialized
INFO - 2017-05-18 04:43:45 --> Router Class Initialized
INFO - 2017-05-18 04:43:45 --> Output Class Initialized
INFO - 2017-05-18 04:43:45 --> Security Class Initialized
INFO - 2017-05-18 04:43:45 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-18 04:43:45 --> Total execution time: 6.0973
INFO - 2017-05-18 04:43:45 --> Input Class Initialized
INFO - 2017-05-18 04:43:45 --> Language Class Initialized
INFO - 2017-05-18 04:43:45 --> Loader Class Initialized
INFO - 2017-05-18 04:43:45 --> Controller Class Initialized
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
INFO - 2017-05-18 04:43:45 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:45 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:45 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:45 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:45 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:46 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:46 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:46 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:46 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:46 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:46 --> Upload Class Initialized
INFO - 2017-05-18 04:43:46 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:46 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:46 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:46 --> Total execution time: 7.1710
INFO - 2017-05-18 04:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:46 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:46 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:47 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:47 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:47 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:47 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:47 --> Upload Class Initialized
INFO - 2017-05-18 04:43:47 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:47 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:47 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:47 --> Total execution time: 6.2913
INFO - 2017-05-18 04:43:47 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:47 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:47 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:48 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:48 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:48 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:48 --> Upload Class Initialized
INFO - 2017-05-18 04:43:48 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:48 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:48 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:48 --> Total execution time: 6.0224
INFO - 2017-05-18 04:43:48 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:48 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:48 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:48 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:48 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:48 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:48 --> Upload Class Initialized
INFO - 2017-05-18 04:43:48 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:48 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:49 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:49 --> Total execution time: 5.7764
INFO - 2017-05-18 04:43:49 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:49 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:49 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:49 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:49 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:49 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:49 --> Upload Class Initialized
INFO - 2017-05-18 04:43:49 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:49 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:50 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/header.php
INFO - 2017-05-18 04:43:50 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/topmenu.php
INFO - 2017-05-18 04:43:50 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/sidebar.php
INFO - 2017-05-18 04:43:50 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/patients/list.php
INFO - 2017-05-18 04:43:50 --> File loaded: C:\xampp\htdocs\emedirec_skype\application\views\theme/defualt/template/footer.php
INFO - 2017-05-18 04:43:50 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:50 --> Total execution time: 5.0294
INFO - 2017-05-18 04:43:50 --> Config Class Initialized
INFO - 2017-05-18 04:43:50 --> Hooks Class Initialized
DEBUG - 2017-05-18 04:43:50 --> UTF-8 Support Enabled
INFO - 2017-05-18 04:43:50 --> Utf8 Class Initialized
INFO - 2017-05-18 04:43:50 --> URI Class Initialized
INFO - 2017-05-18 04:43:50 --> Router Class Initialized
INFO - 2017-05-18 04:43:50 --> Output Class Initialized
INFO - 2017-05-18 04:43:50 --> Security Class Initialized
DEBUG - 2017-05-18 04:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-18 04:43:50 --> Input Class Initialized
INFO - 2017-05-18 04:43:50 --> Language Class Initialized
INFO - 2017-05-18 04:43:50 --> Loader Class Initialized
INFO - 2017-05-18 04:43:50 --> Controller Class Initialized
INFO - 2017-05-18 04:43:50 --> Model Class Initialized
INFO - 2017-05-18 04:43:51 --> Database Driver Class Initialized
INFO - 2017-05-18 04:43:51 --> Helper loaded: file_helper
INFO - 2017-05-18 04:43:51 --> Helper loaded: date_helper
INFO - 2017-05-18 04:43:51 --> Session: Class initialized using 'database' driver.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Model Class Initialized
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Helper loaded: url_helper
INFO - 2017-05-18 04:43:51 --> Helper loaded: form_helper
DEBUG - 2017-05-18 04:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-05-18 04:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-05-18 04:43:51 --> Pagination Class Initialized
INFO - 2017-05-18 04:43:51 --> Form Validation Class Initialized
INFO - 2017-05-18 04:43:51 --> Jquery Class Initialized
INFO - 2017-05-18 04:43:51 --> Javascript Class Initialized and loaded. Driver used: jquery
INFO - 2017-05-18 04:43:51 --> Upload Class Initialized
INFO - 2017-05-18 04:43:51 --> Language file loaded: language/english/common_lang.php
INFO - 2017-05-18 04:43:51 --> Language file loaded: language/english/accounttype_lang.php
INFO - 2017-05-18 04:43:51 --> Final output sent to browser
DEBUG - 2017-05-18 04:43:51 --> Total execution time: 1.1060
