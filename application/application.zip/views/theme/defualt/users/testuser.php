<?php
/**
 * Created by IntelliJ IDEA.
 * User: administrator
 * Date: 9/22/15
 * Time: 2:11 PM
 */
    print_r($usd);
?>